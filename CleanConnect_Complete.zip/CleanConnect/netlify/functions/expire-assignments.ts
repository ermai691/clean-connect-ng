import type { Config } from "@netlify/functions";
import { createSupabaseAdmin } from "./_supabase-admin";
import { expireStaleAssignmentsCore, reconcileStuckPaidBookings } from "../../src/lib/matching-core";
import { escalateOverdueConfirmations } from "../../src/lib/completion-escalation";

// Runs every 5 minutes. Granularity doesn't need to match the 30-minute
// response window exactly — a 5-minute sweep means an expired offer is
// caught within 5 minutes of actually expiring, which is fine in practice.
export default async () => {
  const admin = createSupabaseAdmin();

  const expiry = await expireStaleAssignmentsCore(admin);
  const reconcile = await reconcileStuckPaidBookings(admin);
  const escalate = await escalateOverdueConfirmations(admin);

  // Anything the sweep couldn't resolve (no eligible provider found) is
  // already recorded on the booking itself (status = no_provider_available)
  // and visible to admins via the dashboard — this function's job is just
  // to make sure that state gets reached reliably, not to page anyone.
  const failures = [
    ...(expiry.ok ? expiry.results : []).filter((r) => !r.result.ok),
    ...(reconcile.ok ? reconcile.results : []).filter((r) => !r.result.ok),
  ];
  if (failures.length > 0) {
    console.error("expire-assignments: some matching attempts failed", JSON.stringify(failures));
  }

  console.log(
    `expire-assignments: expired=${expiry.ok ? expiry.processed : "ERROR"} reconciled=${reconcile.ok ? reconcile.processed : "ERROR"} escalate=${escalate.ok ? escalate.processed : "ERROR"}`,
  );
};

export const config: Config = {
  schedule: "*/5 * * * *",
};
