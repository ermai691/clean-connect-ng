import type { Config } from "@netlify/functions";
import { createHmac, timingSafeEqual } from "node:crypto";
import { createSupabaseAdmin } from "./_supabase-admin";
import { findAndOfferProvider } from "../../src/lib/matching-core";

// NOTE: this is written against Paystack's documented webhook contract
// (x-paystack-signature = HMAC-SHA512 of the raw request body, hex-encoded,
// using the secret key) but has NOT been exercised against a real Paystack
// account — no credentials have been provided. Treat as unverified until
// tested against Paystack's test mode. See CLEANCONNECT_CHANGELOG.md.

function verifySignature(rawBody: string, signature: string | null, secret: string): boolean {
  if (!signature) return false;
  const expected = createHmac("sha512", secret).update(rawBody).digest("hex");
  // Constant-time comparison — a plain === leaks timing information that
  // could theoretically help an attacker forge a valid signature byte by byte.
  const expectedBuf = Buffer.from(expected, "utf8");
  const actualBuf = Buffer.from(signature, "utf8");
  if (expectedBuf.length !== actualBuf.length) return false;
  return timingSafeEqual(expectedBuf, actualBuf);
}

async function verifyWithPaystack(reference: string, secretKey: string) {
  const res = await fetch(`https://api.paystack.co/transaction/verify/${encodeURIComponent(reference)}`, {
    headers: { Authorization: `Bearer ${secretKey}` },
  });
  if (!res.ok) return { ok: false as const, error: `Paystack verify returned ${res.status}` };
  const body = await res.json();
  return { ok: true as const, data: body?.data };
}

export default async (req: Request) => {
  const secretKey = process.env.PAYSTACK_SECRET_KEY;
  if (!secretKey) {
    console.error("paystack-webhook: PAYSTACK_SECRET_KEY is not set");
    return new Response("Payment processing not configured", { status: 500 });
  }

  const rawBody = await req.text();
  const signature = req.headers.get("x-paystack-signature");
  if (!verifySignature(rawBody, signature, secretKey)) {
    console.error("paystack-webhook: invalid signature");
    return new Response("Invalid signature", { status: 401 });
  }

  let event: any;
  try {
    event = JSON.parse(rawBody);
  } catch {
    return new Response("Invalid JSON", { status: 400 });
  }

  // Only act on successful charges — everything else is acknowledged and ignored.
  if (event?.event !== "charge.success") {
    return new Response("OK", { status: 200 });
  }

  const reference: string | undefined = event?.data?.reference;
  if (!reference) return new Response("Missing reference", { status: 400 });

  // Defense in depth: never trust the webhook payload's amount/status alone —
  // re-verify the transaction directly with Paystack before acting on it.
  const verified = await verifyWithPaystack(reference, secretKey);
  if (!verified.ok || verified.data?.status !== "success") {
    console.error("paystack-webhook: verification failed or not successful", reference);
    return new Response("OK", { status: 200 }); // ack so Paystack doesn't retry forever on a legitimately-failed charge
  }

  // CleanConnect charges NGN only. Reject unexpected currency even if status is success.
  const currency = String(verified.data?.currency ?? "").toUpperCase();
  if (currency && currency !== "NGN") {
    console.error("paystack-webhook: unexpected currency", reference, currency);
    return new Response("OK", { status: 200 });
  }

  const admin = createSupabaseAdmin();

  // --- Quotation payments (no marketplace matching) ---
  const { data: quotation } = await admin
    .from("quotations")
    .select("id, quoted_amount, inspection_fee, include_inspection_fee, status, customer_id, payment_reference, service_name, reference")
    .eq("payment_reference", reference)
    .maybeSingle();

  if (quotation) {
    const base = Number(quotation.quoted_amount);
    const fee =
      quotation.include_inspection_fee && Number(quotation.inspection_fee) > 0
        ? Number(quotation.inspection_fee)
        : 0;
    const expectedKobo = Math.round((base + fee) * 100);
    const paidKobo = Number(verified.data.amount);
    if (paidKobo !== expectedKobo) {
      console.error("paystack-webhook: quotation amount mismatch", { reference, paidKobo, expectedKobo });
      await admin.from("notifications").insert({
        user_id: quotation.customer_id,
        type: "payment_issue",
        title: "Quotation payment amount mismatch",
        body: `Reference ${reference}: paid ${paidKobo} kobo, expected ${expectedKobo} kobo. Needs admin review.`,
      });
      return new Response("OK", { status: 200 });
    }

    // Idempotent: only transition accepted -> paid once
    const { data: qUpdated } = await admin
      .from("quotations")
      .update({ status: "paid", paid_at: new Date().toISOString() })
      .eq("id", quotation.id)
      .eq("status", "accepted")
      .select()
      .maybeSingle();

    if (qUpdated) {
      await admin
        .from("payments")
        .update({ status: "successful" })
        .eq("quotation_id", quotation.id);
      await admin.from("notifications").insert({
        user_id: quotation.customer_id,
        type: "quotation",
        title: "Payment received",
        body: `${quotation.service_name} · ${quotation.reference}: payment verified. CleanConnect will assign an internal team shortly.`,
      });
    }
    // Never call findAndOfferProvider for quotation jobs.
    return new Response("OK", { status: 200 });
  }

  // --- Direct booking payments (existing marketplace flow) ---
  const { data: booking } = await admin
    .from("bookings")
    .select("id, amount, status, customer_id")
    .eq("payment_reference", reference)
    .maybeSingle();

  if (!booking) {
    console.error("paystack-webhook: no booking or quotation found for reference", reference);
    return new Response("OK", { status: 200 });
  }

  // Amount check: Paystack amounts are in kobo; booking.amount is naira.
  const paidKobo = Number(verified.data.amount);
  const expectedKobo = Math.round(Number(booking.amount) * 100);
  if (paidKobo !== expectedKobo) {
    console.error("paystack-webhook: amount mismatch", { reference, paidKobo, expectedKobo });
    await admin.from("notifications").insert({
      user_id: booking.customer_id,
      type: "payment_issue",
      title: "Payment amount mismatch",
      body: `Reference ${reference}: paid ${paidKobo} kobo, expected ${expectedKobo} kobo. Needs admin review.`,
    });
    return new Response("OK", { status: 200 });
  }

  // Idempotent atomic transition: only succeeds once.
  const { data: updated } = await admin
    .from("bookings")
    .update({ status: "paid" })
    .eq("id", booking.id)
    .eq("status", "payment_pending")
    .select()
    .maybeSingle();

  if (!updated) {
    return new Response("OK", { status: 200 });
  }

  await admin.from("payments").update({ status: "successful" }).eq("booking_id", booking.id);

  const matchResult = await findAndOfferProvider(admin, booking.id);
  if (!matchResult.ok) {
    console.error("paystack-webhook: payment succeeded but matching failed", booking.id, matchResult.error);
  }

  return new Response("OK", { status: 200 });
};

export const config: Config = {
  path: "/api/paystack-webhook",
};
