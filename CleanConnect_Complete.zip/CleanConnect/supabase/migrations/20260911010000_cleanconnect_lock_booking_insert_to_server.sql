-- Closes a real pricing-integrity gap: previously a customer's own session
-- could insert a booking directly with any amount they chose, since the
-- INSERT policy only checked ownership, never the amount. Booking creation
-- is now server-side only (see src/lib/booking.functions.ts), which
-- recomputes the authoritative price from the service catalogue.
-- Applied directly to project blgyguiwnbmmlbsjrzqg on 2026-09-11.
DROP POLICY IF EXISTS "Bookings insertable by owner or admin" ON public.bookings;
CREATE POLICY "Bookings insertable by admin only (customers use server fn)" ON public.bookings FOR INSERT TO authenticated
  WITH CHECK (private.has_role((select auth.uid()), 'admin'));
