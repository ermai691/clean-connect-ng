-- Configurable platform settings (commission, timing windows, match weights).
-- Applied directly to project blgyguiwnbmmlbsjrzqg on 2026-09-10.
create table public.platform_settings (
  key text primary key,
  value jsonb not null,
  description text,
  updated_at timestamptz not null default now()
);
grant select on public.platform_settings to authenticated, anon;
grant all on public.platform_settings to service_role;
alter table public.platform_settings enable row level security;
create policy "Anyone can read platform settings" on public.platform_settings for select using (true);
create policy "Admins manage platform settings" on public.platform_settings for all to authenticated
  using (private.has_role((select auth.uid()), 'admin')) with check (private.has_role((select auth.uid()), 'admin'));

insert into public.platform_settings (key, value, description) values
  ('commission_flat_ngn', '5500', 'Flat CleanConnect commission per booking, in NGN'),
  ('provider_response_window_minutes', '30', 'Minutes a provider has to accept/decline an assignment before it reassigns'),
  ('completion_confirm_window_hours', '1', 'Hours after provider marks complete before auto-confirming if customer does nothing'),
  ('match_weights', '{"reliability":0.35,"rating":0.25,"proximity":0.25,"experience":0.15}', 'Weighted scoring factors for provider matching, must sum to 1.0'),
  ('provider_wait_minutes', '15', 'Minutes a provider waits at the service location if the customer is unavailable, before reporting a no-show');
