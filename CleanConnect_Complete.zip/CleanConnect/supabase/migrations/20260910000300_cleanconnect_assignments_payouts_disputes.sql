-- booking_assignments, payouts, and disputes tables -- the core of the
-- automated matching + hold/payout + dispute system.
-- Applied directly to project blgyguiwnbmmlbsjrzqg on 2026-09-10.
create table public.booking_assignments (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null references public.bookings(id) on delete cascade,
  provider_id uuid not null references auth.users(id) on delete cascade,
  match_score numeric,
  status text not null default 'pending' check (status in ('pending','accepted','declined','expired','cancelled')),
  offered_at timestamptz not null default now(),
  responds_by timestamptz not null,
  responded_at timestamptz,
  created_at timestamptz not null default now()
);
grant select, insert, update on public.booking_assignments to authenticated;
grant all on public.booking_assignments to service_role;
alter table public.booking_assignments enable row level security;
create index idx_assignments_booking on public.booking_assignments(booking_id);
create index idx_assignments_provider on public.booking_assignments(provider_id);
create index idx_assignments_pending_deadline on public.booking_assignments(responds_by) where status = 'pending';

create policy "Providers read own assignments" on public.booking_assignments for select to authenticated
  using ((select auth.uid()) = provider_id or private.has_role((select auth.uid()), 'admin'));
create policy "Providers respond to own assignments" on public.booking_assignments for update to authenticated
  using ((select auth.uid()) = provider_id) with check ((select auth.uid()) = provider_id);
create policy "Admins manage assignments" on public.booking_assignments for all to authenticated
  using (private.has_role((select auth.uid()), 'admin')) with check (private.has_role((select auth.uid()), 'admin'));

create table public.payouts (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings(id) on delete cascade,
  provider_id uuid references auth.users(id) on delete set null,
  gross_amount numeric(12,2) not null,
  commission_amount numeric(12,2) not null,
  payout_amount numeric(12,2) not null,
  status text not null default 'pending' check (status in ('pending','held','released','cancelled')),
  held_reason text,
  released_at timestamptz,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);
grant select on public.payouts to authenticated;
grant all on public.payouts to service_role;
alter table public.payouts enable row level security;
create index idx_payouts_provider on public.payouts(provider_id);
create policy "Providers read own payouts" on public.payouts for select to authenticated
  using ((select auth.uid()) = provider_id or private.has_role((select auth.uid()), 'admin'));
create policy "Admins manage payouts" on public.payouts for all to authenticated
  using (private.has_role((select auth.uid()), 'admin')) with check (private.has_role((select auth.uid()), 'admin'));

create table public.disputes (
  id uuid primary key default gen_random_uuid(),
  booking_id uuid not null unique references public.bookings(id) on delete cascade,
  customer_id uuid not null references auth.users(id) on delete cascade,
  reason text not null,
  description text,
  status text not null default 'open' check (status in ('open','resolved')),
  resolution text,
  resolved_by uuid references auth.users(id) on delete set null,
  resolved_at timestamptz,
  created_at timestamptz not null default now()
);
grant select, insert on public.disputes to authenticated;
grant all on public.disputes to service_role;
alter table public.disputes enable row level security;
create policy "Participants read disputes" on public.disputes for select to authenticated
  using (
    (select auth.uid()) = customer_id
    or private.has_role((select auth.uid()), 'admin')
    or exists (select 1 from public.bookings b where b.id = booking_id and b.provider_id = (select auth.uid()))
  );
create policy "Customers open disputes on own bookings" on public.disputes for insert to authenticated
  with check (
    (select auth.uid()) = customer_id
    and exists (select 1 from public.bookings b where b.id = booking_id and b.customer_id = (select auth.uid()))
  );
create policy "Admins resolve disputes" on public.disputes for update to authenticated
  using (private.has_role((select auth.uid()), 'admin')) with check (private.has_role((select auth.uid()), 'admin'));

create trigger trg_payouts_updated before update on public.payouts for each row execute function public.update_updated_at_column();

-- Needed so the provider dashboard's offer banner updates live, not just on
-- page refresh, when a new job is offered.
ALTER PUBLICATION supabase_realtime ADD TABLE public.booking_assignments;
