-- Provider policies (full set), support replies, withdrawal hardening helpers.
-- NOT applied to live Supabase without explicit approval.
-- Depends on 20261101140000_cleanconnect_provider_portal_foundation.sql

-- Support ticket messages (provider + admin). internal_note is admin-only via RLS.
CREATE TABLE IF NOT EXISTS public.provider_support_messages (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  ticket_id uuid NOT NULL REFERENCES public.provider_support_tickets(id) ON DELETE CASCADE,
  sender_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  body text NOT NULL,
  is_internal_note boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS provider_support_messages_ticket_idx
  ON public.provider_support_messages (ticket_id, created_at);

ALTER TABLE public.provider_support_messages ENABLE ROW LEVEL SECURITY;

-- Providers: read non-internal messages on own tickets; insert non-internal on own open/waiting tickets
CREATE POLICY "Providers read own ticket messages"
  ON public.provider_support_messages FOR SELECT TO authenticated
  USING (
    private.has_role(auth.uid(), 'admin')
    OR (
      is_internal_note = false
      AND EXISTS (
        SELECT 1 FROM public.provider_support_tickets t
        WHERE t.id = ticket_id AND t.provider_id = auth.uid()
      )
    )
  );

CREATE POLICY "Providers reply on own tickets"
  ON public.provider_support_messages FOR INSERT TO authenticated
  WITH CHECK (
    is_internal_note = false
    AND sender_id = auth.uid()
    AND EXISTS (
      SELECT 1 FROM public.provider_support_tickets t
      WHERE t.id = ticket_id
        AND t.provider_id = auth.uid()
        AND t.status IN ('open', 'in_progress', 'waiting_for_provider')
    )
  );

CREATE POLICY "Admins manage support messages"
  ON public.provider_support_messages FOR ALL TO authenticated
  USING (private.has_role(auth.uid(), 'admin'))
  WITH CHECK (private.has_role(auth.uid(), 'admin'));

GRANT SELECT, INSERT ON public.provider_support_messages TO authenticated;
GRANT ALL ON public.provider_support_messages TO service_role;

-- Unique active (non-terminal) withdrawal per provider to reduce duplicate spam
CREATE UNIQUE INDEX IF NOT EXISTS provider_withdrawals_one_open_per_provider
  ON public.provider_withdrawals (provider_id)
  WHERE status IN ('requested', 'processing', 'under_review');

-- Seed / upsert all required policy documents (draft — legal review required)
INSERT INTO public.provider_policy_documents (slug, title, version, body, is_required) VALUES
(
  'provider-agreement',
  'CleanConnect Provider Agreement',
  '2026-11-01',
  $b$DRAFT — Requires review by a qualified Nigerian lawyer before public launch.

CleanConnect Provider Agreement (Abuja marketplace).
1. Independent contractor status — not employment.
2. Eligibility: accurate identity docs, verification, admin approval, policy acceptance, truthful availability.
3. Jobs only via CleanConnect matching after customer payment for direct bookings.
4. No off-platform payment requests for platform bookings; no circumventing platform charges.
5. Professional, punctual service; protect customer property and privacy (NDPA 2023 considerations).
6. Earnings subject to platform commission from platform_settings (default ₦5,500 flat per completed direct booking). Quotation-only work is internal and not marketplace provider work.
7. Withdrawals of available balances only; success only after payment-provider confirmation.
8. CleanConnect may restrict accounts for violations after review.
$b$, true
),
(
  'provider-terms',
  'Provider Terms and Conditions',
  '2026-11-01',
  $b$DRAFT — Legal review required.

Terms cover account use, service standards, scheduling (including platform minimum notice and horizon rules), cancellations, fees, limitation of liability (to be finalized by counsel), and governing law of the Federal Republic of Nigeria as applicable.
Providers must follow CleanConnect booking and payment procedures only.
$b$, true
),
(
  'code-of-conduct',
  'Provider Code of Conduct',
  '2026-11-01',
  $b$DRAFT — Legal review required.

Providers must: be punctual; treat customers with respect; avoid harassment, discrimination, threats or abuse; dress and behave professionally; never falsify completion; never manipulate reviews; never misuse customer contacts or addresses; report accidents, damage and safety incidents promptly.
$b$, true
),
(
  'privacy-notice',
  'Provider Privacy Notice',
  '2026-11-01',
  $b$DRAFT — Legal review required under the Nigeria Data Protection Act 2023.

Explains what personal data CleanConnect processes about providers (identity, contact, service areas, performance, payout details), purposes (matching, safety, payments, support), retention, and rights to access/correction subject to law. Contact CleanConnect support for privacy requests.
$b$, true
),
(
  'job-acceptance-cancellation',
  'Job Acceptance and Cancellation Policy',
  '2026-11-01',
  $b$DRAFT — Legal review required.

Offers are time-limited (default 30 minutes). Accept only if you can attend. Repeated declines, expiries or cancellations after accept may affect ranking and eligibility. Cancellations after accept must be rare and reported with reason. CleanConnect may reassign the job.
$b$, true
),
(
  'attendance-no-show',
  'Attendance and No-Show Policy',
  '2026-11-01',
  $b$DRAFT — Legal review required.

Providers must arrive within the agreed window. No-shows harm customers and may lead to warnings, ranking impact, temporary restriction or suspension after review.
$b$, true
),
(
  'quality-safety',
  'Cleaning Quality and Safety Policy',
  '2026-11-01',
  $b$DRAFT — Legal review required.

Use safe methods and appropriate care for surfaces and belongings. Do not use unauthorized chemicals that damage property. Report hazards, injuries or damage immediately. Follow reasonable customer house rules that do not conflict with safety or law.
$b$, true
),
(
  'earnings-withdrawal',
  'Earnings and Withdrawal Policy',
  '2026-11-01',
  $b$DRAFT — Legal review required.

Provider net earnings = eligible completed booking amounts minus platform commission from platform_settings (default ₦5,500 flat) for direct marketplace jobs. Pending vs available balances are separate. Withdrawals require sufficient available balance and verified bank details where required. A withdrawal is not successful until the payment provider confirms. Failed transfers are not treated as paid. Quotation-only jobs are not marketplace provider earnings.
$b$, true
),
(
  'customer-communication',
  'Customer Communication Policy',
  '2026-11-01',
  $b$DRAFT — Legal review required.

Customer contact details are visible only after a job is assigned to you. Use them only for that booking. No spam, harassment, or solicitation of off-platform work for that booking. Messaging should stay professional and booking-related.
$b$, true
),
(
  'confidentiality-data',
  'Customer Confidentiality and Data Protection Policy',
  '2026-11-01',
  $b$DRAFT — Legal review required.

Do not share customer addresses, phone numbers, photos or household details with third parties. Do not retain customer data longer than needed for the job. Comply with applicable data-protection duties including NDPA 2023 themes of security and purpose limitation.
$b$, true
),
(
  'reviews-ratings',
  'Reviews and Ratings Policy',
  '2026-11-01',
  $b$DRAFT — Legal review required.

Reviews must reflect real completed work. Providers must not write, buy, or coerce reviews. Providers may report abusive reviews to CleanConnect for review. CleanConnect may remove reviews that violate policy after assessment.
$b$, true
),
(
  'complaints-disputes',
  'Complaints, Disputes and Appeals Policy',
  '2026-11-01',
  $b$DRAFT — Legal review required.

Customers or providers may raise complaints via support. Disputed jobs may pause earnings release. Providers may appeal disciplinary actions through support with evidence. Serious matters receive human review; automatic permanent bans are not applied on a single unverified complaint alone.
$b$, true
),
(
  'suspension-termination',
  'Account Suspension and Termination Policy',
  '2026-11-01',
  $b$DRAFT — Legal review required.

Statuses may include pending verification, pending approval, approved, restricted, suspended, rejected or deactivated. Only authorized admins change privileged statuses. Temporary restriction may be used during investigation. Appeals are available via support.
$b$, true
),
(
  'prohibited-fraud',
  'Prohibited Conduct and Fraud Prevention Policy',
  '2026-11-01',
  $b$DRAFT — Legal review required.

Prohibited: fake identity, fake completions, payment diversion, commission evasion, unauthorized charges, review fraud, account sharing for fraud, threats, theft, and platform circumvention. CleanConnect may hold funds, reverse withdrawals, suspend accounts and report unlawful activity where required.
$b$, true
)
ON CONFLICT (slug) DO UPDATE SET
  title = EXCLUDED.title,
  version = EXCLUDED.version,
  body = EXCLUDED.body,
  is_required = EXCLUDED.is_required,
  published_at = now();
