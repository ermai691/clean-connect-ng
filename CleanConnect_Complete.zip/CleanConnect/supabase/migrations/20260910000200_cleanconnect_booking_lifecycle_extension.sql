-- Extends booking status to the full marketplace lifecycle (payment ->
-- matching -> assignment -> completion -> payout), plus matching/payment
-- support columns. Applied directly to project blgyguiwnbmmlbsjrzqg on 2026-09-10.
alter table public.bookings drop constraint if exists bookings_status_check;
alter table public.bookings add constraint bookings_status_check check (status in (
  'payment_pending', 'paid', 'finding_provider', 'no_provider_available',
  'assignment_pending', 'provider_accepted', 'on_the_way', 'in_progress',
  'completed', 'awaiting_confirmation', 'confirmed_complete', 'disputed',
  'payout_released', 'cancelled', 'rejected'
));
alter table public.bookings alter column status set default 'payment_pending';

alter table public.bookings add column service_city text;
alter table public.bookings add column service_state text;
alter table public.bookings add column completed_at timestamptz;
alter table public.bookings add column confirm_deadline timestamptz;
alter table public.bookings add column payment_reference text;
