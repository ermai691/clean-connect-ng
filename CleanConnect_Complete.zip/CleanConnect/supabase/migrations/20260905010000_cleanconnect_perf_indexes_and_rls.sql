-- Phase 3 cleanup: Supabase performance advisor findings.
-- 1) Missing indexes on foreign key columns.
-- 2) RLS policies re-evaluating auth.uid()/has_role() per row instead of
--    once per query -- wrapped in (select ...) per Supabase's guidance:
--    https://supabase.com/docs/guides/database/postgres/row-level-security#call-functions-with-select
-- No security/behavior change -- same access rules, just faster at scale.
-- Applied directly to project blgyguiwnbmmlbsjrzqg on 2026-09-05.

CREATE INDEX IF NOT EXISTS idx_addresses_user ON public.addresses(user_id);
CREATE INDEX IF NOT EXISTS idx_messages_booking ON public.messages(booking_id);
CREATE INDEX IF NOT EXISTS idx_messages_sender ON public.messages(sender_id);
CREATE INDEX IF NOT EXISTS idx_payments_booking ON public.payments(booking_id);
CREATE INDEX IF NOT EXISTS idx_reviews_customer ON public.reviews(customer_id);
CREATE INDEX IF NOT EXISTS idx_reviews_provider ON public.reviews(provider_id);
CREATE INDEX IF NOT EXISTS idx_wallet_transactions_user ON public.wallet_transactions(user_id);

DROP POLICY IF EXISTS "Users read own profile" ON public.profiles;
CREATE POLICY "Users read own profile" ON public.profiles FOR SELECT TO authenticated
  USING ((select auth.uid()) = id OR private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "Users insert own profile" ON public.profiles;
CREATE POLICY "Users insert own profile" ON public.profiles FOR INSERT TO authenticated
  WITH CHECK ((select auth.uid()) = id);

DROP POLICY IF EXISTS "Users update own profile" ON public.profiles;
DROP POLICY IF EXISTS "Admins update any profile" ON public.profiles;
CREATE POLICY "Users update own profile" ON public.profiles FOR UPDATE TO authenticated
  USING ((select auth.uid()) = id OR private.has_role((select auth.uid()), 'admin'))
  WITH CHECK ((select auth.uid()) = id OR private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "Users manage own addresses" ON public.addresses;
CREATE POLICY "Users manage own addresses" ON public.addresses FOR ALL TO authenticated
  USING ((select auth.uid()) = user_id) WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Customers read own bookings" ON public.bookings;
DROP POLICY IF EXISTS "Admins manage bookings" ON public.bookings;
CREATE POLICY "Bookings readable by participants" ON public.bookings FOR SELECT TO authenticated
  USING ((select auth.uid()) = customer_id OR (select auth.uid()) = provider_id OR private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "Customers create own bookings" ON public.bookings;
CREATE POLICY "Bookings insertable by owner or admin" ON public.bookings FOR INSERT TO authenticated
  WITH CHECK ((select auth.uid()) = customer_id OR private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "Customers update own bookings" ON public.bookings;
DROP POLICY IF EXISTS "Providers update assigned bookings" ON public.bookings;
CREATE POLICY "Bookings updatable by participants or admin" ON public.bookings FOR UPDATE TO authenticated
  USING ((select auth.uid()) = customer_id OR (select auth.uid()) = provider_id OR private.has_role((select auth.uid()), 'admin'))
  WITH CHECK ((select auth.uid()) = customer_id OR (select auth.uid()) = provider_id OR private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "Customers read own payments" ON public.payments;
CREATE POLICY "Customers read own payments" ON public.payments FOR SELECT TO authenticated
  USING ((select auth.uid()) = customer_id OR private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "Customers create own payments" ON public.payments;
CREATE POLICY "Customers create own payments" ON public.payments FOR INSERT TO authenticated
  WITH CHECK ((select auth.uid()) = customer_id);

DROP POLICY IF EXISTS "Admins update payments" ON public.payments;
CREATE POLICY "Admins update payments" ON public.payments FOR UPDATE TO authenticated
  USING (private.has_role((select auth.uid()), 'admin')) WITH CHECK (private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "Users read own wallet" ON public.wallet_transactions;
CREATE POLICY "Users read own wallet" ON public.wallet_transactions FOR SELECT TO authenticated
  USING ((select auth.uid()) = user_id OR private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "Users create own wallet rows" ON public.wallet_transactions;
CREATE POLICY "Users create own wallet rows" ON public.wallet_transactions FOR INSERT TO authenticated
  WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Reviews readable by participants" ON public.reviews;
CREATE POLICY "Reviews readable by participants" ON public.reviews FOR SELECT TO authenticated
  USING ((select auth.uid()) = customer_id OR (select auth.uid()) = provider_id OR private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "Customers review own completed bookings" ON public.reviews;
CREATE POLICY "Customers review own completed bookings" ON public.reviews FOR INSERT TO authenticated
  WITH CHECK ((select auth.uid()) = customer_id AND EXISTS (
    SELECT 1 FROM public.bookings b WHERE b.id = booking_id AND b.customer_id = (select auth.uid()) AND b.status = 'completed'
  ));

DROP POLICY IF EXISTS "Customers manage own reviews" ON public.reviews;
CREATE POLICY "Customers manage own reviews" ON public.reviews FOR UPDATE TO authenticated
  USING ((select auth.uid()) = customer_id) WITH CHECK ((select auth.uid()) = customer_id);

DROP POLICY IF EXISTS "Customers delete own reviews" ON public.reviews;
CREATE POLICY "Customers delete own reviews" ON public.reviews FOR DELETE TO authenticated
  USING ((select auth.uid()) = customer_id);

DROP POLICY IF EXISTS "Participants read messages" ON public.messages;
CREATE POLICY "Participants read messages" ON public.messages FOR SELECT TO authenticated
  USING ((select auth.uid()) = sender_id OR (select auth.uid()) = recipient_id OR private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "Users send messages" ON public.messages;
CREATE POLICY "Users send messages" ON public.messages FOR INSERT TO authenticated
  WITH CHECK ((select auth.uid()) = sender_id);

DROP POLICY IF EXISTS "Recipients mark read" ON public.messages;
CREATE POLICY "Recipients mark read" ON public.messages FOR UPDATE TO authenticated
  USING ((select auth.uid()) = recipient_id) WITH CHECK ((select auth.uid()) = recipient_id);

DROP POLICY IF EXISTS "Users read own notifications" ON public.notifications;
CREATE POLICY "Users read own notifications" ON public.notifications FOR SELECT TO authenticated
  USING ((select auth.uid()) = user_id OR private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "System inserts notifications" ON public.notifications;
CREATE POLICY "System inserts notifications" ON public.notifications FOR INSERT TO authenticated
  WITH CHECK ((select auth.uid()) = user_id OR private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "Users update own notifications" ON public.notifications;
CREATE POLICY "Users update own notifications" ON public.notifications FOR UPDATE TO authenticated
  USING ((select auth.uid()) = user_id) WITH CHECK ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users delete own notifications" ON public.notifications;
CREATE POLICY "Users delete own notifications" ON public.notifications FOR DELETE TO authenticated
  USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Users claim non-admin role" ON public.user_roles;
CREATE POLICY "Users claim non-admin role" ON public.user_roles FOR INSERT TO authenticated
  WITH CHECK ((select auth.uid()) = user_id AND role <> 'admin');

DROP POLICY IF EXISTS "Users can read their own roles" ON public.user_roles;
CREATE POLICY "Users can read their own roles" ON public.user_roles FOR SELECT TO authenticated
  USING ((select auth.uid()) = user_id);

DROP POLICY IF EXISTS "Approved providers are publicly readable" ON public.providers;
DROP POLICY IF EXISTS "Admins manage providers" ON public.providers;
CREATE POLICY "Providers readable by anyone or owner or admin" ON public.providers FOR SELECT
  USING (approval_status = 'approved' OR (select auth.uid()) = id OR private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "Users create own provider application" ON public.providers;
CREATE POLICY "Users create own provider application" ON public.providers FOR INSERT TO authenticated
  WITH CHECK ((select auth.uid()) = id OR private.has_role((select auth.uid()), 'admin'));

DROP POLICY IF EXISTS "Providers update own profile" ON public.providers;
CREATE POLICY "Providers update own profile" ON public.providers FOR UPDATE TO authenticated
  USING ((select auth.uid()) = id OR private.has_role((select auth.uid()), 'admin'))
  WITH CHECK ((select auth.uid()) = id OR private.has_role((select auth.uid()), 'admin'));
