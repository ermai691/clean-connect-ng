-- Found via live RLS testing (simulating real users with
-- request.jwt.claim.sub): the old message-send policy only checked that
-- the sender was who they claimed to be, never that they were actually a
-- current participant of the referenced booking. A provider reassigned
-- away from a booking could still insert new messages to the real
-- customer, impersonating ongoing involvement. Verified fixed by re-running
-- the same attack after this migration -- it now fails with an RLS
-- violation, while the legitimate currently-assigned provider still sends fine.
-- Applied directly to project blgyguiwnbmmlbsjrzqg on 2026-09-11.
DROP POLICY IF EXISTS "Users send messages" ON public.messages;
CREATE POLICY "Participants send messages" ON public.messages FOR INSERT TO authenticated
  WITH CHECK (
    (select auth.uid()) = sender_id
    AND (
      private.has_role((select auth.uid()), 'admin')
      OR (
        booking_id IS NOT NULL
        AND EXISTS (
          SELECT 1 FROM public.bookings b
          WHERE b.id = booking_id
            AND (b.customer_id = (select auth.uid()) OR b.provider_id = (select auth.uid()))
            AND (recipient_id = b.customer_id OR recipient_id = b.provider_id)
        )
      )
    )
  );
