-- Provider portal foundation: withdrawals ledger, policy acceptance, support tickets.
-- NOT applied to live Supabase without explicit approval.
-- Does not alter bookings matching or quotation tables.

-- ---------------------------------------------------------------------------
-- Provider bank accounts (for withdrawal destination)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.provider_bank_accounts (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  bank_name text NOT NULL,
  account_number text NOT NULL,
  account_name text NOT NULL,
  is_default boolean NOT NULL DEFAULT false,
  verified boolean NOT NULL DEFAULT false,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS provider_bank_accounts_provider_idx
  ON public.provider_bank_accounts (provider_id);

ALTER TABLE public.provider_bank_accounts ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Providers manage own bank accounts"
  ON public.provider_bank_accounts FOR ALL TO authenticated
  USING (auth.uid() = provider_id OR private.has_role(auth.uid(), 'admin'))
  WITH CHECK (auth.uid() = provider_id OR private.has_role(auth.uid(), 'admin'));

GRANT SELECT, INSERT, UPDATE, DELETE ON public.provider_bank_accounts TO authenticated;
GRANT ALL ON public.provider_bank_accounts TO service_role;

-- ---------------------------------------------------------------------------
-- Withdrawal requests (Model B: provider-initiated; Paystack Transfer is external)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.provider_withdrawals (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  amount numeric(12, 2) NOT NULL CHECK (amount > 0),
  currency text NOT NULL DEFAULT 'NGN',
  status text NOT NULL DEFAULT 'requested'
    CHECK (status IN ('requested', 'processing', 'successful', 'failed', 'reversed', 'under_review')),
  bank_account_id uuid REFERENCES public.provider_bank_accounts(id) ON DELETE SET NULL,
  paystack_transfer_code text,
  paystack_reference text UNIQUE,
  failure_reason text,
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now(),
  processed_at timestamptz
);

CREATE INDEX IF NOT EXISTS provider_withdrawals_provider_idx
  ON public.provider_withdrawals (provider_id, created_at DESC);

ALTER TABLE public.provider_withdrawals ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Providers read own withdrawals"
  ON public.provider_withdrawals FOR SELECT TO authenticated
  USING (auth.uid() = provider_id OR private.has_role(auth.uid(), 'admin'));

CREATE POLICY "Providers insert own withdrawal requests"
  ON public.provider_withdrawals FOR INSERT TO authenticated
  WITH CHECK (auth.uid() = provider_id);

CREATE POLICY "Admins update withdrawals"
  ON public.provider_withdrawals FOR UPDATE TO authenticated
  USING (private.has_role(auth.uid(), 'admin'))
  WITH CHECK (private.has_role(auth.uid(), 'admin'));

GRANT SELECT, INSERT ON public.provider_withdrawals TO authenticated;
GRANT ALL ON public.provider_withdrawals TO service_role;

-- ---------------------------------------------------------------------------
-- Versioned provider policies + acceptance records
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.provider_policy_documents (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  slug text NOT NULL UNIQUE,
  title text NOT NULL,
  version text NOT NULL,
  body text NOT NULL,
  is_required boolean NOT NULL DEFAULT true,
  published_at timestamptz NOT NULL DEFAULT now(),
  created_at timestamptz NOT NULL DEFAULT now()
);

CREATE TABLE IF NOT EXISTS public.provider_policy_acceptances (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  policy_id uuid NOT NULL REFERENCES public.provider_policy_documents(id) ON DELETE CASCADE,
  policy_version text NOT NULL,
  accepted_at timestamptz NOT NULL DEFAULT now(),
  UNIQUE (provider_id, policy_id, policy_version)
);

ALTER TABLE public.provider_policy_documents ENABLE ROW LEVEL SECURITY;
ALTER TABLE public.provider_policy_acceptances ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Anyone authenticated can read published policies"
  ON public.provider_policy_documents FOR SELECT TO authenticated
  USING (true);

CREATE POLICY "Providers manage own acceptances"
  ON public.provider_policy_acceptances FOR ALL TO authenticated
  USING (auth.uid() = provider_id OR private.has_role(auth.uid(), 'admin'))
  WITH CHECK (auth.uid() = provider_id OR private.has_role(auth.uid(), 'admin'));

GRANT SELECT ON public.provider_policy_documents TO authenticated;
GRANT SELECT, INSERT ON public.provider_policy_acceptances TO authenticated;
GRANT ALL ON public.provider_policy_documents TO service_role;
GRANT ALL ON public.provider_policy_acceptances TO service_role;

-- Seed core required agreement (draft — legal review required before production)
INSERT INTO public.provider_policy_documents (slug, title, version, body, is_required)
VALUES (
  'provider-agreement',
  'CleanConnect Provider Agreement',
  '2026-11-01',
  $policy$
This is an implementation draft of the CleanConnect Provider Agreement for a Nigerian cleaning-services marketplace (Abuja launch). It is not legal advice and requires review by a qualified Nigerian lawyer before public launch.

1. Role. Providers are independent service professionals, not employees of CleanConnect.
2. Eligibility. Providers must submit accurate identity documents, complete verification, obtain admin approval, accept required policies, and keep availability accurate.
3. Job offers. Providers only receive jobs matched by CleanConnect. Providers must not solicit or accept off-platform payment for platform bookings.
4. Conduct. Providers must be punctual, professional, respectful, and must protect customer privacy (NDPA 2023 considerations apply). Harassment, fraud, fake completions, or review manipulation is prohibited.
5. Quality & safety. Providers must perform services carefully and report damage, accidents, or safety issues promptly.
6. Earnings. Platform commission is configured in platform settings (default ₦5,500 flat per completed direct marketplace booking). Quotation-only jobs are internal CleanConnect work and are not marketplace provider jobs.
7. Withdrawals. Providers may request withdrawals of available balances. Transfers complete only after payment-provider confirmation. CleanConnect may hold or reverse funds for disputes, fraud, or errors.
8. Suspension. CleanConnect may restrict or suspend accounts for policy violations after review. Serious cases may be reported to authorities where required by law.
9. Changes. Material policy updates require re-acceptance of a new version.

Flag for legal review: liability allocation, insurance, tax, and dispute procedures.
$policy$,
  true
)
ON CONFLICT (slug) DO NOTHING;

-- ---------------------------------------------------------------------------
-- Provider support tickets (minimal; admin can read via RLS)
-- ---------------------------------------------------------------------------
CREATE TABLE IF NOT EXISTS public.provider_support_tickets (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  provider_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,
  category text NOT NULL,
  subject text NOT NULL,
  body text NOT NULL,
  status text NOT NULL DEFAULT 'open'
    CHECK (status IN ('open', 'in_progress', 'waiting_for_provider', 'resolved', 'closed')),
  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

CREATE INDEX IF NOT EXISTS provider_support_tickets_provider_idx
  ON public.provider_support_tickets (provider_id, created_at DESC);

ALTER TABLE public.provider_support_tickets ENABLE ROW LEVEL SECURITY;

CREATE POLICY "Providers manage own support tickets"
  ON public.provider_support_tickets FOR ALL TO authenticated
  USING (auth.uid() = provider_id OR private.has_role(auth.uid(), 'admin'))
  WITH CHECK (
    (auth.uid() = provider_id AND status = 'open')
    OR private.has_role(auth.uid(), 'admin')
  );

GRANT SELECT, INSERT, UPDATE ON public.provider_support_tickets TO authenticated;
GRANT ALL ON public.provider_support_tickets TO service_role;
