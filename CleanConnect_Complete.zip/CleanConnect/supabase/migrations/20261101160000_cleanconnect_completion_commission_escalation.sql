-- Completion audit fields, commission ₦5,000 default, 5-minute admin escalation window.
-- NOT applied to live Supabase without explicit approval.
-- Does NOT auto-pay providers after five minutes.

ALTER TABLE public.bookings
  ADD COLUMN IF NOT EXISTS started_at timestamptz,
  ADD COLUMN IF NOT EXISTS confirmed_at timestamptz,
  ADD COLUMN IF NOT EXISTS confirmed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS confirmation_source text
    CHECK (confirmation_source IS NULL OR confirmation_source IN ('customer', 'admin_phone')),
  ADD COLUMN IF NOT EXISTS admin_confirm_note text,
  ADD COLUMN IF NOT EXISTS escalation_notified_at timestamptz;

COMMENT ON COLUMN public.bookings.confirmation_source IS
  'customer = customer confirmed in app; admin_phone = admin confirmed after phone verification. Not an automatic timer payment.';
COMMENT ON COLUMN public.bookings.confirm_deadline IS
  'Admin escalation reminder deadline after provider marks complete. Does NOT auto-release earnings.';

-- Commission: set official default to 5000 NGN without wiping a custom non-5500 value.
UPDATE public.platform_settings
SET
  value = '5000'::jsonb,
  description = 'Flat CleanConnect commission per completed direct marketplace booking, in NGN (official: 5000)'
WHERE key = 'commission_flat_ngn'
  AND (value::text IN ('5500', '"5500"', '5000', '"5000"') OR value IS NULL);

-- Prefer minutes for the 5-minute admin escalation window (json number, not integer column).
INSERT INTO public.platform_settings (key, value, description)
VALUES (
  'completion_confirm_window_minutes',
  '5'::jsonb,
  'Minutes after provider marks complete before admin escalation notification. Does NOT auto-pay the provider.'
)
ON CONFLICT (key) DO UPDATE
SET description = EXCLUDED.description;

-- Keep hours key documented as legacy; do not use it for auto-confirm payment.
UPDATE public.platform_settings
SET description = 'LEGACY hours setting. Prefer completion_confirm_window_minutes. Does NOT auto-release provider earnings.'
WHERE key = 'completion_confirm_window_hours';
