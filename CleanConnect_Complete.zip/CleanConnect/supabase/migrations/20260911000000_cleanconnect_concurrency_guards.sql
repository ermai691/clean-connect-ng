-- Hard database-level guarantees against race conditions:
-- 1) At most one pending assignment per booking at a time.
-- 2) A payment reference can only ever belong to one booking.
-- Applied directly to project blgyguiwnbmmlbsjrzqg on 2026-09-11.
CREATE UNIQUE INDEX idx_one_pending_assignment_per_booking
  ON public.booking_assignments (booking_id)
  WHERE status = 'pending';

CREATE UNIQUE INDEX idx_bookings_payment_reference_unique
  ON public.bookings (payment_reference)
  WHERE payment_reference IS NOT NULL;
