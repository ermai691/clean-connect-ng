-- Staff-field privacy for quotations.
-- Customers must not read internal columns via the Supabase API.
-- Admins retain full access through service-role server functions (not broad
-- authenticated SELECTs on sensitive columns).
-- NOT applied to live Supabase without explicit approval.
--
-- Apply AFTER:
--   20261029233000_cleanconnect_quotations_foundation.sql
--   20261030233000_cleanconnect_quotation_payment_handover.sql

-- ---------------------------------------------------------------------------
-- 1. Customer-facing view (safe columns only)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE VIEW public.customer_quotations
WITH (security_invoker = true)
AS
SELECT
  id,
  reference,
  customer_id,
  service_id,
  service_name,
  job_details,
  address,
  notes,
  attachment_paths,
  status,
  quoted_amount,
  inspection_fee,
  include_inspection_fee,
  valid_until,
  booking_id,
  payment_reference,
  paid_at,
  created_at,
  updated_at
FROM public.quotations;

COMMENT ON VIEW public.customer_quotations IS
  'Customer-safe quotation projection. Excludes staff_notes, assignment and review metadata.';

-- RLS on the view is enforced via security_invoker against base table policies.
GRANT SELECT ON public.customer_quotations TO authenticated;
GRANT SELECT ON public.customer_quotations TO service_role;

-- ---------------------------------------------------------------------------
-- 2. Lock down base table privileges for the authenticated role
-- ---------------------------------------------------------------------------
REVOKE ALL ON public.quotations FROM PUBLIC;
REVOKE ALL ON public.quotations FROM anon;
REVOKE ALL ON public.quotations FROM authenticated;

-- Customers may INSERT only non-privileged columns (RLS still requires status=submitted
-- and null staff/price fields).
GRANT INSERT (
  id,
  reference,
  customer_id,
  service_id,
  service_name,
  job_details,
  address,
  notes,
  attachment_paths,
  status
) ON public.quotations TO authenticated;

-- Customers may UPDATE only request details + status (cancel). Cannot touch
-- staff notes, assignment, pricing, payment or review columns.
GRANT UPDATE (
  job_details,
  address,
  notes,
  attachment_paths,
  status
) ON public.quotations TO authenticated;

-- Column-level SELECT on customer-safe fields only.
-- Required so security_invoker views can resolve underlying columns for the caller.
-- Staff-only columns (staff_notes, reviewed_*, assigned_*, assignment_notes) are NOT granted.
GRANT SELECT (
  id,
  reference,
  customer_id,
  service_id,
  service_name,
  job_details,
  address,
  notes,
  attachment_paths,
  status,
  quoted_amount,
  inspection_fee,
  include_inspection_fee,
  valid_until,
  booking_id,
  payment_reference,
  paid_at,
  created_at,
  updated_at
) ON public.quotations TO authenticated;

-- service_role keeps full access for trusted server functions (admin list, pricing, assign, webhook).
GRANT ALL ON public.quotations TO service_role;

-- ---------------------------------------------------------------------------
-- 3. Defence in depth: block non-admin changes to internal columns on UPDATE
--    (extends existing quotations_protect_row behaviour)
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.quotations_protect_row()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  is_admin boolean;
BEGIN
  IF NOT private.quotation_paths_belong_to_row(NEW.customer_id, NEW.id, NEW.attachment_paths) THEN
    RAISE EXCEPTION 'attachment_paths must use the format {customer_id}/{quotation_id}/{filename} for this quotation'
      USING ERRCODE = 'check_violation';
  END IF;

  IF TG_OP = 'INSERT' THEN
    RETURN NEW;
  END IF;

  -- Service-role / backend (supabaseAdmin): auth.uid() is null
  IF auth.uid() IS NULL THEN
    RETURN NEW;
  END IF;

  SELECT private.has_role(auth.uid(), 'admin') INTO is_admin;
  IF COALESCE(is_admin, false) THEN
    RETURN NEW;
  END IF;

  IF NEW.service_id IS DISTINCT FROM OLD.service_id
     OR NEW.service_name IS DISTINCT FROM OLD.service_name THEN
    RAISE EXCEPTION 'service_id and service_name cannot be changed after a quotation is created'
      USING ERRCODE = 'check_violation';
  END IF;

  IF NEW.customer_id IS DISTINCT FROM OLD.customer_id THEN
    RAISE EXCEPTION 'customer_id cannot be changed'
      USING ERRCODE = 'check_violation';
  END IF;

  IF NEW.quoted_amount IS DISTINCT FROM OLD.quoted_amount
     OR NEW.inspection_fee IS DISTINCT FROM OLD.inspection_fee
     OR NEW.valid_until IS DISTINCT FROM OLD.valid_until
     OR NEW.booking_id IS DISTINCT FROM OLD.booking_id
     OR NEW.reviewed_at IS DISTINCT FROM OLD.reviewed_at
     OR NEW.reviewed_by IS DISTINCT FROM OLD.reviewed_by
     OR NEW.staff_notes IS DISTINCT FROM OLD.staff_notes
     OR NEW.payment_reference IS DISTINCT FROM OLD.payment_reference
     OR NEW.paid_at IS DISTINCT FROM OLD.paid_at
     OR NEW.include_inspection_fee IS DISTINCT FROM OLD.include_inspection_fee
     OR NEW.assigned_team_label IS DISTINCT FROM OLD.assigned_team_label
     OR NEW.assigned_by IS DISTINCT FROM OLD.assigned_by
     OR NEW.assigned_at IS DISTINCT FROM OLD.assigned_at
     OR NEW.assignment_notes IS DISTINCT FROM OLD.assignment_notes THEN
    RAISE EXCEPTION 'privileged quotation fields can only be changed by an administrator or the system'
      USING ERRCODE = 'check_violation';
  END IF;

  RETURN NEW;
END;
$$;
