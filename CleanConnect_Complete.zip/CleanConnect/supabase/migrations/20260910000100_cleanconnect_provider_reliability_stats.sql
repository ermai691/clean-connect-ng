-- Reliability stat columns feeding the matching score.
-- Applied directly to project blgyguiwnbmmlbsjrzqg on 2026-09-10.
alter table public.providers add column completed_jobs integer not null default 0;
alter table public.providers add column cancelled_jobs integer not null default 0;
alter table public.providers add column no_show_count integer not null default 0;
alter table public.providers add column assignments_accepted integer not null default 0;
alter table public.providers add column assignments_declined integer not null default 0;
alter table public.providers add column assignments_expired integer not null default 0;
