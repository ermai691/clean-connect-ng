-- Quotation Paystack payment + admin-only internal-team assignment.
-- NOT applied to live Supabase without explicit approval.
--
-- After verified payment:
--   - quotation status becomes 'paid'
--   - job awaits admin assignment (NOT marketplace matching)
-- Admin then assigns to an internal team label; no findAndOfferProvider.

ALTER TABLE public.payments
  ADD COLUMN IF NOT EXISTS quotation_id uuid REFERENCES public.quotations(id) ON DELETE SET NULL;

CREATE INDEX IF NOT EXISTS payments_quotation_id_idx ON public.payments (quotation_id);

ALTER TABLE public.quotations
  ADD COLUMN IF NOT EXISTS payment_reference text,
  ADD COLUMN IF NOT EXISTS paid_at timestamptz,
  ADD COLUMN IF NOT EXISTS include_inspection_fee boolean NOT NULL DEFAULT false,
  ADD COLUMN IF NOT EXISTS assigned_team_label text,
  ADD COLUMN IF NOT EXISTS assigned_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  ADD COLUMN IF NOT EXISTS assigned_at timestamptz,
  ADD COLUMN IF NOT EXISTS assignment_notes text;

CREATE UNIQUE INDEX IF NOT EXISTS quotations_payment_reference_uidx
  ON public.quotations (payment_reference)
  WHERE payment_reference IS NOT NULL;

-- Replace status CHECK reliably (handles named or auto-generated constraint names).
DO $$
DECLARE
  r record;
BEGIN
  FOR r IN
    SELECT c.conname
    FROM pg_constraint c
    JOIN pg_class t ON t.oid = c.conrelid
    JOIN pg_namespace n ON n.oid = t.relnamespace
    WHERE n.nspname = 'public'
      AND t.relname = 'quotations'
      AND c.contype = 'c'
      AND pg_get_constraintdef(c.oid) ILIKE '%status%'
  LOOP
    EXECUTE format('ALTER TABLE public.quotations DROP CONSTRAINT %I', r.conname);
  END LOOP;
END
$$;

ALTER TABLE public.quotations
  ADD CONSTRAINT quotations_status_check CHECK (status IN (
    'submitted',
    'under_review',
    'quoted',
    'accepted',
    'declined',
    'expired',
    'cancelled',
    'paid',
    'assigned'
  ));

COMMENT ON COLUMN public.payments.quotation_id IS
  'Quotation payments only; booking_id stays null. Never triggers marketplace matching.';
COMMENT ON COLUMN public.quotations.payment_reference IS
  'Paystack reference for accepted-quotation checkout.';
COMMENT ON COLUMN public.quotations.paid_at IS
  'Set only after verified Paystack success. Job then awaits admin assignment.';
COMMENT ON COLUMN public.quotations.include_inspection_fee IS
  'True only when customer explicitly approved disclosed inspection fee before payment.';
COMMENT ON COLUMN public.quotations.assigned_team_label IS
  'Admin-entered CleanConnect internal team / staff label. Not a marketplace provider.';
COMMENT ON COLUMN public.quotations.assigned_by IS
  'Admin user who performed manual assignment.';

-- At most one successful payment per quotation (duplicate webhook protection at DB layer)
CREATE UNIQUE INDEX IF NOT EXISTS payments_one_successful_per_quotation
  ON public.payments (quotation_id)
  WHERE quotation_id IS NOT NULL AND status = 'successful';

-- At most one pending payment per quotation
CREATE UNIQUE INDEX IF NOT EXISTS payments_one_pending_per_quotation
  ON public.payments (quotation_id)
  WHERE quotation_id IS NOT NULL AND status = 'pending';
