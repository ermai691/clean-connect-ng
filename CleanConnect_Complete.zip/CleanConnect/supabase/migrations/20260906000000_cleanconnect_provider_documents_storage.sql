-- Private bucket for provider verification documents (ID, selfie, etc).
-- Not public: these are sensitive identity documents.
-- Applied directly to project blgyguiwnbmmlbsjrzqg on 2026-09-06.
insert into storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
values ('provider-documents', 'provider-documents', false, 5242880, array['image/png','image/jpeg','image/jpg','image/webp'])
on conflict (id) do nothing;

-- Path convention: {provider_user_id}/{doc_type}.{ext} -- the leading folder
-- name is checked against auth.uid() to scope access per provider.
create policy "Providers upload own documents"
  on storage.objects for insert to authenticated
  with check (
    bucket_id = 'provider-documents'
    and (select auth.uid())::text = (storage.foldername(name))[1]
  );

create policy "Providers read own documents, admins read all"
  on storage.objects for select to authenticated
  using (
    bucket_id = 'provider-documents'
    and (
      (select auth.uid())::text = (storage.foldername(name))[1]
      or private.has_role((select auth.uid()), 'admin')
    )
  );

create policy "Providers replace own documents"
  on storage.objects for update to authenticated
  using (bucket_id = 'provider-documents' and (select auth.uid())::text = (storage.foldername(name))[1])
  with check (bucket_id = 'provider-documents' and (select auth.uid())::text = (storage.foldername(name))[1]);

create policy "Providers delete own documents"
  on storage.objects for delete to authenticated
  using (bucket_id = 'provider-documents' and (select auth.uid())::text = (storage.foldername(name))[1]);

-- admin-auth.ts calls supabase.rpc("has_role", ...), which PostgREST always
-- routes through the public schema. The earlier hardening migration revoked
-- authenticated's EXECUTE on public.has_role (keeping it only on
-- private.has_role for RLS policy use), which broke admin login via RPC.
GRANT EXECUTE ON FUNCTION public.has_role(uuid, app_role) TO authenticated;
