-- The previous migration (fix_message_insert_authorization) correctly
-- closed a booking-chat impersonation gap but didn't account for a second,
-- pre-existing use of messages: self-addressed "support" messages with no
-- booking_id (customer.support.tsx, customer.messages.tsx). This restores
-- that narrow case without reopening the impersonation gap.
-- Applied directly to project blgyguiwnbmmlbsjrzqg on 2026-09-11.
DROP POLICY IF EXISTS "Participants send messages" ON public.messages;
CREATE POLICY "Participants send messages" ON public.messages FOR INSERT TO authenticated
  WITH CHECK (
    (select auth.uid()) = sender_id
    AND (
      private.has_role((select auth.uid()), 'admin')
      OR (booking_id IS NULL AND recipient_id = (select auth.uid()))
      OR (
        booking_id IS NOT NULL
        AND EXISTS (
          SELECT 1 FROM public.bookings b
          WHERE b.id = booking_id
            AND (b.customer_id = (select auth.uid()) OR b.provider_id = (select auth.uid()))
            AND (recipient_id = b.customer_id OR recipient_id = b.provider_id)
        )
      )
    )
  );
