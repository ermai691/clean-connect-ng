-- Phase 2: dynamic pricing needs somewhere to store the size/scope details
-- a customer enters (bedrooms, sqm, guest count, load count, severity, etc).
-- Applied directly to project blgyguiwnbmmlbsjrzqg on 2026-09-05.
ALTER TABLE public.bookings ADD COLUMN job_details jsonb NOT NULL DEFAULT '{}'::jsonb;
