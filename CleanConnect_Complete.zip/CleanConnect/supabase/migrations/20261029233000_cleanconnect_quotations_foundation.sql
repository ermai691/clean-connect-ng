-- CleanConnect quotation-request foundation (security-hardened).
-- Creates the quotations table, RLS policies that keep privileged fields
-- staff-only, a private quotation-attachments storage bucket, column-lock
-- trigger for service identity, path-bound attachment ownership, and a
-- non-destructive seed for quotation_validity_days (default 7).
-- Does NOT touch bookings, payments, matching, or Phase 0 classifications.
-- Migration only — not applied to the live database by this change.

-- ---------------------------------------------------------------------------
-- 1. quotations table
-- ---------------------------------------------------------------------------
CREATE TABLE public.quotations (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  reference text NOT NULL UNIQUE
    DEFAULT ('CQ-' || upper(substr(replace(gen_random_uuid()::text, '-', ''), 1, 8))),
  customer_id uuid NOT NULL REFERENCES auth.users(id) ON DELETE CASCADE,

  -- Service snapshot (catalogue may change later; keep the name the customer saw)
  service_id text NOT NULL,
  service_name text NOT NULL,

  -- Customer-supplied job information
  job_details jsonb NOT NULL DEFAULT '{}'::jsonb,
  address text NOT NULL,
  notes text,

  -- Storage object paths relative to the quotation-attachments bucket
  -- Convention: {customer_id}/{quotation_id}/{filename}
  attachment_paths text[] NOT NULL DEFAULT '{}',

  -- Workflow status. Customers may only create 'submitted' and later
  -- transition their own row to 'cancelled'. All other statuses are staff-only.
  status text NOT NULL DEFAULT 'submitted'
    CONSTRAINT quotations_status_check CHECK (status IN (
      'submitted',
      'under_review',
      'quoted',
      'accepted',
      'declined',
      'expired',
      'cancelled'
    )),

  -- Staff-only / system-managed fields (nullable until a quote is issued)
  quoted_amount numeric(12, 2),
  inspection_fee numeric(12, 2),
  valid_until timestamptz,
  booking_id uuid REFERENCES public.bookings(id) ON DELETE SET NULL,
  reviewed_at timestamptz,
  reviewed_by uuid REFERENCES auth.users(id) ON DELETE SET NULL,
  staff_notes text,

  created_at timestamptz NOT NULL DEFAULT now(),
  updated_at timestamptz NOT NULL DEFAULT now()
);

COMMENT ON TABLE public.quotations IS
  'Customer quotation requests for services that require manual assessment. Separate from bookings; marketplace matching must never run on these rows.';

CREATE INDEX quotations_customer_id_idx ON public.quotations (customer_id);
CREATE INDEX quotations_status_idx ON public.quotations (status);
CREATE INDEX quotations_created_at_idx ON public.quotations (created_at DESC);

GRANT SELECT, INSERT, UPDATE ON public.quotations TO authenticated;
GRANT ALL ON public.quotations TO service_role;

ALTER TABLE public.quotations ENABLE ROW LEVEL SECURITY;

-- ---------------------------------------------------------------------------
-- 2. Helper: every attachment path must belong to this quotation
-- ---------------------------------------------------------------------------
-- Path format required: {customer_id}/{quotation_id}/{filename}
CREATE OR REPLACE FUNCTION private.quotation_paths_belong_to_row(
  p_customer_id uuid,
  p_quotation_id uuid,
  p_paths text[]
)
RETURNS boolean
LANGUAGE plpgsql
STABLE
SET search_path = public
AS $$
DECLARE
  p text;
  prefix text;
BEGIN
  IF p_paths IS NULL THEN
    RETURN true;
  END IF;
  prefix := p_customer_id::text || '/' || p_quotation_id::text || '/';
  FOREACH p IN ARRAY p_paths LOOP
    IF p IS NULL OR p = '' OR position(prefix in p) <> 1 THEN
      RETURN false;
    END IF;
  END LOOP;
  RETURN true;
END;
$$;

REVOKE ALL ON FUNCTION private.quotation_paths_belong_to_row(uuid, uuid, text[]) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.quotation_paths_belong_to_row(uuid, uuid, text[]) TO authenticated, service_role;

-- ---------------------------------------------------------------------------
-- 3. Trigger: lock service identity + privileged columns for non-admins;
--    validate attachment_paths on INSERT and UPDATE
-- ---------------------------------------------------------------------------
CREATE OR REPLACE FUNCTION public.quotations_protect_row()
RETURNS trigger
LANGUAGE plpgsql
SECURITY INVOKER
SET search_path = public
AS $$
DECLARE
  is_admin boolean;
BEGIN
  -- Validate attachment path ownership for every write
  IF NOT private.quotation_paths_belong_to_row(NEW.customer_id, NEW.id, NEW.attachment_paths) THEN
    RAISE EXCEPTION 'attachment_paths must use the format {customer_id}/{quotation_id}/{filename} for this quotation'
      USING ERRCODE = 'check_violation';
  END IF;

  IF TG_OP = 'INSERT' THEN
    RETURN NEW;
  END IF;

  -- Service-role / backend (createServerFn with supabaseAdmin): auth.uid() is null.
  -- RLS does not apply to service_role; only trusted server code uses it.
  IF auth.uid() IS NULL THEN
    RETURN NEW;
  END IF;

  -- UPDATE: admins may change anything
  SELECT private.has_role(auth.uid(), 'admin') INTO is_admin;
  IF COALESCE(is_admin, false) THEN
    RETURN NEW;
  END IF;

  -- Non-admin: lock service identity (compare new row to existing row)
  IF NEW.service_id IS DISTINCT FROM OLD.service_id
     OR NEW.service_name IS DISTINCT FROM OLD.service_name THEN
    RAISE EXCEPTION 'service_id and service_name cannot be changed after a quotation is created'
      USING ERRCODE = 'check_violation';
  END IF;

  -- Non-admin: lock ownership and staff-only fields
  IF NEW.customer_id IS DISTINCT FROM OLD.customer_id THEN
    RAISE EXCEPTION 'customer_id cannot be changed'
      USING ERRCODE = 'check_violation';
  END IF;

  IF NEW.quoted_amount IS DISTINCT FROM OLD.quoted_amount
     OR NEW.inspection_fee IS DISTINCT FROM OLD.inspection_fee
     OR NEW.valid_until IS DISTINCT FROM OLD.valid_until
     OR NEW.booking_id IS DISTINCT FROM OLD.booking_id
     OR NEW.reviewed_at IS DISTINCT FROM OLD.reviewed_at
     OR NEW.reviewed_by IS DISTINCT FROM OLD.reviewed_by
     OR NEW.staff_notes IS DISTINCT FROM OLD.staff_notes THEN
    RAISE EXCEPTION 'privileged quotation fields can only be changed by an administrator'
      USING ERRCODE = 'check_violation';
  END IF;

  RETURN NEW;
END;
$$;

CREATE TRIGGER trg_quotations_protect_row
  BEFORE INSERT OR UPDATE ON public.quotations
  FOR EACH ROW
  EXECUTE FUNCTION public.quotations_protect_row();

-- ---------------------------------------------------------------------------
-- 4. RLS policies
-- ---------------------------------------------------------------------------

-- SELECT: owning customer or admin
CREATE POLICY "Customers read own quotations"
  ON public.quotations
  FOR SELECT
  TO authenticated
  USING (
    (select auth.uid()) = customer_id
    OR private.has_role((select auth.uid()), 'admin')
  );

-- INSERT: authenticated customer only; must own the row; status must be
-- 'submitted'; privileged columns must remain null/default so a client
-- cannot self-price or self-approve.
CREATE POLICY "Customers insert own quotation requests"
  ON public.quotations
  FOR INSERT
  TO authenticated
  WITH CHECK (
    (select auth.uid()) = customer_id
    AND status = 'submitted'
    AND quoted_amount IS NULL
    AND inspection_fee IS NULL
    AND valid_until IS NULL
    AND booking_id IS NULL
    AND reviewed_at IS NULL
    AND reviewed_by IS NULL
    AND staff_notes IS NULL
  );

-- UPDATE (customer): owner only, while status is still 'submitted'.
-- May keep status as 'submitted' (edit job details / address / notes /
-- attachment_paths) or set status to 'cancelled'.
-- Privileged columns must remain NULL (defence in depth; trigger also locks them).
-- service_id / service_name are locked by trg_quotations_protect_row.
CREATE POLICY "Customers update or cancel own submitted quotations"
  ON public.quotations
  FOR UPDATE
  TO authenticated
  USING (
    (select auth.uid()) = customer_id
    AND status = 'submitted'
  )
  WITH CHECK (
    (select auth.uid()) = customer_id
    AND status IN ('submitted', 'cancelled')
    AND quoted_amount IS NULL
    AND inspection_fee IS NULL
    AND valid_until IS NULL
    AND booking_id IS NULL
    AND reviewed_at IS NULL
    AND reviewed_by IS NULL
    AND staff_notes IS NULL
  );

-- Full management for admins
CREATE POLICY "Admins manage quotations"
  ON public.quotations
  FOR ALL
  TO authenticated
  USING (private.has_role((select auth.uid()), 'admin'))
  WITH CHECK (private.has_role((select auth.uid()), 'admin'));

-- No DELETE policy for authenticated customers. Admins use the ALL policy
-- above (or service_role). Providers have no policies and therefore no access.

-- ---------------------------------------------------------------------------
-- 5. updated_at trigger (reuses existing shared helper)
-- ---------------------------------------------------------------------------
CREATE TRIGGER trg_quotations_updated
  BEFORE UPDATE ON public.quotations
  FOR EACH ROW
  EXECUTE FUNCTION public.update_updated_at_column();

-- ---------------------------------------------------------------------------
-- 6. Private storage bucket for quotation attachments
-- ---------------------------------------------------------------------------
-- 10 MB limit. Images + short videos only.
INSERT INTO storage.buckets (id, name, public, file_size_limit, allowed_mime_types)
VALUES (
  'quotation-attachments',
  'quotation-attachments',
  false,
  10485760,
  ARRAY['image/jpeg', 'image/png', 'image/webp', 'video/mp4', 'video/quicktime']
)
ON CONFLICT (id) DO NOTHING;

-- Path convention: {customer_id}/{quotation_id}/{filename}
-- First folder = auth.uid(); second folder = id of a quotation owned by that customer.

CREATE OR REPLACE FUNCTION private.quotation_storage_object_owned(object_name text)
RETURNS boolean
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path = public
AS $$
  SELECT EXISTS (
    SELECT 1
    FROM public.quotations q
    WHERE q.customer_id = auth.uid()
      AND q.id::text = (storage.foldername(object_name))[2]
  );
$$;

REVOKE ALL ON FUNCTION private.quotation_storage_object_owned(text) FROM PUBLIC;
GRANT EXECUTE ON FUNCTION private.quotation_storage_object_owned(text) TO authenticated, service_role;

CREATE POLICY "Customers upload own quotation attachments"
  ON storage.objects
  FOR INSERT
  TO authenticated
  WITH CHECK (
    bucket_id = 'quotation-attachments'
    AND (select auth.uid())::text = (storage.foldername(name))[1]
    AND private.quotation_storage_object_owned(name)
  );

CREATE POLICY "Customers read own quotation attachments, admins read all"
  ON storage.objects
  FOR SELECT
  TO authenticated
  USING (
    bucket_id = 'quotation-attachments'
    AND (
      (
        (select auth.uid())::text = (storage.foldername(name))[1]
        AND private.quotation_storage_object_owned(name)
      )
      OR private.has_role((select auth.uid()), 'admin')
    )
  );

CREATE POLICY "Customers delete own quotation attachments"
  ON storage.objects
  FOR DELETE
  TO authenticated
  USING (
    bucket_id = 'quotation-attachments'
    AND (select auth.uid())::text = (storage.foldername(name))[1]
    AND private.quotation_storage_object_owned(name)
  );

-- No general UPDATE policy for customers on storage objects (replace = delete + insert).
-- Admins can read via the SELECT policy above; service_role bypasses RLS when needed.

-- ---------------------------------------------------------------------------
-- 7. platform_settings seed (non-destructive)
-- ---------------------------------------------------------------------------
-- Only inserts the default if the key does not already exist, so an
-- administrator who already configured the value is not overwritten.
INSERT INTO public.platform_settings (key, value, description)
VALUES (
  'quotation_validity_days',
  '7',
  'Default number of days a sent quotation remains valid before it expires'
)
ON CONFLICT (key) DO NOTHING;
