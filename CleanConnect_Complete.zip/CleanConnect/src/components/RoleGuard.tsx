import { Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useState, type ReactNode } from "react";
import { dashboardPathFor, getUser, type Role, type User } from "@/lib/auth";
import { supabase } from "@/integrations/supabase/client";
import { currentCustomer } from "@/lib/customer-auth";
import { currentAdmin } from "@/lib/admin-auth";

/**
 * Route guard.
 * - Admin routes are verified against the real backend session + admin role.
 * - Customer/provider routes keep the existing client session.
 */
export function RoleGuard({ role, children }: { role: Role; children: ReactNode }) {
  const navigate = useNavigate();
  const [state, setState] = useState<{ ready: boolean; user: User | null; denied: boolean }>({
    ready: false,
    user: null,
    denied: false,
  });
  const [failure, setFailure] = useState<string | null>(null);

  useEffect(() => {
    let active = true;

    const sync = async () => {
      try {
        setFailure(null);
        if (role === "admin") {
          const admin = await currentAdmin();
          if (!active) return;
          if (admin) {
            setState({ ready: true, user: { name: admin.name, email: admin.email, role: "admin" }, denied: false });
            return;
          }
          const other = getUser();
          if (other) {
            setState({ ready: true, user: other, denied: true });
            return;
          }
          setState({ ready: true, user: null, denied: false });
          navigate({ to: "/auth/$role", params: { role: "admin" }, replace: true });
          return;
        }

        if (role === "customer") {
          const customer = await currentCustomer();
          if (!active) return;
          const user = customer ? { name: "Customer", email: customer.email, role: "customer" as const } : null;
          setState({ ready: true, user, denied: false });
          if (!user) navigate({ to: "/auth/$role", params: { role }, replace: true });
          return;
        }

        const user = getUser();
        if (!active) return;
        setState({ ready: true, user, denied: false });
        if (!user) navigate({ to: "/auth/$role", params: { role }, replace: true });
      } catch (err) {
        if (!active) return;
        // A failure here (e.g. a misconfigured backend) used to leave this
        // screen stuck on "Checking your access..." forever with no
        // feedback. Now it surfaces an actual error instead.
        console.error("RoleGuard access check failed:", err);
        setState({ ready: true, user: null, denied: false });
        setFailure(err instanceof Error ? err.message : "Something went wrong while checking your access.");
      }
    };

    void sync();
    const onChange = () => void sync();
    window.addEventListener("cc-auth-change", onChange);
    const { data: authListener } = supabase.auth.onAuthStateChange(() => void sync());
    return () => {
      active = false;
      window.removeEventListener("cc-auth-change", onChange);
      authListener.subscription.unsubscribe();
    };
  }, [navigate, role]);

  if (failure) {
    return (
      <div className="auth-shell">
        <div className="auth-card" style={{ textAlign: "center" }}>
          <div style={{ fontSize: "2.4rem", color: "#dc2626" }}><i className="fas fa-triangle-exclamation" /></div>
          <h1>We couldn't verify your account</h1>
          <p className="sub">{failure}</p>
          <button type="button" className="btn btn-primary" onClick={() => window.location.reload()}>
            Try again
          </button>
        </div>
      </div>
    );
  }

  if (!state.ready || (!state.user && !state.denied)) {
    return (
      <div className="auth-shell">
        <div className="auth-card" style={{ textAlign: "center" }}>
          <p className="sub"><i className="fas fa-spinner fa-spin" /> Checking your access…</p>
        </div>
      </div>
    );
  }

  if (state.denied || (state.user && state.user.role !== role)) {
    const signedInRole = state.user?.role ?? "customer";
    return (
      <div className="auth-shell">
        <div className="auth-card" style={{ textAlign: "center" }}>
          <div style={{ fontSize: "2.4rem", color: "#dc2626" }}><i className="fas fa-ban" /></div>
          <h1>{role === "admin" ? "Administrator access required." : "403 — Access Denied"}</h1>
          <p className="sub">
            You're signed in as a {signedInRole}. This area is restricted to {role} accounts.
          </p>
          <Link to={dashboardPathFor(signedInRole)} className="btn btn-primary">
            Go to my dashboard
          </Link>
          <div className="auth-alt">
            <Link to="/auth/$role" params={{ role: "admin" }}>Administrator login</Link>
          </div>
        </div>
      </div>
    );
  }

  return <>{children}</>;
}
