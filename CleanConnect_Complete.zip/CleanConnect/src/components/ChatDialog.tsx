import { useEffect, useRef, useState } from "react";
import { sendBookingMessage, useBookingMessages } from "@/lib/messages";

export function ChatDialog({
  bookingId,
  recipientId,
  title,
  onClose,
}: {
  bookingId: string;
  recipientId: string;
  title: string;
  onClose: () => void;
}) {
  const { messages, loading, reload } = useBookingMessages(bookingId);
  const [draft, setDraft] = useState("");
  const [sending, setSending] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ block: "end" });
  }, [messages]);

  const send = async () => {
    if (!draft.trim()) return;
    setSending(true);
    setErr(null);
    const res = await sendBookingMessage(bookingId, recipientId, draft);
    setSending(false);
    if (!res.ok) return setErr(res.error);
    setDraft("");
    void reload();
  };

  return (
    <div className="cd-modal" role="dialog" aria-modal="true" aria-label={`Chat about ${title}`}>
      <div className="cd-modal-card" style={{ display: "flex", flexDirection: "column", maxHeight: "80vh" }}>
        <h2 style={{ marginBottom: 4 }}>{title}</h2>
        <p style={{ fontSize: ".78rem", color: "var(--muted-foreground)", margin: "0 0 12px" }}>
          Messages here are only about this booking — no personal contact details are shared.
        </p>

        <div style={{ flex: 1, overflowY: "auto", display: "flex", flexDirection: "column", gap: 8, minHeight: 200, padding: "4px 2px" }}>
          {loading ? (
            <p className="cd-sub">Loading…</p>
          ) : messages.length === 0 ? (
            <p className="cd-sub">No messages yet — say hello.</p>
          ) : (
            messages.map((m) => (
              <div
                key={m.id}
                style={{
                  alignSelf: m.mine ? "flex-end" : "flex-start",
                  background: m.mine ? "var(--primary, #2563eb)" : "var(--muted, #f1f5f9)",
                  color: m.mine ? "#fff" : "inherit",
                  borderRadius: 12,
                  padding: "8px 12px",
                  maxWidth: "80%",
                  fontSize: ".9rem",
                }}
              >
                {m.body}
                <div style={{ fontSize: ".68rem", opacity: 0.7, marginTop: 2 }}>
                  {new Date(m.createdAt).toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
                </div>
              </div>
            ))
          )}
          <div ref={bottomRef} />
        </div>

        {err && <p className="cd-error">{err}</p>}

        <div style={{ display: "flex", gap: 8, marginTop: 12 }}>
          <input
            value={draft}
            onChange={(e) => setDraft(e.target.value)}
            onKeyDown={(e) => e.key === "Enter" && !sending && void send()}
            placeholder="Type a message…"
            aria-label="Message"
            style={{ flex: 1 }}
          />
          <button type="button" className="pd-btn pd-btn-primary" disabled={sending} onClick={() => void send()}>
            Send
          </button>
        </div>
        <div className="cd-modal-actions" style={{ marginTop: 10 }}>
          <button type="button" className="pd-btn pd-btn-ghost" onClick={onClose}>
            Close
          </button>
        </div>
      </div>
    </div>
  );
}
