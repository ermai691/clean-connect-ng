/** Shared CleanConnect service catalogue (name, category, starting price, pricing model). */

// How a service scales with job size. "rooms" = bedrooms+bathrooms,
// "area" = square metres (+ optional severity for construction/renovation
// jobs), "guests" = event/venue capacity band, "loads" = laundry
// bags/loads, "fixed" = no size input, price is flat.
export type SizeUnit = "rooms" | "area" | "guests" | "loads" | "fixed";

/** How the service is sold.
 * - "direct": customer books online, price is calculated automatically, Paystack payment, then marketplace matching.
 * - "quote": customer must Request a Quote; CleanConnect prices and handles the job (never marketplace matching).
 * Server accepts only services with bookingMode === "direct". Anything else is rejected.
 */
export type BookingMode = "direct" | "quote";

export type CatalogService = {
  id: string;
  name: string;
  category: string;
  price: number; // base/starting price shown in listings
  icon: string;
  sizeUnit: SizeUnit;
  /** Authoritative sales channel. Server enforces this; client must never be trusted. */
  bookingMode: BookingMode;
};

export const SERVICE_CATALOG: CatalogService[] = [
  // --- Direct-booking ---
  { id: "house", name: "House Cleaning", category: "Home Cleaning", price: 15000, icon: "fa-house", sizeUnit: "rooms", bookingMode: "direct" },
  { id: "deep", name: "Deep Cleaning", category: "Home Cleaning", price: 35000, icon: "fa-spray-can-sparkles", sizeUnit: "rooms", bookingMode: "direct" },
  { id: "movein", name: "Move-in Cleaning", category: "Home Cleaning", price: 40000, icon: "fa-box-open", sizeUnit: "rooms", bookingMode: "direct" },
  { id: "moveout", name: "Move-out Cleaning", category: "Home Cleaning", price: 42000, icon: "fa-truck-ramp-box", sizeUnit: "rooms", bookingMode: "direct" },
  { id: "sofa", name: "Sofa Cleaning", category: "Home Cleaning", price: 20000, icon: "fa-couch", sizeUnit: "rooms", bookingMode: "direct" },
  { id: "airbnb", name: "Airbnb Cleaning", category: "Home Cleaning", price: 18000, icon: "fa-bed", sizeUnit: "rooms", bookingMode: "direct" },
  { id: "laundry", name: "Laundry & Ironing", category: "Laundry", price: 8000, icon: "fa-shirt", sizeUnit: "loads", bookingMode: "direct" },

  // --- Quotation-only ---
  { id: "postcon", name: "Post Construction", category: "Specialty", price: 60000, icon: "fa-helmet-safety", sizeUnit: "area", bookingMode: "quote" },
  { id: "postreno", name: "Post-Renovation Cleaning", category: "Specialty", price: 55000, icon: "fa-paint-roller", sizeUnit: "area", bookingMode: "quote" },
  { id: "fumigation", name: "Fumigation & Pest", category: "Specialty", price: 30000, icon: "fa-bug-slash", sizeUnit: "rooms", bookingMode: "quote" },
  { id: "commercial", name: "Commercial Cleaning", category: "Commercial", price: 50000, icon: "fa-city", sizeUnit: "area", bookingMode: "quote" },
  { id: "school", name: "School Cleaning", category: "Commercial", price: 55000, icon: "fa-school", sizeUnit: "area", bookingMode: "quote" },
  { id: "hospital", name: "Hospital Cleaning", category: "Commercial", price: 80000, icon: "fa-hospital", sizeUnit: "area", bookingMode: "quote" },
  { id: "warehouse", name: "Warehouse Cleaning", category: "Commercial", price: 90000, icon: "fa-warehouse", sizeUnit: "area", bookingMode: "quote" },
  { id: "event", name: "Event Cleanup", category: "Specialty", price: 45000, icon: "fa-champagne-glasses", sizeUnit: "guests", bookingMode: "quote" },
  { id: "office", name: "Office Cleaning", category: "Commercial", price: 25000, icon: "fa-building", sizeUnit: "area", bookingMode: "quote" },
  { id: "restaurant", name: "Restaurant Cleaning", category: "Commercial", price: 40000, icon: "fa-utensils", sizeUnit: "area", bookingMode: "quote" },
];

export const PACKAGES = [
  { id: "standard", name: "Standard", multiplier: 1 },
  { id: "premium", name: "Premium", multiplier: 1.4 },
  { id: "express", name: "Express", multiplier: 1.7 },
];

export const SEVERITY_LEVELS = [
  { id: "light", name: "Light mess", multiplier: 1 },
  { id: "moderate", name: "Moderate mess", multiplier: 1.3 },
  { id: "heavy", name: "Heavy mess", multiplier: 1.6 },
];

export function findService(idOrName?: string | null): CatalogService {
  const value = (idOrName ?? "").toLowerCase().trim();
  return (
    SERVICE_CATALOG.find((s) => s.id === value || s.name.toLowerCase() === value) ??
    SERVICE_CATALOG[0]!
  );
}

export function ngn(value: number) {
  return `₦${Math.round(value).toLocaleString("en-NG")}`;
}

/** Job size/scope details a customer fills in on the booking form. Shape
 * varies by the service's sizeUnit; unused fields are simply omitted. */
export type JobDetails = {
  bedrooms?: number;
  bathrooms?: number;
  areaSqm?: number;
  severity?: string; // SEVERITY_LEVELS id
  guests?: number;
  loads?: number;
};

const ROOM_RATE = { bedroomRate: 5000, bathroomRate: 3000 };
const AREA_RATE = { includedSqm: 50, perExtraSqm: 350 };
const GUEST_RATE = { includedGuests: 50, perExtraGuest: 400 };
const LOAD_RATE = 8000; // per load; laundry's base price already equals one load

/** Computes the pre-package-multiplier price for a service given job size details. */
export function estimateBasePrice(service: CatalogService, details: JobDetails): number {
  switch (service.sizeUnit) {
    case "rooms": {
      const bedrooms = Math.max(1, details.bedrooms ?? 1);
      const bathrooms = Math.max(0, details.bathrooms ?? 1);
      const extraBedrooms = bedrooms - 1;
      const extraBathrooms = Math.max(0, bathrooms - 1);
      return service.price + extraBedrooms * ROOM_RATE.bedroomRate + extraBathrooms * ROOM_RATE.bathroomRate;
    }
    case "area": {
      const sqm = Math.max(1, details.areaSqm ?? AREA_RATE.includedSqm);
      const extraSqm = Math.max(0, sqm - AREA_RATE.includedSqm);
      const severity = SEVERITY_LEVELS.find((s) => s.id === details.severity)?.multiplier ?? 1;
      const isConstructionLike = service.id === "postcon" || service.id === "postreno";
      const base = service.price + extraSqm * AREA_RATE.perExtraSqm;
      return isConstructionLike ? Math.round(base * severity) : base;
    }
    case "guests": {
      const guests = Math.max(1, details.guests ?? GUEST_RATE.includedGuests);
      const extraGuests = Math.max(0, guests - GUEST_RATE.includedGuests);
      return service.price + extraGuests * GUEST_RATE.perExtraGuest;
    }
    case "loads": {
      const loads = Math.max(1, details.loads ?? 1);
      return loads * LOAD_RATE;
    }
    case "fixed":
    default:
      return service.price;
  }
}

export type PriceLine = { label: string; amount: number };

/** Itemized version of estimateBasePrice, for showing customers why a price is what it is. */
export function estimateBreakdown(service: CatalogService, details: JobDetails): { lines: PriceLine[]; subtotal: number } {
  const lines: PriceLine[] = [];

  switch (service.sizeUnit) {
    case "rooms": {
      const bedrooms = Math.max(1, details.bedrooms ?? 1);
      const bathrooms = Math.max(0, details.bathrooms ?? 1);
      const extraBedrooms = bedrooms - 1;
      const extraBathrooms = Math.max(0, bathrooms - 1);
      lines.push({ label: `${service.name} (base, 1 bedroom)`, amount: service.price });
      if (extraBedrooms > 0) lines.push({ label: `${extraBedrooms} extra bedroom${extraBedrooms > 1 ? "s" : ""}`, amount: extraBedrooms * ROOM_RATE.bedroomRate });
      if (extraBathrooms > 0) lines.push({ label: `${extraBathrooms} extra bathroom${extraBathrooms > 1 ? "s" : ""}`, amount: extraBathrooms * ROOM_RATE.bathroomRate });
      break;
    }
    case "area": {
      const sqm = Math.max(1, details.areaSqm ?? AREA_RATE.includedSqm);
      const extraSqm = Math.max(0, sqm - AREA_RATE.includedSqm);
      const isConstructionLike = service.id === "postcon" || service.id === "postreno";
      const severityLevel = SEVERITY_LEVELS.find((s) => s.id === details.severity);
      const severity = severityLevel?.multiplier ?? 1;
      lines.push({ label: `${service.name} (base, up to ${AREA_RATE.includedSqm} sqm)`, amount: service.price });
      if (extraSqm > 0) lines.push({ label: `${extraSqm} extra sqm`, amount: extraSqm * AREA_RATE.perExtraSqm });
      if (isConstructionLike && severity !== 1 && severityLevel) {
        const preSeverity = service.price + extraSqm * AREA_RATE.perExtraSqm;
        lines.push({ label: `${severityLevel.name} (${Math.round((severity - 1) * 100)}% more)`, amount: Math.round(preSeverity * severity) - preSeverity });
      }
      break;
    }
    case "guests": {
      const guests = Math.max(1, details.guests ?? GUEST_RATE.includedGuests);
      const extraGuests = Math.max(0, guests - GUEST_RATE.includedGuests);
      lines.push({ label: `${service.name} (base, up to ${GUEST_RATE.includedGuests} guests)`, amount: service.price });
      if (extraGuests > 0) lines.push({ label: `${extraGuests} extra guests`, amount: extraGuests * GUEST_RATE.perExtraGuest });
      break;
    }
    case "loads": {
      const loads = Math.max(1, details.loads ?? 1);
      lines.push({ label: `${loads} load${loads > 1 ? "s" : ""} of laundry`, amount: loads * LOAD_RATE });
      break;
    }
    case "fixed":
    default:
      lines.push({ label: service.name, amount: service.price });
  }

  const subtotal = lines.reduce((sum, l) => sum + l.amount, 0);
  return { lines, subtotal };
}
