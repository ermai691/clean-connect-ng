// Framework-agnostic provider matching engine. Deliberately has zero
// TanStack imports so it can be called from:
//  - matching.functions.ts (TanStack server functions, client-callable RPC)
//  - netlify/functions/expire-assignments.ts (scheduled job)
//  - netlify/functions/paystack-webhook.ts (payment webhook)
// All three need the exact same logic, not three copies of it.
//
// `admin` below is any Supabase client with service-role access — typed
// loosely (not the generated Database type) so this file works identically
// whether the caller is TanStack's bundled client.server.ts or a plain
// @supabase/supabase-js client created directly in a Netlify Function.

type MatchWeights = { reliability: number; rating: number; proximity: number; experience: number };

export async function getSetting<T>(admin: any, key: string, fallback: T): Promise<T> {
  const { data } = await admin.from("platform_settings").select("value").eq("key", key).maybeSingle();
  return (data?.value as T) ?? fallback;
}

/** Scores one eligible provider. All sub-scores are 0..1; weighted sum is 0..1. */
export function scoreProvider(
  provider: {
    rating: number;
    review_count: number;
    completed_jobs: number;
    cancelled_jobs: number;
    no_show_count: number;
    assignments_accepted: number;
    assignments_declined: number;
    assignments_expired: number;
    city: string | null;
    state: string | null;
  },
  booking: { service_city: string | null; service_state: string | null },
  weights: MatchWeights,
): number {
  const incidents = provider.cancelled_jobs + provider.no_show_count;
  const hasJobHistory = provider.completed_jobs + incidents > 0;
  const completionRatio = hasJobHistory ? provider.completed_jobs / (provider.completed_jobs + incidents + 1) : 0.5;
  const responses = provider.assignments_accepted + provider.assignments_declined + provider.assignments_expired;
  const acceptRatio = responses === 0 ? 0.7 : provider.assignments_accepted / (responses + 1);
  const reliability = completionRatio * 0.6 + acceptRatio * 0.4;

  const rating = provider.review_count === 0 ? 0.7 : Math.max(0, Math.min(1, provider.rating / 5));

  let proximity = 0.2;
  if (booking.service_city && provider.city && booking.service_city.toLowerCase() === provider.city.toLowerCase()) {
    proximity = 1.0;
  } else if (booking.service_state && provider.state && booking.service_state.toLowerCase() === provider.state.toLowerCase()) {
    proximity = 0.6;
  }

  const experience = Math.max(0, Math.min(1, provider.completed_jobs / 20));

  return (
    reliability * weights.reliability +
    rating * weights.rating +
    proximity * weights.proximity +
    experience * weights.experience
  );
}

export type MatchResult =
  | { ok: true; assigned: true; providerId: string; score: number }
  | { ok: true; assigned: false; reason: string }
  | { ok: false; error: string };

/** Finds and offers the job to the best eligible provider. Only runs on
 * bookings that are actually in a matchable payment state — this function
 * must never be the thing that lets an unpaid booking get a provider. */

/** Required policies must be accepted at the current published version. */
async function providerHasRequiredPolicyAcceptances(admin: any, providerId: string): Promise<boolean> {
  const { data: required, error } = await admin
    .from("provider_policy_documents")
    .select("id, version")
    .eq("is_required", true);
  // If the policies table is not migrated yet, do not block all matching.
  if (error) {
    // Fail closed: never offer jobs if policy acceptance cannot be verified.
    console.error("policy check error — matching blocked for provider", providerId, error.message);
    return false;
  }
  if (!required?.length) return true;
  for (const pol of required) {
    const { data: acc } = await admin
      .from("provider_policy_acceptances")
      .select("id")
      .eq("provider_id", providerId)
      .eq("policy_id", pol.id)
      .eq("policy_version", pol.version)
      .maybeSingle();
    if (!acc) return false;
  }
  return true;
}

export async function findAndOfferProvider(admin: any, bookingId: string): Promise<MatchResult> {
  const { data: booking } = await admin.from("bookings").select("*").eq("id", bookingId).maybeSingle();
  if (!booking) return { ok: false, error: "Booking not found." };

  const matchableStatuses = ["paid", "finding_provider", "no_provider_available", "assignment_pending"];
  if (!matchableStatuses.includes(booking.status)) {
    return { ok: false, error: `Booking is not eligible for matching (status: ${booking.status}).` };
  }

  const { data: priorAttempts } = await admin
    .from("booking_assignments")
    .select("provider_id")
    .eq("booking_id", bookingId);
  const triedProviderIds = new Set((priorAttempts ?? []).map((a: any) => a.provider_id));

  const { data: candidates } = await admin
    .from("providers")
    .select("*")
    .eq("approval_status", "approved")
    .eq("verification_status", "verified")
    .eq("is_online", true)
    .contains("services", [booking.service]);

  const notTried = (candidates ?? []).filter((p: any) => !triedProviderIds.has(p.id));
  const eligible: any[] = [];
  for (const p of notTried) {
    // Suspended/rejected already excluded by approval_status=approved query.
    if (await providerHasRequiredPolicyAcceptances(admin, p.id)) eligible.push(p);
  }
  if (eligible.length === 0) {
    await admin.from("bookings").update({ status: "no_provider_available" }).eq("id", bookingId);
    return { ok: true, assigned: false, reason: "no_eligible_provider" };
  }

  const slotStart = new Date(booking.scheduled_for).getTime();
  const windowMs = 3 * 60 * 60 * 1000;
  const { data: activeBookings } = await admin
    .from("bookings")
    .select("provider_id, scheduled_for")
    .in("status", ["provider_accepted", "on_the_way", "in_progress"])
    .not("provider_id", "is", null);
  const busyProviderIds = new Set(
    (activeBookings ?? [])
      .filter((b: any) => Math.abs(new Date(b.scheduled_for).getTime() - slotStart) < windowMs)
      .map((b: any) => b.provider_id),
  );
  const available = eligible.filter((p: any) => !busyProviderIds.has(p.id));
  if (available.length === 0) {
    await admin.from("bookings").update({ status: "no_provider_available" }).eq("id", bookingId);
    return { ok: true, assigned: false, reason: "no_available_provider" };
  }

  const weights = await getSetting<MatchWeights>(admin, "match_weights", {
    reliability: 0.35, rating: 0.25, proximity: 0.25, experience: 0.15,
  });
  const responseWindowMinutes = await getSetting<number>(admin, "provider_response_window_minutes", 30);

  const ranked = available
    .map((p: any) => ({ provider: p, score: scoreProvider(p, booking, weights) }))
    .sort((a: { score: number }, b: { score: number }) => b.score - a.score);

  const best = ranked[0];
  const respondsBy = new Date(Date.now() + responseWindowMinutes * 60 * 1000).toISOString();

  // Relies on idx_one_pending_assignment_per_booking (unique partial index)
  // to guarantee no two concurrent calls for the same booking both succeed.
  const { error: assignError } = await admin.from("booking_assignments").insert({
    booking_id: bookingId,
    provider_id: best.provider.id,
    match_score: best.score,
    status: "pending",
    responds_by: respondsBy,
  });
  if (assignError) {
    // A unique-violation here means another concurrent call already created
    // the pending assignment for this booking — not a real failure.
    if (/duplicate key|unique constraint/i.test(assignError.message ?? "")) {
      return { ok: true, assigned: false, reason: "already_has_pending_assignment" };
    }
    return { ok: false, error: assignError.message };
  }

  await admin.from("bookings").update({ status: "assignment_pending" }).eq("id", bookingId);
  await admin.from("notifications").insert({
    user_id: best.provider.id,
    type: "assignment",
    title: "New CleanConnect booking offer",
    body: `${booking.service} · ${booking.scheduled_for} · Respond within ${responseWindowMinutes} minutes.`,
  });

  return { ok: true, assigned: true, providerId: best.provider.id, score: best.score };
}

/** Atomically expires every assignment whose response window has passed,
 * then re-triggers matching for each affected booking. The UPDATE...RETURNING
 * is a single statement, so two overlapping invocations (e.g. a manual
 * trigger firing during the scheduled sweep) cannot both "claim" the same
 * stale row — only one can win per row. */
export async function expireStaleAssignmentsCore(admin: any) {
  const nowIso = new Date().toISOString();

  const { data: expired, error } = await admin
    .from("booking_assignments")
    .update({ status: "expired" })
    .eq("status", "pending")
    .lt("responds_by", nowIso)
    .select("id, booking_id, provider_id");

  if (error) return { ok: false as const, error: error.message };

  const results: Array<{ bookingId: string; result: MatchResult }> = [];
  for (const a of expired ?? []) {
    const { data: provider } = await admin
      .from("providers")
      .select("assignments_expired")
      .eq("id", a.provider_id)
      .maybeSingle();
    await admin
      .from("providers")
      .update({ assignments_expired: (provider?.assignments_expired ?? 0) + 1 })
      .eq("id", a.provider_id);
    const result = await findAndOfferProvider(admin, a.booking_id);
    results.push({ bookingId: a.booking_id, result });
  }

  return { ok: true as const, processed: (expired ?? []).length, results };
}

/** Safety net for payments whose webhook never arrived (or arrived but
 * matching failed): finds bookings stuck in a "paid but nothing has
 * happened" state for more than a couple of minutes and retries matching.
 * Does NOT touch payment verification itself — that's the webhook's job —
 * this only catches a booking that's already 'paid' but has zero
 * assignment attempts, which should never normally happen but shouldn't be
 * allowed to silently rot if it does. */
export async function reconcileStuckPaidBookings(admin: any) {
  const staleThreshold = new Date(Date.now() - 2 * 60 * 1000).toISOString();
  const { data: stuck } = await admin
    .from("bookings")
    .select("id")
    .eq("status", "paid")
    .lt("created_at", staleThreshold);

  const results: Array<{ bookingId: string; result: MatchResult }> = [];
  for (const b of stuck ?? []) {
    const { data: hasAttempt } = await admin
      .from("booking_assignments")
      .select("id")
      .eq("booking_id", b.id)
      .limit(1)
      .maybeSingle();
    if (hasAttempt) continue; // already has an offer in flight or resolved
    const result = await findAndOfferProvider(admin, b.id);
    results.push({ bookingId: b.id, result });
  }
  return { ok: true as const, processed: results.length, results };
}
