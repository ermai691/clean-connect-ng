// Booking creation, moved server-side specifically so the price can never
// be supplied by the client. Before this, the frontend computed the price
// and the backend simply stored whatever number it was given — a customer
// could have bypassed the booking form entirely and inserted an arbitrary
// amount directly via the Supabase REST API, since the database's RLS
// policy only checked booking ownership, never the amount.

import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";
import { findService, PACKAGES, estimateBasePrice, type JobDetails } from "@/lib/service-catalog";

const jobDetailsSchema = z
  .object({
    bedrooms: z.number().optional(),
    bathrooms: z.number().optional(),
    areaSqm: z.number().optional(),
    severity: z.string().optional(),
    guests: z.number().optional(),
    loads: z.number().optional(),
  })
  .partial();

const inputSchema = z.object({
  serviceId: z.string(),
  packageId: z.string(),
  jobDetails: jobDetailsSchema,
  scheduledFor: z.string(),
  address: z.string().min(1),
  notes: z.string().optional(),
  method: z.string(),
});

export const createBookingServerSide = createServerFn({ method: "POST" })
  .inputValidator((input) => inputSchema.parse(input))
  .handler(async ({ data }) => {
    const authorization = getRequestHeader("Authorization");
    const token = authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
    if (!token) return { ok: false as const, error: "You must be signed in to book." };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: authData, error: authError } = await supabaseAdmin.auth.getUser(token);
    const user = authData.user;
    if (authError || !user) return { ok: false as const, error: "You must be signed in to book." };

    const service = findService(data.serviceId);

    // Authoritative sales-channel check. Never trust a mode sent by the browser.
    // Only services explicitly classified as "direct" may use ordinary online booking.
    // Quote, missing, or invalid classifications are all rejected.
    if (service.bookingMode !== "direct") {
      return {
        ok: false as const,
        error:
          "This service requires a quotation from CleanConnect. Please use Request a Quote instead of the online booking form.",
      };
    }

    const pkg = PACKAGES.find((p) => p.id === data.packageId) ?? PACKAGES[0]!;

    // The only authoritative price calculation in the system. The client
    // sends what size of job it is (bedrooms, sqm, etc) — never a price.
    const basePrice = estimateBasePrice(service, data.jobDetails as JobDetails);
    const amount = Math.round(basePrice * pkg.multiplier);

    const { data: booking, error } = await supabaseAdmin
      .from("bookings")
      .insert({
        customer_id: user.id,
        service: service.name,
        category: service.category,
        package: pkg.name,
        amount,
        scheduled_for: data.scheduledFor,
        address: data.address.trim(),
        notes: data.notes?.trim() || null,
        job_details: data.jobDetails as never,
        status: "payment_pending",
      })
      .select()
      .single();

    if (error || !booking) return { ok: false as const, error: error?.message ?? "Could not create booking." };

    await supabaseAdmin.from("bookings").update({ payment_reference: booking.reference }).eq("id", booking.id);

    await supabaseAdmin.from("payments").insert({
      booking_id: booking.id,
      customer_id: user.id,
      amount,
      method: data.method,
      status: "pending",
    });

    await supabaseAdmin.from("notifications").insert({
      user_id: user.id,
      type: "booking",
      title: "Booking received",
      body: `${service.name} · ${booking.reference} is awaiting payment.`,
    });

    return { ok: true as const, booking };
  });
