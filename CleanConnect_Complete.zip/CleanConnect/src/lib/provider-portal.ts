/** Provider portal helpers — withdrawals, support, policies, job actions. */

import { supabase } from "@/integrations/supabase/client";
import { updateBookingStatusAsProvider } from "@/lib/provider-data";

export async function providerStartJob(bookingId: string) {
  // Official workflow: Start Job moves booking to in_progress and records started_at.
  return updateBookingStatusAsProvider(bookingId, "in_progress");
}

export async function providerMarkInProgress(bookingId: string) {
  return updateBookingStatusAsProvider(bookingId, "in_progress");
}

export async function providerCompleteJob(bookingId: string) {
  return updateBookingStatusAsProvider(bookingId, "awaiting_confirmation");
}

export type WithdrawalRow = {
  id: string;
  amount: number;
  status: string;
  created_at: string;
  failure_reason: string | null;
};

export async function listProviderWithdrawals(): Promise<WithdrawalRow[]> {
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) return [];
  const { data } = await (supabase as any)
    .from("provider_withdrawals")
    .select("id, amount, status, created_at, failure_reason")
    .eq("provider_id", uid)
    .order("created_at", { ascending: false })
    .limit(50);
  return (data ?? []).map((r: any) => ({
    id: r.id,
    amount: Number(r.amount),
    status: r.status,
    created_at: r.created_at,
    failure_reason: r.failure_reason,
  }));
}

/** Creates a withdrawal request only. Actual Paystack Transfer requires server config.
 * Never marks a transfer successful from the client. */
export async function requestProviderWithdrawal(amountNaira: number) {
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) return { ok: false as const, error: "Not signed in." };
  const amount = Math.round(Number(amountNaira));
  if (!Number.isFinite(amount) || amount < 100) {
    return { ok: false as const, error: "Minimum withdrawal is ₦100." };
  }

  // Available balance from successful wallet ledger rows (same basis as dashboard).
  const { data: walletRows } = await supabase
    .from("wallet_transactions")
    .select("amount, status")
    .eq("user_id", uid);
  const available = (walletRows ?? [])
    .filter((w) => w.status === "successful")
    .reduce((t, w) => t + Number(w.amount), 0);

  // Subtract open withdrawal requests so providers cannot over-request.
  const { data: openWd } = await (supabase as any)
    .from("provider_withdrawals")
    .select("amount, status")
    .eq("provider_id", uid)
    .in("status", ["requested", "processing", "under_review"]);
  const reserved = (openWd ?? []).reduce((t: number, w: any) => t + Number(w.amount), 0);
  const spendable = available - reserved;
  if (amount > spendable) {
    return {
      ok: false as const,
      error: `Insufficient available balance. Spendable: ₦${Math.max(0, Math.round(spendable)).toLocaleString("en-NG")}.`,
    };
  }

  const { data, error } = await (supabase as any)
    .from("provider_withdrawals")
    .insert({
      provider_id: uid,
      amount,
      currency: "NGN",
      status: "requested",
      paystack_reference: `WD-${uid.slice(0, 8)}-${Date.now().toString(36).toUpperCase()}`,
    })
    .select("id, amount, status, created_at")
    .maybeSingle();

  if (error) {
    if (/unique|duplicate/i.test(error.message ?? "")) {
      return { ok: false as const, error: "You already have an open withdrawal request." };
    }
    return {
      ok: false as const,
      error: error.message.includes("does not exist")
        ? "Withdrawals are not available until the portal migration is applied on Supabase."
        : error.message,
    };
  }
  return { ok: true as const, withdrawal: data };
}

export async function listProviderSupportTickets() {
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) return [];
  const { data } = await (supabase as any)
    .from("provider_support_tickets")
    .select("id, category, subject, body, status, created_at")
    .eq("provider_id", uid)
    .order("created_at", { ascending: false })
    .limit(30);
  return data ?? [];
}

export async function createProviderSupportTicket(input: {
  category: string;
  subject: string;
  body: string;
}) {
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) return { ok: false as const, error: "Not signed in." };
  const { error } = await (supabase as any).from("provider_support_tickets").insert({
    provider_id: uid,
    category: input.category.trim(),
    subject: input.subject.trim(),
    body: input.body.trim(),
    status: "open",
  });
  if (error) {
    return {
      ok: false as const,
      error: error.message.includes("does not exist")
        ? "Support tickets require the portal migration on Supabase."
        : error.message,
    };
  }
  return { ok: true as const };
}

export async function listProviderPolicies() {
  const { data } = await (supabase as any)
    .from("provider_policy_documents")
    .select("id, slug, title, version, body, is_required, published_at")
    .order("published_at", { ascending: false });
  return data ?? [];
}

export async function acceptProviderPolicy(policyId: string, version: string) {
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) return { ok: false as const, error: "Not signed in." };
  const { error } = await (supabase as any).from("provider_policy_acceptances").upsert(
    {
      provider_id: uid,
      policy_id: policyId,
      policy_version: version,
      accepted_at: new Date().toISOString(),
    },
    { onConflict: "provider_id,policy_id,policy_version" },
  );
  if (error) {
    return {
      ok: false as const,
      error: error.message.includes("does not exist")
        ? "Policy acceptance requires the portal migration on Supabase."
        : error.message,
    };
  }
  return { ok: true as const };
}

export async function listProviderNotifications() {
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) return [];
  const { data } = await supabase
    .from("notifications")
    .select("id, type, title, body, read, created_at")
    .eq("user_id", uid)
    .order("created_at", { ascending: false })
    .limit(50);
  return data ?? [];
}

export async function markProviderNotificationRead(id: string) {
  const { error } = await supabase.from("notifications").update({ read: true }).eq("id", id);
  return error ? { ok: false as const, error: error.message } : { ok: true as const };
}

export async function markAllProviderNotificationsRead() {
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) return { ok: false as const, error: "Not signed in." };
  const { error } = await supabase
    .from("notifications")
    .update({ read: true })
    .eq("user_id", uid)
    .eq("read", false);
  return error ? { ok: false as const, error: error.message } : { ok: true as const };
}


export async function listMyPolicyAcceptances() {
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) return [];
  const { data } = await (supabase as any)
    .from("provider_policy_acceptances")
    .select("policy_id, policy_version, accepted_at")
    .eq("provider_id", uid);
  return data ?? [];
}
