// Real provider data layer — every read/write is scoped to the authenticated
// provider by RLS. Replaces the hardcoded STATS/PERFORMANCE/VERIFICATION/
// CHECKLIST constants that used to live in routes/provider.tsx.

import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import type { Booking, Payment, Review, WalletTx } from "@/lib/customer-data";

export type ProviderProfile = {
  id: string;
  business_name: string;
  contact_phone: string | null;
  contact_email: string | null;
  description: string | null;
  services: string[];
  coverage_area: string | null;
  city: string | null;
  state: string | null;
  verification_status: string;
  approval_status: string;
  verification_documents: unknown[];
  rating: number;
  review_count: number;
  is_online: boolean;
  created_at: string;
  updated_at: string;
};

export type ProviderData = {
  profile: ProviderProfile | null;
  bookings: Booking[];
  payments: Payment[];
  reviews: Review[];
  wallet: WalletTx[];
};

const EMPTY: ProviderData = { profile: null, bookings: [], payments: [], reviews: [], wallet: [] };

const ACTIVE_STATUSES: Booking["status"][] = [
  "assignment_pending",
  "provider_accepted",
  "on_the_way",
  "in_progress",
  "awaiting_confirmation",
];

export function useProviderData() {
  const [userId, setUserId] = useState<string | null>(null);
  const [data, setData] = useState<ProviderData>(EMPTY);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const topicRef = useRef(`provider-${Math.random().toString(36).slice(2)}`);

  const load = useCallback(async () => {
    setError(null);
    const { data: auth } = await supabase.auth.getUser();
    const uid = auth.user?.id ?? null;
    setUserId(uid);
    if (!uid) {
      setData(EMPTY);
      setLoading(false);
      return;
    }
    try {
      const [profile, bookings, reviews, wallet] = await Promise.all([
        supabase.from("providers").select("*").eq("id", uid).maybeSingle(),
        supabase.from("bookings").select("*").eq("provider_id", uid).order("scheduled_for", { ascending: true }),
        supabase.from("reviews").select("*").eq("provider_id", uid).order("created_at", { ascending: false }),
        supabase.from("wallet_transactions").select("*").eq("user_id", uid).order("created_at", { ascending: false }),
      ]);

      const bookingIds = (bookings.data ?? []).map((b) => b.id);
      const payments = bookingIds.length
        ? await supabase.from("payments").select("*").in("booking_id", bookingIds)
        : { data: [] as Payment[] };

      setData({
        profile: (profile.data as ProviderProfile | null) ?? null,
        bookings: (bookings.data ?? []) as Booking[],
        payments: (payments.data ?? []) as Payment[],
        reviews: (reviews.data ?? []) as Review[],
        wallet: (wallet.data ?? []) as WalletTx[],
      });
    } catch (e) {
      setError(e instanceof Error ? e.message : "Something went wrong.");
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    if (!userId) return;
    const channel = supabase
      .channel(`${topicRef.current}-${userId}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "bookings" }, () => void load())
      .on("postgres_changes", { event: "*", schema: "public", table: "reviews" }, () => void load())
      .on("postgres_changes", { event: "*", schema: "public", table: "providers" }, () => void load())
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [userId, load]);

  return { userId, data, loading, error, reload: load };
}

/* --------------------------- derived stats --------------------------- */

function startOfDay(d = new Date()) {
  const x = new Date(d);
  x.setHours(0, 0, 0, 0);
  return x;
}
function startOfMonth(d = new Date()) {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}
function startOfYear(d = new Date()) {
  return new Date(d.getFullYear(), 0, 1);
}

export function providerStats(d: ProviderData) {
  const completed = d.bookings.filter((b) => b.status === "completed");
  const activeRequests = d.bookings.filter((b) => ACTIVE_STATUSES.includes(b.status));
  const successfulPayments = d.payments.filter((p) => p.status === "successful");
  const sumSince = (since: Date) =>
    successfulPayments
      .filter((p) => new Date(p.created_at) >= since)
      .reduce((t, p) => t + Number(p.amount), 0);

  const walletBalance = d.wallet.reduce((t, w) => (w.status === "successful" ? t + Number(w.amount) : t), 0);
  const uniqueCustomers = new Set(d.bookings.map((b) => b.customer_id)).size;

  return {
    // Superseded by usePendingOffers() (booking_assignments-based) now that
    // jobs are matched/offered rather than browsed. Kept at 0 here rather
    // than removed, so existing UI reading this field doesn't break.
    availableRequests: 0,
    jobsCompleted: completed.length,
    todayEarnings: sumSince(startOfDay()),
    monthlyEarnings: sumSince(startOfMonth()),
    yearlyEarnings: sumSince(startOfYear()),
    weeklyEarnings: sumSince(new Date(Date.now() - 7 * 86400000)),
    walletBalance,
    averageRating: d.profile?.rating ?? 0,
    reviewCount: d.profile?.review_count ?? 0,
    totalCustomers: uniqueCustomers,
    totalBookings: d.bookings.length,
    completionRatePct: d.bookings.length ? Math.round((completed.length / d.bookings.length) * 100) : 0,
    cancellationRatePct: d.bookings.length
      ? Math.round((d.bookings.filter((b) => b.status === "cancelled" || b.status === "rejected").length / d.bookings.length) * 100)
      : 0,
    acceptedRatePct: d.bookings.length
      ? Math.round(
          (d.bookings.filter((b) => b.status !== "cancelled" && b.status !== "rejected").length / d.bookings.length) * 100,
        )
      : 0,
    satisfactionPct: d.profile?.rating ? Math.round((d.profile.rating / 5) * 100) : 0,
  };
}

export function profileCompletionPct(p: ProviderProfile | null) {
  if (!p) return 0;
  const checks = [
    !!p.business_name,
    !!p.description && p.description.length >= 20,
    p.services.length > 0,
    !!p.contact_phone,
    !!p.coverage_area,
    p.verification_status === "verified",
  ];
  return Math.round((checks.filter(Boolean).length / checks.length) * 100);
}

/* --------------------------- mutations --------------------------- */

export async function setProviderOnline(online: boolean) {
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) return { ok: false as const, error: "Not signed in." };
  const { error } = await supabase.from("providers").update({ is_online: online }).eq("id", uid);
  return error ? { ok: false as const, error: error.message } : { ok: true as const };
}

export async function updateProviderProfile(patch: Partial<Pick<ProviderProfile,
  "business_name" | "contact_phone" | "description" | "services" | "coverage_area" | "city" | "state">>) {
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) return { ok: false as const, error: "Not signed in." };
  const { error } = await supabase.from("providers").update(patch).eq("id", uid);
  return error ? { ok: false as const, error: error.message } : { ok: true as const };
}

/** Providers may only move a booking through their side of the lifecycle.
 * Marking a job "done" transitions to awaiting_confirmation (not a bare
 * completed) so the customer gets their confirm/dispute window before
 * payout eligibility — see platform_settings.completion_confirm_window_hours. */
export async function updateBookingStatusAsProvider(
  bookingId: string,
  status: Extract<Booking["status"], "on_the_way" | "in_progress" | "awaiting_confirmation">,
) {
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) return { ok: false as const, error: "Not signed in." };

  const { data: booking } = await supabase
    .from("bookings")
    .select("id, provider_id, status")
    .eq("id", bookingId)
    .maybeSingle();

  if (!booking) return { ok: false as const, error: "Booking not found." };
  if (booking.provider_id !== uid) {
    return { ok: false as const, error: "This booking is not assigned to you." };
  }

  const allowedFrom: Record<string, string[]> = {
    on_the_way: ["provider_accepted"],
    in_progress: ["provider_accepted", "on_the_way"],
    awaiting_confirmation: ["in_progress"],
  };
  const okFrom = allowedFrom[status] ?? [];
  if (!okFrom.includes(booking.status)) {
    return {
      ok: false as const,
      error: `Cannot move from ${booking.status} to ${status}.`,
    };
  }

  if (status === "awaiting_confirmation") {
    // 5-minute admin escalation window (minutes setting). NOT automatic payment.
    let minutes = 5;
    const { data: minSetting } = await supabase
      .from("platform_settings")
      .select("value")
      .eq("key", "completion_confirm_window_minutes")
      .maybeSingle();
    if (minSetting?.value != null) {
      const n = Number(minSetting.value);
      if (Number.isFinite(n) && n > 0) minutes = n;
    } else {
      const { data: hourSetting } = await supabase
        .from("platform_settings")
        .select("value")
        .eq("key", "completion_confirm_window_hours")
        .maybeSingle();
      const h = Number(hourSetting?.value);
      if (Number.isFinite(h) && h > 0) minutes = h * 60;
    }
    const confirmDeadline = new Date(Date.now() + minutes * 60 * 1000).toISOString();
    const { data: updated, error } = await supabase
      .from("bookings")
      .update({
        status,
        completed_at: new Date().toISOString(),
        confirm_deadline: confirmDeadline,
      } as any)
      .eq("id", bookingId)
      .eq("provider_id", uid)
      .in("status", okFrom)
      .select("id, customer_id, reference, service")
      .maybeSingle();
    if (error) return { ok: false as const, error: error.message };
    if (!updated) return { ok: false as const, error: "Update failed — status may have already changed." };

    // Notify customer (confirm / dispute) — earnings stay held
    if ((updated as any).customer_id) {
      await supabase.from("notifications").insert({
        user_id: (updated as any).customer_id,
        type: "booking",
        title: "Please confirm your cleaning job",
        body: `${(updated as any).service} · ${(updated as any).reference}: Your provider marked the job complete. Please confirm or report a problem in My Bookings. Earnings are not released until you or CleanConnect confirm.`,
      });
    }
    // Best-effort immediate admin heads-up (escalation cron still fires after deadline)
    try {
      const { data: admins } = await supabase.from("user_roles").select("user_id").eq("role", "admin");
      const adminIds = [...new Set((admins ?? []).map((a: any) => a.user_id).filter(Boolean))];
      if (adminIds.length) {
        await supabase.from("notifications").insert(
          adminIds.map((adminId) => ({
            user_id: adminId,
            type: "booking",
            title: "Provider marked job completed",
            body: `${(updated as any).service} · ${(updated as any).reference}: customer confirmation pending. Escalation after confirm_deadline if still open.`,
          })),
        );
      }
    } catch (e) {
      console.error("admin notify on complete failed", e);
    }
    return { ok: true as const };
  }

  if (status === "in_progress") {
    const { data: updated, error } = await supabase
      .from("bookings")
      .update({ status, started_at: new Date().toISOString() } as any)
      .eq("id", bookingId)
      .eq("provider_id", uid)
      .in("status", okFrom)
      .select("id")
      .maybeSingle();
    if (error) return { ok: false as const, error: error.message };
    if (!updated) return { ok: false as const, error: "Update failed — status may have already changed." };
    return { ok: true as const };
  }

  const { data: updated, error } = await supabase
    .from("bookings")
    .update({ status })
    .eq("id", bookingId)
    .eq("provider_id", uid)
    .in("status", okFrom)
    .select("id")
    .maybeSingle();
  if (error) return { ok: false as const, error: error.message };
  if (!updated) return { ok: false as const, error: "Update failed — status may have already changed." };
  return { ok: true as const };
}
