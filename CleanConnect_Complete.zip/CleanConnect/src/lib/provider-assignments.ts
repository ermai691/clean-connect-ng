import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { respondToAssignment as respondToAssignmentFn } from "@/lib/matching.functions";

export type PendingOffer = {
  id: string;
  bookingId: string;
  service: string;
  category: string;
  amount: number;
  scheduledFor: string;
  address: string;
  respondsBy: string;
};

export function usePendingOffers() {
  const [offers, setOffers] = useState<PendingOffer[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const { data: auth } = await supabase.auth.getUser();
    const uid = auth.user?.id;
    if (!uid) {
      setOffers([]);
      setLoading(false);
      return;
    }
    const { data } = await supabase
      .from("booking_assignments")
      .select("id, booking_id, responds_by, bookings(service, category, amount, scheduled_for, address)")
      .eq("provider_id", uid)
      .eq("status", "pending")
      .order("offered_at", { ascending: true });

    const now = Date.now();
    const live = (data ?? [])
      .filter((a: any) => new Date(a.responds_by).getTime() > now)
      .map((a: any) => ({
        id: a.id,
        bookingId: a.booking_id,
        service: a.bookings?.service ?? "Service",
        category: a.bookings?.category ?? "",
        amount: Number(a.bookings?.amount ?? 0),
        scheduledFor: a.bookings?.scheduled_for ?? "",
        address: a.bookings?.address ?? "",
        respondsBy: a.responds_by,
      }));
    setOffers(live);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
    const channel = supabase
      .channel(`provider-offers-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "booking_assignments" }, () => void load())
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [load]);

  return { offers, loading, reload: load };
}

export async function respondToOffer(assignmentId: string, decision: "accept" | "decline") {
  try {
    const res = await respondToAssignmentFn({ data: { assignmentId, decision } });
    return res;
  } catch (err) {
    return { ok: false as const, error: err instanceof Error ? err.message : "Something went wrong." };
  }
}
