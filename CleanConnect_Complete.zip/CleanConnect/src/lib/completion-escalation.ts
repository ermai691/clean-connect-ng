/**
 * Framework-agnostic: 5-minute admin escalation after provider marks complete.
 * Safe to call from Netlify scheduled functions. Does NOT auto-confirm or pay.
 */
export async function escalateOverdueConfirmations(admin: any): Promise<{
  ok: boolean;
  processed: number;
  error?: string;
}> {
  const nowIso = new Date().toISOString();

  // Claim rows atomically: only first updater wins (escalation_notified_at null -> set).
  const { data: claimed, error } = await admin
    .from("bookings")
    .update({ escalation_notified_at: nowIso })
    .eq("status", "awaiting_confirmation")
    .is("escalation_notified_at", null)
    .lt("confirm_deadline", nowIso)
    .select("id, reference, service, customer_id, provider_id, completed_at, confirm_deadline");

  if (error) {
    console.error("escalateOverdueConfirmations:", error.message);
    return { ok: false, processed: 0, error: error.message };
  }

  const rows = claimed ?? [];
  if (rows.length === 0) return { ok: true, processed: 0 };

  const { data: admins, error: adminErr } = await admin
    .from("user_roles")
    .select("user_id")
    .eq("role", "admin");

  if (adminErr) {
    console.error("escalateOverdueConfirmations: admin list failed", adminErr.message);
    // Rows already claimed — log so ops can still see them in Pending Confirmation UI
    return { ok: false, processed: rows.length, error: adminErr.message };
  }

  const adminIds = [...new Set((admins ?? []).map((a: any) => a.user_id).filter(Boolean))];
  if (adminIds.length === 0) {
    console.error("escalateOverdueConfirmations: no admin users in user_roles");
    return { ok: true, processed: rows.length };
  }

  const notifications: any[] = [];
  for (const b of rows) {
    const body = `${b.service} · ${b.reference}: customer has not confirmed within the escalation window. Contact the customer. Do NOT auto-pay. Booking stays awaiting_confirmation until customer or admin confirms.`;
    for (const adminId of adminIds) {
      notifications.push({
        user_id: adminId,
        type: "escalation",
        title: "Pending completion confirmation",
        body,
      });
    }
  }

  if (notifications.length > 0) {
    const { error: nErr } = await admin.from("notifications").insert(notifications);
    if (nErr) {
      console.error("escalateOverdueConfirmations: notify failed", nErr.message);
      return { ok: false, processed: rows.length, error: nErr.message };
    }
  }

  console.log(`escalateOverdueConfirmations: notified admins about ${rows.length} booking(s)`);
  return { ok: true, processed: rows.length };
}
