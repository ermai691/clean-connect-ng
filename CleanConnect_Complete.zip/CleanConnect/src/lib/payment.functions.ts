// NOTE: written against Paystack's documented /transaction/initialize
// contract but not yet exercised against a real Paystack account — no
// credentials have been provided. Unverified until tested in test mode.

import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";

export const initializePaystackPayment = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ bookingId: z.string().uuid(), callbackUrl: z.string().url() }).parse(input))
  .handler(async ({ data }) => {
    const authorization = getRequestHeader("Authorization");
    const token = authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
    if (!token) return { ok: false as const, error: "You must be signed in." };

    const secretKey = process.env.PAYSTACK_SECRET_KEY;
    if (!secretKey) {
      return {
        ok: false as const,
        error: "Online payment isn't configured yet. Please contact support to complete this booking.",
      };
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: authData, error: authError } = await supabaseAdmin.auth.getUser(token);
    const user = authData.user;
    if (authError || !user) return { ok: false as const, error: "You must be signed in." };

    // The authoritative amount comes from the booking row we created
    // server-side earlier, never from anything the client sends here.
    const { data: booking } = await supabaseAdmin
      .from("bookings")
      .select("id, amount, customer_id, payment_reference, status")
      .eq("id", data.bookingId)
      .maybeSingle();

    if (!booking) return { ok: false as const, error: "Booking not found." };
    if (booking.customer_id !== user.id) return { ok: false as const, error: "This booking isn't yours." };
    if (booking.status !== "payment_pending") {
      return { ok: false as const, error: `This booking is not awaiting payment (status: ${booking.status}).` };
    }
    if (!booking.payment_reference) {
      return { ok: false as const, error: "Booking is missing a payment reference." };
    }

    const res = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${secretKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: user.email,
        amount: Math.round(Number(booking.amount) * 100), // naira -> kobo
        currency: "NGN",
        reference: booking.payment_reference,
        callback_url: data.callbackUrl,
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      console.error("Paystack initialize failed:", res.status, text);
      return { ok: false as const, error: "Could not start payment. Please try again." };
    }

    const body = await res.json();
    if (!body?.status || !body?.data?.authorization_url) {
      return { ok: false as const, error: "Paystack did not return a checkout link." };
    }

    return { ok: true as const, authorizationUrl: body.data.authorization_url as string };
  });
