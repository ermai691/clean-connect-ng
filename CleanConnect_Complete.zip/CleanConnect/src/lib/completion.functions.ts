/**
 * Customer/admin completion confirmation, disputes, and one-shot earnings release.
 * Provider "complete" never releases money.
 */
import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";

async function requireUser() {
  const authorization = getRequestHeader("Authorization");
  const token = authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) return { ok: false as const, error: "You must be signed in." };
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data, error } = await supabaseAdmin.auth.getUser(token);
  if (error || !data.user) return { ok: false as const, error: "You must be signed in." };
  return { ok: true as const, user: data.user, supabaseAdmin };
}

async function getCommissionNgn(admin: any): Promise<number> {
  const { data } = await admin
    .from("platform_settings")
    .select("value")
    .eq("key", "commission_flat_ngn")
    .maybeSingle();
  const raw = data?.value;
  const n = typeof raw === "number" ? raw : Number(typeof raw === "string" ? raw : JSON.stringify(raw)?.replace(/"/g, ""));
  return Number.isFinite(n) && n >= 0 ? n : 5000;
}

/** Exactly-once payout row + wallet credit. Not a bank transfer. */
export async function releaseProviderEarningsOnce(admin: any, bookingId: string) {
  const { data: booking } = await admin
    .from("bookings")
    .select("id, amount, provider_id, status, reference, service")
    .eq("id", bookingId)
    .maybeSingle();

  if (!booking) return { ok: false as const, error: "Booking not found." };
  if (!booking.provider_id) return { ok: false as const, error: "No provider assigned." };
  if (booking.status === "disputed") {
    return { ok: false as const, error: "Disputed bookings cannot release earnings." };
  }
  if (booking.status === "payment_pending" || booking.status === "cancelled" || booking.status === "rejected") {
    return { ok: false as const, error: "Booking is not eligible for earnings release." };
  }
  // Caller must move to confirmed_complete first (customer, admin phone, or dispute outcome A).
  if (!["confirmed_complete", "payout_released"].includes(booking.status)) {
    return { ok: false as const, error: `Booking status ${booking.status} is not confirmed for payout.` };
  }

  const { data: existing } = await admin.from("payouts").select("id").eq("booking_id", bookingId).maybeSingle();
  if (existing) return { ok: true as const, payoutId: existing.id as string };

  const gross = Number(booking.amount) || 0;
  const commission = await getCommissionNgn(admin);
  const payoutAmount = Math.max(0, Math.round((gross - commission) * 100) / 100);

  const { data: payout, error: pErr } = await admin
    .from("payouts")
    .insert({
      booking_id: bookingId,
      provider_id: booking.provider_id,
      gross_amount: gross,
      commission_amount: commission,
      payout_amount: payoutAmount,
      status: "released",
      released_at: new Date().toISOString(),
    })
    .select("id")
    .maybeSingle();

  if (pErr) {
    if (/duplicate|unique/i.test(pErr.message ?? "")) {
      const { data: again } = await admin.from("payouts").select("id").eq("booking_id", bookingId).maybeSingle();
      if (again) return { ok: true as const, payoutId: again.id as string };
    }
    return { ok: false as const, error: pErr.message };
  }

  await admin.from("wallet_transactions").insert({
    user_id: booking.provider_id,
    description: `Earnings · ${booking.reference || bookingId} (gross ₦${gross} − commission ₦${commission})`,
    amount: payoutAmount,
    status: "successful",
  });

  await admin
    .from("bookings")
    .update({ status: "payout_released" })
    .eq("id", bookingId)
    .in("status", ["confirmed_complete", "awaiting_confirmation"]);

  await admin.from("notifications").insert({
    user_id: booking.provider_id,
    type: "earnings",
    title: "Earnings available in wallet",
    body: `${booking.service} · ${booking.reference}: ₦${payoutAmount.toLocaleString("en-NG")} is available to request as a withdrawal. This is not an automatic bank transfer.`,
  });

  return { ok: true as const, payoutId: payout.id as string };
}

export const customerConfirmCompletion = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ bookingId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const auth = await requireUser();
    if (!auth.ok) return auth;
    const { user, supabaseAdmin: admin } = auth;

    const { data: booking } = await admin
      .from("bookings")
      .select("id, customer_id, status, provider_id, reference, service")
      .eq("id", data.bookingId)
      .maybeSingle();

    if (!booking) return { ok: false as const, error: "Booking not found." };
    if (booking.customer_id !== user.id) return { ok: false as const, error: "This booking is not yours." };
    if (booking.status !== "awaiting_confirmation") {
      return { ok: false as const, error: `Not awaiting confirmation (${booking.status}).` };
    }

    const { data: updated, error } = await admin
      .from("bookings")
      .update({
        status: "confirmed_complete",
        confirmed_at: new Date().toISOString(),
        confirmed_by: user.id,
        confirmation_source: "customer",
      } as any)
      .eq("id", booking.id)
      .eq("status", "awaiting_confirmation")
      .select("id")
      .maybeSingle();

    if (error) return { ok: false as const, error: error.message };
    if (!updated) return { ok: false as const, error: "Already confirmed or status changed." };

    const release = await releaseProviderEarningsOnce(admin, booking.id);
    if (!release.ok) return { ok: false as const, error: `Confirmed, but earnings release failed: ${release.error}` };

    if (booking.provider_id) {
      await admin.from("notifications").insert({
        user_id: booking.provider_id,
        type: "booking",
        title: "Customer confirmed completion",
        body: `${booking.service} · ${booking.reference}: customer confirmed the job was completed.`,
      });
    }
    return { ok: true as const };
  });

export const customerDisputeCompletion = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z.object({ bookingId: z.string().uuid(), reason: z.string().trim().min(3).max(2000) }).parse(input),
  )
  .handler(async ({ data }) => {
    const auth = await requireUser();
    if (!auth.ok) return auth;
    const { user, supabaseAdmin: admin } = auth;

    const { data: booking } = await admin
      .from("bookings")
      .select("id, customer_id, status")
      .eq("id", data.bookingId)
      .maybeSingle();

    if (!booking) return { ok: false as const, error: "Booking not found." };
    if (booking.customer_id !== user.id) return { ok: false as const, error: "This booking is not yours." };
    if (booking.status !== "awaiting_confirmation") {
      return { ok: false as const, error: "Only jobs awaiting confirmation can be disputed here." };
    }

    const { data: updated, error } = await admin
      .from("bookings")
      .update({ status: "disputed" })
      .eq("id", booking.id)
      .eq("status", "awaiting_confirmation")
      .select("id")
      .maybeSingle();

    if (error) return { ok: false as const, error: error.message };
    if (!updated) return { ok: false as const, error: "Could not open dispute." };

    await admin.from("disputes").upsert(
      {
        booking_id: booking.id,
        customer_id: user.id,
        reason: data.reason,
        status: "open",
      },
      { onConflict: "booking_id" },
    );

    return { ok: true as const };
  });

export const adminConfirmCompletionByPhone = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z.object({ bookingId: z.string().uuid(), note: z.string().trim().max(2000).optional() }).parse(input),
  )
  .handler(async ({ data }) => {
    const auth = await requireUser();
    if (!auth.ok) return auth;
    const { user, supabaseAdmin: admin } = auth;

    const { data: isAdmin } = await admin.rpc("has_role", { _user_id: user.id, _role: "admin" });
    if (!isAdmin) return { ok: false as const, error: "Admin only." };

    const { data: booking } = await admin
      .from("bookings")
      .select("id, status, customer_id, provider_id, reference, service")
      .eq("id", data.bookingId)
      .maybeSingle();

    if (!booking) return { ok: false as const, error: "Booking not found." };
    if (booking.status === "disputed") {
      return { ok: false as const, error: "Resolve the dispute before confirming completion." };
    }
    if (booking.status !== "awaiting_confirmation") {
      return { ok: false as const, error: `Not awaiting confirmation (${booking.status}).` };
    }

    const { data: updated, error } = await admin
      .from("bookings")
      .update({
        status: "confirmed_complete",
        confirmed_at: new Date().toISOString(),
        confirmed_by: user.id,
        confirmation_source: "admin_phone",
        admin_confirm_note: data.note?.trim() || null,
      } as any)
      .eq("id", booking.id)
      .eq("status", "awaiting_confirmation")
      .select("id")
      .maybeSingle();

    if (error) return { ok: false as const, error: error.message };
    if (!updated) return { ok: false as const, error: "Already confirmed or status changed." };

    const release = await releaseProviderEarningsOnce(admin, booking.id);
    if (!release.ok) return { ok: false as const, error: `Confirmed, but earnings release failed: ${release.error}` };

    const notes: any[] = [
      {
        user_id: booking.customer_id,
        type: "booking",
        title: "Completion confirmed by CleanConnect",
        body: `${booking.service} · ${booking.reference}: admin confirmed completion after verification.`,
      },
    ];
    if (booking.provider_id) {
      notes.push({
        user_id: booking.provider_id,
        type: "booking",
        title: "Completion confirmed by CleanConnect",
        body: `${booking.service} · ${booking.reference}: earnings follow wallet rules (not an automatic bank transfer).`,
      });
    }
    await admin.from("notifications").insert(notes);
    return { ok: true as const };
  });


export const adminResolveDispute = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z
      .object({
        bookingId: z.string().uuid(),
        decision: z.enum(["provider_entitled", "provider_not_entitled"]),
        resolution: z.string().trim().min(3).max(4000),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const auth = await requireUser();
    if (!auth.ok) return auth;
    const { user, supabaseAdmin: admin } = auth;

    const { data: isAdmin } = await admin.rpc("has_role", { _user_id: user.id, _role: "admin" });
    if (!isAdmin) return { ok: false as const, error: "Admin only." };

    const { data: booking } = await admin
      .from("bookings")
      .select("id, status, customer_id, provider_id, reference, service")
      .eq("id", data.bookingId)
      .maybeSingle();

    if (!booking) return { ok: false as const, error: "Booking not found." };
    if (booking.status !== "disputed") {
      return { ok: false as const, error: `Booking is not disputed (status: ${booking.status}).` };
    }

    const { data: dispute } = await admin
      .from("disputes")
      .select("id, status")
      .eq("booking_id", booking.id)
      .maybeSingle();

    if (!dispute) return { ok: false as const, error: "No dispute record for this booking." };
    if (dispute.status === "resolved") {
      return { ok: false as const, error: "This dispute is already resolved." };
    }

    const { data: resolved, error: dErr } = await admin
      .from("disputes")
      .update({
        status: "resolved",
        resolution: `${data.decision}: ${data.resolution}`,
        resolved_by: user.id,
        resolved_at: new Date().toISOString(),
      })
      .eq("id", dispute.id)
      .eq("status", "open")
      .select("id")
      .maybeSingle();

    if (dErr) return { ok: false as const, error: dErr.message };
    if (!resolved) return { ok: false as const, error: "Dispute could not be resolved (maybe already resolved)." };

    if (data.decision === "provider_entitled") {
      const { data: confirmed, error: bErr } = await admin
        .from("bookings")
        .update({
          status: "confirmed_complete",
          confirmed_at: new Date().toISOString(),
          confirmed_by: user.id,
          confirmation_source: "admin_phone",
          admin_confirm_note: data.resolution,
        } as any)
        .eq("id", booking.id)
        .eq("status", "disputed")
        .select("id")
        .maybeSingle();

      if (bErr) return { ok: false as const, error: bErr.message };
      if (!confirmed) return { ok: false as const, error: "Booking status changed during resolution." };

      const release = await releaseProviderEarningsOnce(admin, booking.id);
      if (!release.ok) {
        return { ok: false as const, error: `Dispute resolved for provider, but earnings release failed: ${release.error}` };
      }
    } else {
      // Provider not entitled — leave earnings withheld; booking stays disputed/cancelled-like
      await admin
        .from("bookings")
        .update({
          admin_confirm_note: `Dispute upheld (no provider payout): ${data.resolution}`,
        } as any)
        .eq("id", booking.id)
        .eq("status", "disputed");
    }

    const notes: any[] = [
      {
        user_id: booking.customer_id,
        type: "dispute",
        title: "Dispute resolution",
        body: `${booking.service} · ${booking.reference}: ${data.decision === "provider_entitled" ? "Resolved in favour of provider completion." : "Your dispute was upheld; provider earnings were not released."} ${data.resolution}`,
      },
    ];
    if (booking.provider_id) {
      notes.push({
        user_id: booking.provider_id,
        type: "dispute",
        title: "Dispute resolution",
        body: `${booking.service} · ${booking.reference}: ${data.decision === "provider_entitled" ? "Admin found the job completed satisfactorily. Wallet earnings follow normal rules (not a bank transfer)." : "Admin upheld the customer dispute. No earnings were released for this booking."}`,
      });
    }
    await admin.from("notifications").insert(notes);
    return { ok: true as const, decision: data.decision };
  });
