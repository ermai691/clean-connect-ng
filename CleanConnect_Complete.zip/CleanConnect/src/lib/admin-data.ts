// Real admin data layer. Field names deliberately mirror the old
// platform-data.ts shapes (customerName, scheduledFor, createdAt, etc.) so
// routes/admin.tsx's JSX needed minimal changes — only the import and hook
// name changed, not the markup.

import { useCallback, useEffect, useRef, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type AdminBookingStatus =
  | "payment_pending" | "paid" | "finding_provider" | "no_provider_available"
  | "assignment_pending" | "provider_accepted" | "on_the_way" | "in_progress"
  | "completed" | "awaiting_confirmation" | "confirmed_complete" | "disputed"
  | "payout_released" | "cancelled" | "rejected";

export type Booking = {
  id: string;
  reference: string;
  customerName: string;
  providerName: string | null;
  service: string;
  category: string;
  amount: number;
  scheduledFor: string;
  createdAt: string;
  status: AdminBookingStatus;
};

export type AdminProvider = {
  id: string;
  name: string;
  email: string;
  status: "pending" | "approved" | "rejected";
  services: string[];
  location: string;
  rating: number;
  verified: boolean;
};

export type AdminCustomer = { id: string; name: string; email: string; status: "active" };

export type AdminReview = {
  id: string;
  customerName: string;
  providerName: string;
  service: string;
  rating: number;
  comment: string;
};

export type AdminActivity = { id: string; title: string; detail?: string; createdAt: string };

export type AdminPayment = {
  id: string;
  bookingReference: string;
  customerName: string;
  amount: number;
  method: string;
  status: string;
  createdAt: string;
};

export type AdminData = {
  bookings: Booking[];
  providers: AdminProvider[];
  customers: AdminCustomer[];
  reviews: AdminReview[];
  activity: AdminActivity[];
  payments: AdminPayment[];
  unreadMessages: number;
  unreadNotifications: number;
};

const EMPTY: AdminData = {
  bookings: [], providers: [], customers: [], reviews: [], activity: [], payments: [],
  unreadMessages: 0, unreadNotifications: 0,
};

export function useAdminData() {
  const [data, setData] = useState<AdminData>(EMPTY);
  const [loading, setLoading] = useState(true);
  const topic = useRef(`admin-${Math.random().toString(36).slice(2)}`);

  const load = useCallback(async () => {
    const [profilesRes, providersRes, bookingsRes, reviewsRes, messagesRes, notificationsRes, paymentsRes] = await Promise.all([
      supabase.from("profiles").select("id, full_name, email"),
      supabase.from("providers").select("*"),
      supabase.from("bookings").select("*").order("created_at", { ascending: false }),
      supabase.from("reviews").select("*").order("created_at", { ascending: false }),
      supabase.from("messages").select("id, read"),
      supabase.from("notifications").select("id, read"),
      supabase.from("payments").select("*").order("created_at", { ascending: false }),
    ]);

    const profiles = profilesRes.data ?? [];
    const providers = (providersRes.data ?? []) as Array<Record<string, any>>;
    const bookingsRaw = bookingsRes.data ?? [];
    const reviewsRaw = reviewsRes.data ?? [];

    const profileById = new Map(profiles.map((p) => [p.id, p]));
    const providerById = new Map(providers.map((p) => [p.id, p]));

    const bookings: Booking[] = bookingsRaw.map((b: any) => ({
      id: b.id,
      reference: b.reference,
      customerName: profileById.get(b.customer_id)?.full_name || "Customer",
      providerName: b.provider_id ? providerById.get(b.provider_id)?.business_name ?? "Provider" : null,
      service: b.service,
      category: b.category,
      amount: Number(b.amount),
      scheduledFor: b.scheduled_for,
      createdAt: b.created_at,
      status: b.status,
    }));

    const adminProviders: AdminProvider[] = providers.map((p) => ({
      id: p.id,
      name: p.business_name,
      email: p.contact_email ?? "",
      status: p.approval_status,
      services: p.services ?? [],
      location: [p.city, p.state].filter(Boolean).join(", ") || (p.coverage_area ?? ""),
      rating: Number(p.rating ?? 0),
      verified: p.verification_status === "verified",
    }));

    const customers: AdminCustomer[] = profiles.map((p) => ({
      id: p.id, name: p.full_name || "Customer", email: p.email ?? "", status: "active",
    }));

    const reviews: AdminReview[] = reviewsRaw.map((r: any) => ({
      id: r.id,
      customerName: profileById.get(r.customer_id)?.full_name || "Customer",
      providerName: r.provider_id ? providerById.get(r.provider_id)?.business_name ?? "Provider" : "Provider",
      service: r.service,
      rating: r.rating,
      comment: r.comment ?? "",
    }));

    const activity: AdminActivity[] = [
      ...bookingsRaw.slice(0, 5).map((b: any) => ({
        id: `booking-${b.id}`,
        title: `${profileById.get(b.customer_id)?.full_name || "A customer"} booked ${b.service}`,
        detail: b.status,
        createdAt: b.created_at,
      })),
      ...providers
        .filter((p) => p.approval_status === "pending")
        .slice(0, 5)
        .map((p) => ({ id: `provider-${p.id}`, title: `${p.business_name} applied as a provider`, createdAt: p.created_at })),
    ]
      .sort((a, b) => +new Date(b.createdAt) - +new Date(a.createdAt))
      .slice(0, 8);

    const bookingById = new Map(bookingsRaw.map((b: any) => [b.id, b]));
    const payments: AdminPayment[] = (paymentsRes.data ?? []).map((p: any) => {
      const booking = bookingById.get(p.booking_id);
      return {
        id: p.id,
        bookingReference: booking?.reference ?? "—",
        customerName: profileById.get(p.customer_id)?.full_name || "Customer",
        amount: Number(p.amount),
        method: p.method,
        status: p.status,
        createdAt: p.created_at,
      };
    });

    setData({
      bookings,
      providers: adminProviders,
      customers,
      reviews,
      activity,
      payments,
      unreadMessages: (messagesRes.data ?? []).filter((m: any) => !m.read).length,
      unreadNotifications: (notificationsRes.data ?? []).filter((n: any) => !n.read).length,
    });
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  useEffect(() => {
    const channel = supabase
      .channel(topic.current)
      .on("postgres_changes", { event: "*", schema: "public", table: "bookings" }, () => void load())
      .on("postgres_changes", { event: "*", schema: "public", table: "providers" }, () => void load())
      .on("postgres_changes", { event: "*", schema: "public", table: "reviews" }, () => void load())
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [load]);

  return { data, loading, reload: load };
}

/* --------------------------- derived stats --------------------------- */

export const MONTH_LABELS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

export function formatNaira(n: number) {
  return `₦${Math.round(n).toLocaleString()}`;
}

export function selectAdminStats(d: AdminData) {
  const today = new Date();
  const isToday = (iso: string) => new Date(iso).toDateString() === today.toDateString();
  const successfulRevenue = d.bookings
    .filter((b) => b.status === "completed")
    .reduce((t, b) => t + b.amount, 0);

  return {
    totalCustomers: d.customers.length,
    totalProviders: d.providers.length,
    activeProviders: d.providers.filter((p) => p.status === "approved").length,
    pendingProviders: d.providers.filter((p) => p.status === "pending").length,
    todaysBookings: d.bookings.filter((b) => isToday(b.scheduledFor)).length,
    totalRevenue: successfulRevenue,
    totalBookings: d.bookings.length,
    completedBookings: d.bookings.filter((b) => b.status === "completed").length,
    pendingBookings: d.bookings.filter((b) => b.status === "payment_pending" || b.status === "finding_provider").length,
    cancelledBookings: d.bookings.filter((b) => b.status === "cancelled" || b.status === "rejected").length,
    totalReviews: d.reviews.length,
    unreadMessages: d.unreadMessages,
    unreadNotifications: d.unreadNotifications,
  };
}

export function selectMonthlyBookings(d: AdminData) {
  const year = new Date().getFullYear();
  const counts = Array(12).fill(0);
  for (const b of d.bookings) {
    const dt = new Date(b.createdAt);
    if (dt.getFullYear() === year) counts[dt.getMonth()]++;
  }
  return counts;
}

export function selectMonthlyRevenue(d: AdminData) {
  const year = new Date().getFullYear();
  const totals = Array(12).fill(0);
  for (const b of d.bookings) {
    if (b.status !== "completed") continue;
    const dt = new Date(b.createdAt);
    if (dt.getFullYear() === year) totals[dt.getMonth()] += b.amount;
  }
  return totals;
}

export function selectCategoryBreakdown(d: AdminData) {
  const totals = new Map<string, number>();
  for (const b of d.bookings) totals.set(b.category, (totals.get(b.category) ?? 0) + 1);
  const sum = d.bookings.length;
  if (!sum) return [];
  return [...totals.entries()]
    .map(([category, count]) => ({ category, pct: (count / sum) * 100 }))
    .sort((a, b) => b.pct - a.pct);
}

/* --------------------------- mutations --------------------------- */

/** Returns short-lived signed URLs for whatever verification documents a
 * provider has uploaded (the bucket is private, so these are the only way
 * to actually view them). Links expire in 10 minutes. */
export async function getProviderDocumentLinks(providerId: string) {
  const { data: files, error } = await supabase.storage.from("provider-documents").list(providerId);
  if (error || !files || files.length === 0) return [] as { name: string; url: string }[];

  const links = await Promise.all(
    files.map(async (f) => {
      const { data } = await supabase.storage
        .from("provider-documents")
        .createSignedUrl(`${providerId}/${f.name}`, 600);
      return { name: f.name, url: data?.signedUrl ?? "" };
    }),
  );
  return links.filter((l) => l.url);
}

export async function setProviderStatus(providerId: string, status: "approved" | "rejected") {
  const { error } = await supabase.from("providers").update({ approval_status: status }).eq("id", providerId);
  return error ? { ok: false as const, error: error.message } : { ok: true as const };
}

/* --------------------------- platform settings (admin) --------------------------- */

export type PlatformSetting = { key: string; value: unknown; description: string | null };

export function usePlatformSettings() {
  const [settings, setSettings] = useState<PlatformSetting[]>([]);
  const [loading, setLoading] = useState(true);

  const load = useCallback(async () => {
    const { data } = await supabase.from("platform_settings").select("*").order("key");
    setSettings((data ?? []) as PlatformSetting[]);
    setLoading(false);
  }, []);

  useEffect(() => {
    void load();
  }, [load]);

  return { settings, loading, reload: load };
}

export async function updatePlatformSetting(key: string, value: unknown) {
  const { error } = await supabase.from("platform_settings").update({ value: value as never }).eq("key", key);
  return error ? { ok: false as const, error: error.message } : { ok: true as const };
}
