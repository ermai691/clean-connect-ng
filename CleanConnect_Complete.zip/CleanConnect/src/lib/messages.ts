// In-app chat scoped to a single booking. Deliberately NOT a general
// customer<->provider chat or contact-sharing mechanism — a thread only
// exists in the context of one booking, between the customer and whichever
// provider is actually assigned to it. No phone numbers or emails are ever
// exchanged through this; see CleanConnect's communication policy.

import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";

export type ChatMessage = {
  id: string;
  bookingId: string;
  senderId: string;
  recipientId: string;
  body: string;
  read: boolean;
  createdAt: string;
  mine: boolean;
};

export function useBookingMessages(bookingId: string | null) {
  const [messages, setMessages] = useState<ChatMessage[]>([]);
  const [loading, setLoading] = useState(true);
  const [myId, setMyId] = useState<string | null>(null);

  const load = useCallback(async () => {
    if (!bookingId) {
      setMessages([]);
      setLoading(false);
      return;
    }
    const { data: auth } = await supabase.auth.getUser();
    const uid = auth.user?.id ?? null;
    setMyId(uid);

    const { data } = await supabase
      .from("messages")
      .select("*")
      .eq("booking_id", bookingId)
      .order("created_at", { ascending: true });

    setMessages(
      (data ?? []).map((m) => ({
        id: m.id,
        bookingId: m.booking_id ?? "",
        senderId: m.sender_id,
        recipientId: m.recipient_id,
        body: m.body,
        read: m.read,
        createdAt: m.created_at,
        mine: m.sender_id === uid,
      })),
    );
    setLoading(false);

    // Mark incoming messages read.
    if (uid) {
      await supabase
        .from("messages")
        .update({ read: true })
        .eq("booking_id", bookingId)
        .eq("recipient_id", uid)
        .eq("read", false);
    }
  }, [bookingId]);

  useEffect(() => {
    void load();
    if (!bookingId) return;
    const channel = supabase
      .channel(`booking-chat-${bookingId}`)
      .on(
        "postgres_changes",
        { event: "*", schema: "public", table: "messages", filter: `booking_id=eq.${bookingId}` },
        () => void load(),
      )
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [bookingId, load]);

  return { messages, loading, myId, reload: load };
}

export async function sendBookingMessage(bookingId: string, recipientId: string, body: string) {
  const trimmed = body.trim();
  if (!trimmed) return { ok: false as const, error: "Message can't be empty." };
  const { data: auth } = await supabase.auth.getUser();
  const uid = auth.user?.id;
  if (!uid) return { ok: false as const, error: "You need to be signed in." };

  const { error } = await supabase.from("messages").insert({
    booking_id: bookingId,
    sender_id: uid,
    recipient_id: recipientId,
    body: trimmed,
  });
  if (error) return { ok: false as const, error: error.message };
  return { ok: true as const };
}

/** Unread message count across all of the current user's bookings, for a nav badge. */
export function useUnreadMessageCount() {
  const [count, setCount] = useState(0);

  const load = useCallback(async () => {
    const { data: auth } = await supabase.auth.getUser();
    const uid = auth.user?.id;
    if (!uid) return setCount(0);
    const { count: c } = await supabase
      .from("messages")
      .select("id", { count: "exact", head: true })
      .eq("recipient_id", uid)
      .eq("read", false);
    setCount(c ?? 0);
  }, []);

  useEffect(() => {
    void load();
    const channel = supabase
      .channel(`unread-messages-${Math.random().toString(36).slice(2)}`)
      .on("postgres_changes", { event: "*", schema: "public", table: "messages" }, () => void load())
      .subscribe();
    return () => {
      void supabase.removeChannel(channel);
    };
  }, [load]);

  return count;
}
