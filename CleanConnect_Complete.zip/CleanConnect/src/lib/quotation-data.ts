// Customer-facing quotation data hooks.
// Relies on RLS: customers only see their own rows. Staff fields are selected
// only where the migration allows (customers can read quoted_amount once set).

import { useCallback, useEffect, useState } from "react";
import { supabase } from "@/integrations/supabase/client";
import { currentCustomer } from "@/lib/customer-auth";

export type QuotationStatus =
  | "submitted"
  | "under_review"
  | "quoted"
  | "accepted"
  | "declined"
  | "expired"
  | "cancelled"
  | "paid"
  | "assigned";

export type Quotation = {
  id: string;
  reference: string;
  customer_id: string;
  service_id: string;
  service_name: string;
  job_details: Record<string, unknown>;
  address: string;
  notes: string | null;
  attachment_paths: string[];
  status: QuotationStatus;
  quoted_amount: number | null;
  inspection_fee: number | null;
  valid_until: string | null;
  booking_id: string | null;
  created_at: string;
  updated_at: string;
};

const CUSTOMER_COLUMNS =
  "id, reference, customer_id, service_id, service_name, job_details, address, notes, attachment_paths, status, quoted_amount, inspection_fee, include_inspection_fee, valid_until, booking_id, payment_reference, paid_at, created_at, updated_at";

export function useCustomerQuotations() {
  const [quotations, setQuotations] = useState<Quotation[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);

  const reload = useCallback(async () => {
    setLoading(true);
    setError(null);
    try {
      const customer = await currentCustomer();
      if (!customer) {
        setQuotations([]);
        setError("Please sign in.");
        return;
      }
      // Table from migration 20261029233000 — regenerate types after apply.
      // Read through customer_quotations view — excludes staff_notes and assignment fields.
      const { data, error: qErr } = await (supabase as any)
        .from("customer_quotations")
        .select(CUSTOMER_COLUMNS)
        .eq("customer_id", customer.id)
        .order("created_at", { ascending: false });
      if (qErr) {
        setError(qErr.message);
        setQuotations([]);
        return;
      }
      setQuotations((data ?? []) as Quotation[]);
    } catch (e) {
      setError(e instanceof Error ? e.message : "Failed to load quotations.");
      setQuotations([]);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void reload();
  }, [reload]);

  return { quotations, loading, error, reload };
}

export async function getQuotationAttachmentUrl(path: string): Promise<string | null> {
  const { data, error } = await supabase.storage
    .from("quotation-attachments")
    .createSignedUrl(path, 60 * 10);
  if (error || !data?.signedUrl) return null;
  return data.signedUrl;
}

export const STATUS_LABELS: Record<QuotationStatus, string> = {
  submitted: "Submitted",
  under_review: "Under review",
  quoted: "Quote ready",
  accepted: "Accepted — pay now",
  declined: "Declined",
  expired: "Expired",
  cancelled: "Cancelled",
  paid: "Paid — awaiting team",
  assigned: "Assigned to team",
};
