// Server-side quotation request creation.
// Quotation-only services must never enter the direct booking, payment, or
// marketplace matching pipelines. Customer identity always comes from the
// bearer token — never from client-supplied IDs.

import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";
import { SERVICE_CATALOG, type JobDetails } from "@/lib/service-catalog";

const jobDetailsSchema = z
  .object({
    bedrooms: z.number().optional(),
    bathrooms: z.number().optional(),
    areaSqm: z.number().optional(),
    severity: z.string().optional(),
    guests: z.number().optional(),
    loads: z.number().optional(),
  })
  .partial();

const inputSchema = z.object({
  serviceId: z.string().min(1),
  jobDetails: jobDetailsSchema.default({}),
  address: z.string().trim().min(1).max(500),
  notes: z.string().trim().max(2000).optional(),
  /** Paths relative to the quotation-attachments bucket:
   *  {customer_id}/{quotation_id}/{filename}
   *  Optional on create; when provided they must match the pre-assigned id. */
  attachmentPaths: z.array(z.string().min(1).max(500)).max(10).default([]),
});

function findQuoteService(serviceId: string) {
  const service = SERVICE_CATALOG.find((s) => s.id === serviceId);
  if (!service) return { ok: false as const, error: "Unknown service." };
  if (service.bookingMode !== "quote") {
    return {
      ok: false as const,
      error:
        "This service can be booked online. Please use Book a Service instead of Request a Quote.",
    };
  }
  return { ok: true as const, service };
}

/** Every path must be exactly under {customerId}/{quotationId}/ */
function attachmentPathsValid(
  customerId: string,
  quotationId: string,
  paths: string[],
): boolean {
  const prefix = `${customerId}/${quotationId}/`;
  return paths.every((p) => typeof p === "string" && p.startsWith(prefix) && p.length > prefix.length);
}

export const createQuotationRequest = createServerFn({ method: "POST" })
  .inputValidator((input) => inputSchema.parse(input))
  .handler(async ({ data }) => {
    const authorization = getRequestHeader("Authorization");
    const token = authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
    if (!token) {
      return { ok: false as const, error: "You must be signed in to request a quotation." };
    }

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: authData, error: authError } = await supabaseAdmin.auth.getUser(token);
    const user = authData.user;
    if (authError || !user) {
      return { ok: false as const, error: "You must be signed in to request a quotation." };
    }

    // Require the customer role. Providers (without customer role) are rejected.
    const { data: isCustomer, error: roleError } = await supabaseAdmin.rpc("has_role", {
      _user_id: user.id,
      _role: "customer",
    });
    if (roleError || !isCustomer) {
      return {
        ok: false as const,
        error: "Only signed-in customers can submit quotation requests.",
      };
    }

    const resolved = findQuoteService(data.serviceId);
    if (!resolved.ok) return resolved;
    const service = resolved.service;

    // Pre-assign id so attachment paths can be validated against the real row id
    // before insert (matches storage convention {customer_id}/{quotation_id}/...).
    const quotationId = crypto.randomUUID();
    const paths = data.attachmentPaths ?? [];
    if (!attachmentPathsValid(user.id, quotationId, paths)) {
      return {
        ok: false as const,
        error:
          "Invalid attachment paths. Files must be stored under your account for this quotation.",
      };
    }

    const address = data.address.trim();
    if (!address) {
      return { ok: false as const, error: "Please provide a service address." };
    }

    // Service-role insert: RLS still models the same rules; we never accept
    // client-supplied customer_id, status, or staff fields.
    // Table added in migration 20261029233000 — regenerate types after apply.
    const { data: row, error: insertError } = await (supabaseAdmin as any)
      .from("quotations")
      .insert({
        id: quotationId,
        customer_id: user.id,
        service_id: service.id,
        service_name: service.name,
        job_details: (data.jobDetails ?? {}) as JobDetails,
        address,
        notes: data.notes?.trim() || null,
        attachment_paths: paths,
        status: "submitted",
      })
      .select("id, reference, status, service_id, service_name, created_at")
      .single();

    if (insertError || !row) {
      return {
        ok: false as const,
        error: insertError?.message ?? "Could not submit quotation request.",
      };
    }

    // Customer-facing confirmation only. No booking, payment, or matching.
    await supabaseAdmin.from("notifications").insert({
      user_id: user.id,
      type: "quotation",
      title: "Quotation request received",
      body: `${service.name} · ${row.reference} is being reviewed by CleanConnect.`,
    });

    return {
      ok: true as const,
      quotation: {
        id: row.id as string,
        reference: row.reference as string,
        status: row.status as string,
        serviceId: row.service_id as string,
        serviceName: row.service_name as string,
        createdAt: row.created_at as string,
      },
    };
  });

async function requireAuthUser(token: string | undefined) {
  if (!token) return { ok: false as const, error: "You must be signed in." };
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const { data: authData, error: authError } = await supabaseAdmin.auth.getUser(token);
  const user = authData.user;
  if (authError || !user) return { ok: false as const, error: "You must be signed in." };
  return { ok: true as const, user, supabaseAdmin };
}

async function requireAdmin(supabaseAdmin: any, userId: string) {
  const { data: isAdmin } = await supabaseAdmin.rpc("has_role", {
    _user_id: userId,
    _role: "admin",
  });
  if (!isAdmin) return { ok: false as const, error: "Admin access required." };
  return { ok: true as const };
}

function bearerToken() {
  const authorization = getRequestHeader("Authorization");
  return authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
}

/** Customer cancels their own submitted quotation. */
export const cancelQuotationRequest = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ quotationId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const auth = await requireAuthUser(bearerToken());
    if (!auth.ok) return auth;
    const { user, supabaseAdmin } = auth;

    const { data: row, error } = await (supabaseAdmin as any)
      .from("quotations")
      .update({ status: "cancelled" })
      .eq("id", data.quotationId)
      .eq("customer_id", user.id)
      .eq("status", "submitted")
      .select("id, reference, status")
      .maybeSingle();

    if (error) return { ok: false as const, error: error.message };
    if (!row) {
      return {
        ok: false as const,
        error: "Quotation not found or cannot be cancelled (only submitted requests can be cancelled).",
      };
    }
    return { ok: true as const, quotation: row };
  });

/** Admin: set review status and optional staff notes. */
export const adminUpdateQuotationReview = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z
      .object({
        quotationId: z.string().uuid(),
        status: z.enum(["under_review", "submitted", "declined", "cancelled"]).optional(),
        staffNotes: z.string().max(4000).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const auth = await requireAuthUser(bearerToken());
    if (!auth.ok) return auth;
    const gate = await requireAdmin(auth.supabaseAdmin, auth.user.id);
    if (!gate.ok) return gate;

    const patch: Record<string, unknown> = {
      reviewed_at: new Date().toISOString(),
      reviewed_by: auth.user.id,
    };
    if (data.status) patch.status = data.status;
    if (data.staffNotes !== undefined) patch.staff_notes = data.staffNotes.trim() || null;

    const { data: row, error } = await (auth.supabaseAdmin as any)
      .from("quotations")
      .update(patch)
      .eq("id", data.quotationId)
      .select("id, reference, status")
      .maybeSingle();

    if (error) return { ok: false as const, error: error.message };
    if (!row) return { ok: false as const, error: "Quotation not found." };
    return { ok: true as const, quotation: row };
  });

/** Admin: set price, inspection fee, validity and mark as quoted; notify customer. */
export const adminSendQuotation = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z
      .object({
        quotationId: z.string().uuid(),
        quotedAmount: z.number().positive().max(50_000_000),
        inspectionFee: z.number().min(0).max(50_000_000).optional(),
        staffNotes: z.string().max(4000).optional(),
        validityDays: z.number().int().min(1).max(90).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const auth = await requireAuthUser(bearerToken());
    if (!auth.ok) return auth;
    const gate = await requireAdmin(auth.supabaseAdmin, auth.user.id);
    if (!gate.ok) return gate;

    const { data: existing } = await (auth.supabaseAdmin as any)
      .from("quotations")
      .select("id, customer_id, status, service_name, reference")
      .eq("id", data.quotationId)
      .maybeSingle();
    if (!existing) return { ok: false as const, error: "Quotation not found." };
    if (existing.status === "cancelled" || existing.status === "expired") {
      return { ok: false as const, error: `Cannot quote a ${existing.status} request.` };
    }

    let days = data.validityDays;
    if (days == null) {
      const { data: setting } = await auth.supabaseAdmin
        .from("platform_settings")
        .select("value")
        .eq("key", "quotation_validity_days")
        .maybeSingle();
      const raw = setting?.value;
      days = typeof raw === "number" ? raw : Number(raw ?? 7);
      if (!Number.isFinite(days) || days < 1) days = 7;
    }

    const validUntil = new Date();
    validUntil.setDate(validUntil.getDate() + days);

    const inspectionFee = data.inspectionFee ?? 0;
    if (data.quotedAmount <= 0) {
      return { ok: false as const, error: "Quoted amount must be greater than zero." };
    }

    const { data: row, error } = await (auth.supabaseAdmin as any)
      .from("quotations")
      .update({
        status: "quoted",
        quoted_amount: data.quotedAmount,
        inspection_fee: inspectionFee,
        valid_until: validUntil.toISOString(),
        reviewed_at: new Date().toISOString(),
        reviewed_by: auth.user.id,
        staff_notes: data.staffNotes?.trim() || null,
      })
      .eq("id", data.quotationId)
      .select("id, reference, status, quoted_amount, inspection_fee, valid_until, customer_id, service_name")
      .maybeSingle();

    if (error || !row) {
      return { ok: false as const, error: error?.message ?? "Could not send quotation." };
    }

    const feeNote =
      inspectionFee > 0
        ? ` Inspection fee ₦${Math.round(inspectionFee).toLocaleString("en-NG")} (disclosed — charged only if you approve).`
        : "";
    await auth.supabaseAdmin.from("notifications").insert({
      user_id: row.customer_id,
      type: "quotation",
      title: "Your quotation is ready",
      body: `${row.service_name} · ${row.reference}: ₦${Math.round(Number(row.quoted_amount)).toLocaleString("en-NG")}. Valid until ${new Date(row.valid_until).toLocaleDateString("en-NG")}.${feeNote}`,
    });

    return {
      ok: true as const,
      quotation: {
        id: row.id as string,
        reference: row.reference as string,
        status: row.status as string,
        quotedAmount: Number(row.quoted_amount),
        inspectionFee: Number(row.inspection_fee ?? 0),
        validUntil: row.valid_until as string,
      },
    };
  });

/** Customer accepts a valid quotation (does not charge payment). */
export const acceptQuotation = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ quotationId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const auth = await requireAuthUser(bearerToken());
    if (!auth.ok) return auth;
    const { user, supabaseAdmin } = auth;

    const { data: existing } = await (supabaseAdmin as any)
      .from("quotations")
      .select("id, customer_id, status, valid_until, quoted_amount, reference, service_name")
      .eq("id", data.quotationId)
      .eq("customer_id", user.id)
      .maybeSingle();

    if (!existing) return { ok: false as const, error: "Quotation not found." };
    if (existing.status !== "quoted") {
      return { ok: false as const, error: "Only an active quotation can be accepted." };
    }
    if (existing.valid_until && new Date(existing.valid_until).getTime() < Date.now()) {
      await (supabaseAdmin as any)
        .from("quotations")
        .update({ status: "expired" })
        .eq("id", existing.id)
        .eq("status", "quoted");
      return { ok: false as const, error: "This quotation has expired." };
    }
    if (!existing.quoted_amount || Number(existing.quoted_amount) <= 0) {
      return { ok: false as const, error: "Quotation has no valid amount." };
    }

    const { data: row, error } = await (supabaseAdmin as any)
      .from("quotations")
      .update({ status: "accepted" })
      .eq("id", data.quotationId)
      .eq("customer_id", user.id)
      .eq("status", "quoted")
      .select("id, reference, status, quoted_amount, inspection_fee")
      .maybeSingle();

    if (error || !row) {
      return { ok: false as const, error: error?.message ?? "Could not accept quotation." };
    }

    // Notify admins via a notification on the accepting customer is weak;
    // insert a system-style note for the customer and rely on admin list.
    await supabaseAdmin.from("notifications").insert({
      user_id: user.id,
      type: "quotation",
      title: "Quotation accepted",
      body: `${existing.service_name} · ${existing.reference} accepted. Complete payment when prompted to schedule the job with CleanConnect's team.`,
    });

    return {
      ok: true as const,
      quotation: {
        id: row.id as string,
        reference: row.reference as string,
        status: row.status as string,
        quotedAmount: Number(row.quoted_amount),
        inspectionFee: Number(row.inspection_fee ?? 0),
      },
    };
  });

/** Customer declines a quoted request. */
export const declineQuotation = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ quotationId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const auth = await requireAuthUser(bearerToken());
    if (!auth.ok) return auth;
    const { user, supabaseAdmin } = auth;

    const { data: row, error } = await (supabaseAdmin as any)
      .from("quotations")
      .update({ status: "declined" })
      .eq("id", data.quotationId)
      .eq("customer_id", user.id)
      .eq("status", "quoted")
      .select("id, reference, status, service_name")
      .maybeSingle();

    if (error) return { ok: false as const, error: error.message };
    if (!row) {
      return { ok: false as const, error: "Quotation not found or cannot be declined." };
    }

    await supabaseAdmin.from("notifications").insert({
      user_id: user.id,
      type: "quotation",
      title: "Quotation declined",
      body: `${row.service_name} · ${row.reference} was declined.`,
    });

    return { ok: true as const, quotation: row };
  });

/** Customer accepts a quoted request and optionally approves a disclosed inspection fee. */
export const acceptQuotationWithFeeChoice = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z
      .object({
        quotationId: z.string().uuid(),
        approveInspectionFee: z.boolean().default(false),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const auth = await requireAuthUser(bearerToken());
    if (!auth.ok) return auth;
    const { user, supabaseAdmin } = auth;

    const { data: existing } = await (supabaseAdmin as any)
      .from("quotations")
      .select("id, customer_id, status, valid_until, quoted_amount, inspection_fee, reference, service_name")
      .eq("id", data.quotationId)
      .eq("customer_id", user.id)
      .maybeSingle();

    if (!existing) return { ok: false as const, error: "Quotation not found." };
    if (existing.status !== "quoted") {
      return { ok: false as const, error: "Only an active quotation can be accepted." };
    }
    if (existing.valid_until && new Date(existing.valid_until).getTime() < Date.now()) {
      await (supabaseAdmin as any)
        .from("quotations")
        .update({ status: "expired" })
        .eq("id", existing.id)
        .eq("status", "quoted");
      return { ok: false as const, error: "This quotation has expired." };
    }
    if (!existing.quoted_amount || Number(existing.quoted_amount) <= 0) {
      return { ok: false as const, error: "Quotation has no valid amount." };
    }

    const fee = Number(existing.inspection_fee ?? 0);
    if (fee > 0 && !data.approveInspectionFee) {
      // Allowed: accept without fee — fee excluded from payment total
    }

    const { data: row, error } = await (supabaseAdmin as any)
      .from("quotations")
      .update({
        status: "accepted",
        include_inspection_fee: fee > 0 && data.approveInspectionFee === true,
      })
      .eq("id", data.quotationId)
      .eq("customer_id", user.id)
      .eq("status", "quoted")
      .select("id, reference, status, quoted_amount, inspection_fee, include_inspection_fee")
      .maybeSingle();

    if (error || !row) {
      return { ok: false as const, error: error?.message ?? "Could not accept quotation." };
    }

    await supabaseAdmin.from("notifications").insert({
      user_id: user.id,
      type: "quotation",
      title: "Quotation accepted",
      body: `${existing.service_name} · ${existing.reference} accepted. Please complete payment to confirm the job with CleanConnect's team.`,
    });

    return {
      ok: true as const,
      quotation: {
        id: row.id as string,
        reference: row.reference as string,
        status: row.status as string,
        quotedAmount: Number(row.quoted_amount),
        inspectionFee: Number(row.inspection_fee ?? 0),
        includeInspectionFee: !!row.include_inspection_fee,
      },
    };
  });

/**
 * Start Paystack checkout for an accepted quotation.
 * Amount is computed server-side from quoted_amount (+ inspection fee only if approved).
 * Does not create a booking or trigger marketplace matching.
 */
export const initializeQuotationPayment = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z.object({ quotationId: z.string().uuid(), callbackUrl: z.string().url() }).parse(input),
  )
  .handler(async ({ data }) => {
    const auth = await requireAuthUser(bearerToken());
    if (!auth.ok) return auth;
    const { user, supabaseAdmin } = auth;

    const secretKey = process.env.PAYSTACK_SECRET_KEY;
    if (!secretKey) {
      return {
        ok: false as const,
        error: "Online payment isn't configured yet. Please contact support.",
      };
    }

    const { data: q } = await (supabaseAdmin as any)
      .from("quotations")
      .select(
        "id, customer_id, status, quoted_amount, inspection_fee, include_inspection_fee, payment_reference, valid_until, reference",
      )
      .eq("id", data.quotationId)
      .eq("customer_id", user.id)
      .maybeSingle();

    if (!q) return { ok: false as const, error: "Quotation not found." };
    if (q.status !== "accepted") {
      return { ok: false as const, error: "Only an accepted quotation can be paid." };
    }
    if (q.valid_until && new Date(q.valid_until).getTime() < Date.now()) {
      return { ok: false as const, error: "This quotation has expired." };
    }

    const base = Number(q.quoted_amount);
    if (!Number.isFinite(base) || base <= 0) {
      return { ok: false as const, error: "Invalid quotation amount." };
    }
    const fee =
      q.include_inspection_fee && Number(q.inspection_fee) > 0 ? Number(q.inspection_fee) : 0;
    const amountNaira = Math.round(base + fee);

    let paymentReference = q.payment_reference as string | null;
    if (!paymentReference) {
      paymentReference = `CQPAY-${q.reference}-${Date.now().toString(36).toUpperCase()}`;
      await (supabaseAdmin as any)
        .from("quotations")
        .update({ payment_reference: paymentReference })
        .eq("id", q.id)
        .eq("customer_id", user.id)
        .eq("status", "accepted");
    }

    // Pending payment row (quotation_id set; booking_id null)
    await (supabaseAdmin as any).from("payments").upsert(
      {
        quotation_id: q.id,
        booking_id: null,
        customer_id: user.id,
        amount: amountNaira,
        method: "Paystack",
        status: "pending",
      },
      { onConflict: "quotation_id", ignoreDuplicates: false },
    ).then(() => null).catch(() => null);

    // Prefer insert if upsert unsupported without unique on quotation_id alone
    const { data: existingPay } = await (supabaseAdmin as any)
      .from("payments")
      .select("id")
      .eq("quotation_id", q.id)
      .eq("status", "pending")
      .maybeSingle();
    if (!existingPay) {
      await (supabaseAdmin as any).from("payments").insert({
        quotation_id: q.id,
        booking_id: null,
        customer_id: user.id,
        amount: amountNaira,
        method: "Paystack",
        status: "pending",
      });
    }

    const res = await fetch("https://api.paystack.co/transaction/initialize", {
      method: "POST",
      headers: {
        Authorization: `Bearer ${secretKey}`,
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        email: user.email,
        amount: amountNaira * 100,
        currency: "NGN",
        reference: paymentReference,
        callback_url: data.callbackUrl,
        metadata: { quotation_id: q.id, kind: "quotation" },
      }),
    });

    if (!res.ok) {
      const text = await res.text();
      console.error("Paystack quotation initialize failed:", res.status, text);
      return { ok: false as const, error: "Could not start payment. Please try again." };
    }

    const body = await res.json();
    if (!body?.status || !body?.data?.authorization_url) {
      return { ok: false as const, error: "Paystack did not return a checkout link." };
    }

    return {
      ok: true as const,
      authorizationUrl: body.data.authorization_url as string,
      amount: amountNaira,
      reference: paymentReference,
    };
  });

/** Admin manually assigns a paid quotation to an internal CleanConnect team label. */
export const adminAssignQuotationJob = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z
      .object({
        quotationId: z.string().uuid(),
        teamLabel: z.string().trim().min(1).max(200),
        assignmentNotes: z.string().trim().max(2000).optional(),
      })
      .parse(input),
  )
  .handler(async ({ data }) => {
    const auth = await requireAuthUser(bearerToken());
    if (!auth.ok) return auth;
    const gate = await requireAdmin(auth.supabaseAdmin, auth.user.id);
    if (!gate.ok) return gate;

    const { data: existing } = await (auth.supabaseAdmin as any)
      .from("quotations")
      .select("id, status, customer_id, reference, service_name")
      .eq("id", data.quotationId)
      .maybeSingle();

    if (!existing) return { ok: false as const, error: "Quotation not found." };
    if (existing.status !== "paid" && existing.status !== "assigned") {
      return {
        ok: false as const,
        error: "Only paid quotation jobs can be assigned to the internal team.",
      };
    }

    const { data: row, error } = await (auth.supabaseAdmin as any)
      .from("quotations")
      .update({
        status: "assigned",
        assigned_team_label: data.teamLabel.trim(),
        assigned_by: auth.user.id,
        assigned_at: new Date().toISOString(),
        assignment_notes: data.assignmentNotes?.trim() || null,
      })
      .eq("id", data.quotationId)
      .in("status", ["paid", "assigned"])
      .select("id, reference, status, assigned_team_label, assigned_at")
      .maybeSingle();

    if (error || !row) {
      return { ok: false as const, error: error?.message ?? "Could not assign job." };
    }

    await auth.supabaseAdmin.from("notifications").insert({
      user_id: existing.customer_id,
      type: "quotation",
      title: "Team assigned to your job",
      body: `${existing.service_name} · ${existing.reference} has been scheduled with CleanConnect's team (${data.teamLabel.trim()}).`,
    });

    return { ok: true as const, quotation: row };
  });

/** Admin: list quotations including internal staff fields (service-role only). */
export const adminListQuotations = createServerFn({ method: "POST" })
  .handler(async () => {
    const auth = await requireAuthUser(bearerToken());
    if (!auth.ok) return auth;
    const gate = await requireAdmin(auth.supabaseAdmin, auth.user.id);
    if (!gate.ok) return gate;

    const { data, error } = await (auth.supabaseAdmin as any)
      .from("quotations")
      .select(
        "id, reference, customer_id, service_name, service_id, address, notes, job_details, attachment_paths, status, quoted_amount, inspection_fee, valid_until, staff_notes, created_at, assigned_team_label, assigned_at, assigned_by, assignment_notes, paid_at, payment_reference, include_inspection_fee",
      )
      .order("created_at", { ascending: false })
      .limit(200);

    if (error) return { ok: false as const, error: error.message };
    return { ok: true as const, quotations: data ?? [] };
  });
