import { supabase } from "@/integrations/supabase/client";
import type { Json } from "@/integrations/supabase/types";
import { setUser as setLocalUser, logout as clearLocalUser } from "@/lib/auth";
import { provisionProviderRole } from "@/lib/provider-auth.functions";

const authRedirectUrl = () => `${window.location.origin}/auth/provider`;

function friendlyAuthError(message: string) {
  if (/email not confirmed/i.test(message)) {
    return "Please confirm your email address using the verification link, then log in again.";
  }
  if (/invalid login credentials/i.test(message)) return "Incorrect email or password.";
  if (/already registered|already exists/i.test(message)) return "An account with that email already exists. Try logging in.";
  if (/password/i.test(message) && /weak|short|characters/i.test(message)) return message;
  return message;
}

function mirrorSession(name: string, email: string) {
  // Navigation convenience only. Supabase Auth remains the source of truth.
  setLocalUser({ name, email, role: "provider" }, true);
}

async function provisionRole() {
  const result = await provisionProviderRole({ data: {} });
  return result.ok ? result : { ok: false as const, error: result.error };
}

export type ProviderApplication = {
  businessName: string;
  contactPhone: string;
  description: string;
  services: string[];
  coverageArea: string;
  city: string;
  state: string;
};

/** The four verification documents collected on the application form, as
 * base64 data URLs (what the upload widget produces). `license` is optional. */
export type ProviderDocuments = {
  passport: string | null;
  nin: string | null;
  license: string | null;
  selfie: string | null;
};

function extensionForDataUrl(dataUrl: string): string {
  const match = /^data:image\/(png|jpeg|jpg|webp)/i.exec(dataUrl);
  return (match?.[1] ?? "jpg").toLowerCase();
}

function dataUrlToBlob(dataUrl: string): Blob {
  const [header, base64] = dataUrl.split(",");
  const mime = /data:(.*?);base64/.exec(header ?? "")?.[1] ?? "image/jpeg";
  const binary = atob(base64 ?? "");
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return new Blob([bytes], { type: mime });
}

/** Uploads whichever of the four documents are present to private storage,
 * scoped under the provider's own user id. Returns the storage paths saved
 * (not public URLs — the bucket is private, so viewing them later requires
 * a signed URL). Upload failures are logged but don't block signup; an
 * admin reviewing an application with a missing document will just see it
 * as absent, same as if the provider skipped an optional field. */
export async function uploadVerificationDocuments(userId: string, docs: ProviderDocuments) {
  const paths: Record<string, string> = {};
  const entries = Object.entries(docs) as [keyof ProviderDocuments, string | null][];

  for (const [key, dataUrl] of entries) {
    if (!dataUrl) continue;
    try {
      const ext = extensionForDataUrl(dataUrl);
      const path = `${userId}/${key}.${ext}`;
      const blob = dataUrlToBlob(dataUrl);
      const { error } = await supabase.storage
        .from("provider-documents")
        .upload(path, blob, { upsert: true, contentType: blob.type });
      if (!error) paths[key] = path;
      else console.error(`Failed to upload ${key}:`, error.message);
    } catch (err) {
      console.error(`Failed to process ${key}:`, err);
    }
  }
  return paths;
}

/** Creates the `providers` row for a freshly authenticated provider. Safe to call once. */
async function createProviderProfile(
  userId: string,
  email: string,
  app: ProviderApplication,
  documentPaths: Record<string, string>,
) {
  const { error } = await supabase.from("providers").insert({
    id: userId,
    business_name: app.businessName,
    contact_phone: app.contactPhone,
    contact_email: email,
    description: app.description,
    services: app.services,
    coverage_area: app.coverageArea,
    city: app.city,
    state: app.state,
    approval_status: "pending",
    verification_status: "unverified",
    verification_documents: documentPaths as Json,
  });
  // Ignore a duplicate-row conflict (e.g. re-submitting after a page refresh) — anything
  // else is surfaced to the caller.
  if (error && !/duplicate key/i.test(error.message)) {
    return { ok: false as const, error: error.message };
  }
  return { ok: true as const };
}

export async function signUpProvider(input: {
  name: string;
  email: string;
  password: string;
  application: ProviderApplication;
  documents: ProviderDocuments;
}) {
  const name = input.name.trim();
  const email = input.email.trim().toLowerCase();
  if (!name) return { ok: false as const, error: "Full name is required." };
  if (input.password.length < 8) return { ok: false as const, error: "Password must be at least 8 characters." };

  const { data, error } = await supabase.auth.signUp({
    email,
    password: input.password,
    options: {
      emailRedirectTo: authRedirectUrl(),
      data: { full_name: name, intended_role: "provider" },
    },
  });
  if (error) return { ok: false as const, error: friendlyAuthError(error.message) };

  if (!data.session || !data.user) {
    return {
      ok: false as const,
      needsConfirmation: true as const,
      error: "Account created. Check your email to confirm your account, then return here and log in — your application finishes automatically once you do.",
    };
  }

  const role = await provisionRole();
  if (!role.ok) return { ok: false as const, error: role.error };

  const documentPaths = await uploadVerificationDocuments(data.user.id, input.documents);
  const profile = await createProviderProfile(data.user.id, data.user.email ?? email, input.application, documentPaths);
  if (!profile.ok) return { ok: false as const, error: profile.error };

  mirrorSession(name, data.user.email ?? email);
  return { ok: true as const };
}

export async function signInProvider(email: string, password: string) {
  const value = email.trim().toLowerCase();
  const { data, error } = await supabase.auth.signInWithPassword({ email: value, password });
  if (error || !data.user) {
    return { ok: false as const, error: friendlyAuthError(error?.message ?? "Incorrect email or password.") };
  }

  const role = await provisionRole();
  if (!role.ok) {
    await supabase.auth.signOut();
    return { ok: false as const, error: role.error };
  }
  const name = (data.user.user_metadata?.["full_name"] as string | undefined) ?? "Provider";
  mirrorSession(name, data.user.email ?? value);
  return { ok: true as const };
}

/**
 * Completes a pending sign-up: provisions the role and creates the `providers`
 * row using an application draft that the caller stashed before email
 * confirmation (there is no session to write with until confirmation).
 */
export async function finishProviderSignup(application: ProviderApplication, documents: ProviderDocuments) {
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user || !data.user.email_confirmed_at) return null;
  const role = await provisionRole();
  if (!role.ok) return null;
  const documentPaths = await uploadVerificationDocuments(data.user.id, documents);
  await createProviderProfile(data.user.id, data.user.email ?? "", application, documentPaths);
  const name = (data.user.user_metadata?.["full_name"] as string | undefined) ?? "Provider";
  mirrorSession(name, data.user.email ?? "");
  return { id: data.user.id, email: data.user.email ?? "", name };
}

/** True if this authenticated provider already has a `providers` row. Used to
 * avoid re-running the resume flow (and re-uploading documents) once an
 * application has already been completed. */
export async function hasProviderProfile(userId: string) {
  const { data } = await supabase.from("providers").select("id").eq("id", userId).maybeSingle();
  return !!data;
}

export async function signOutProvider() {
  await supabase.auth.signOut();
  clearLocalUser();
}

export async function currentProvider() {
  const { data, error } = await supabase.auth.getUser();
  if (error || !data.user) return null;
  return { id: data.user.id, email: data.user.email ?? "" };
}
