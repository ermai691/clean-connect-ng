// Thin TanStack Start server-function wrappers around matching-core.ts.
// All the actual logic lives there so it's shared with the Netlify
// scheduled function and the Paystack webhook, which can't import
// TanStack-specific code.

import { createServerFn } from "@tanstack/react-start";
import { getRequestHeader } from "@tanstack/react-start/server";
import { z } from "zod";
import { findAndOfferProvider, expireStaleAssignmentsCore } from "@/lib/matching-core";

/** Verifies the caller is a signed-in admin. Used to gate the two functions
 * below — neither should be callable by an arbitrary authenticated user,
 * let alone an anonymous one. A booking's payment status is not, by
 * itself, authorization to trigger matching or expire offers. */
async function requireAdmin(supabaseAdmin: any): Promise<{ ok: true } | { ok: false; error: string }> {
  const authorization = getRequestHeader("Authorization");
  const token = authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
  if (!token) return { ok: false, error: "You must be signed in." };

  const { data: authData, error: authError } = await supabaseAdmin.auth.getUser(token);
  const user = authData.user;
  if (authError || !user) return { ok: false, error: "You must be signed in." };

  const { data: isAdmin } = await supabaseAdmin.rpc("has_role", { _user_id: user.id, _role: "admin" });
  if (!isAdmin) return { ok: false, error: "Admin access required." };
  return { ok: true };
}

/** Admin-only manual/testing trigger — the real production trigger is the
 * Paystack webhook calling findAndOfferProvider directly (see
 * netlify/functions/paystack-webhook.ts), which runs with service-role
 * access in a trusted server context, not through this public RPC. */
export const assignBestProvider = createServerFn({ method: "POST" })
  .inputValidator((input) => z.object({ bookingId: z.string().uuid() }).parse(input))
  .handler(async ({ data }) => {
    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const auth = await requireAdmin(supabaseAdmin);
    if (!auth.ok) return { ok: false as const, error: auth.error };
    return findAndOfferProvider(supabaseAdmin, data.bookingId);
  });

/** Provider accepts or declines their offered assignment. Verifies the
 * caller is actually the assigned provider (never trusts a client-supplied
 * provider id), and uses an atomic conditional update so a concurrent
 * expiry sweep can't race an accept/decline click. */
export const respondToAssignment = createServerFn({ method: "POST" })
  .inputValidator((input) =>
    z.object({ assignmentId: z.string().uuid(), decision: z.enum(["accept", "decline"]) }).parse(input),
  )
  .handler(async ({ data }) => {
    const authorization = getRequestHeader("Authorization");
    const token = authorization?.match(/^Bearer\s+(.+)$/i)?.[1];
    if (!token) return { ok: false as const, error: "You must be signed in." };

    const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
    const { data: authData, error: authError } = await supabaseAdmin.auth.getUser(token);
    const user = authData.user;
    if (authError || !user) return { ok: false as const, error: "You must be signed in." };

    const { data: assignment } = await supabaseAdmin
      .from("booking_assignments")
      .select("*")
      .eq("id", data.assignmentId)
      .maybeSingle();
    if (!assignment) return { ok: false as const, error: "Assignment not found." };
    if (assignment.provider_id !== user.id) return { ok: false as const, error: "This offer isn't yours." };

    const newStatus = data.decision === "accept" ? "accepted" : "declined";
    const nowIso = new Date().toISOString();

    // Atomic claim: if the 30-minute expiry sweep concurrently flips this
    // row to 'expired' first, this matches zero rows instead of racing it.
    const { data: claimed } = await supabaseAdmin
      .from("booking_assignments")
      .update({ status: newStatus, responded_at: nowIso })
      .eq("id", data.assignmentId)
      .eq("status", "pending")
      .gt("responds_by", nowIso)
      .select()
      .maybeSingle();

    if (!claimed) {
      return { ok: false as const, error: "This offer is no longer active (it may have just expired)." };
    }

    const counterField = data.decision === "accept" ? "assignments_accepted" : "assignments_declined";
    const { data: provider } = await supabaseAdmin
      .from("providers")
      .select(counterField)
      .eq("id", user.id)
      .maybeSingle();
    const currentCount = (provider as Record<string, number> | null)?.[counterField] ?? 0;
    const counterUpdate: Record<string, number> = { [counterField]: currentCount + 1 };
    await supabaseAdmin.from("providers").update(counterUpdate as never).eq("id", user.id);

    if (data.decision === "accept") {
      await supabaseAdmin
        .from("bookings")
        .update({ status: "provider_accepted", provider_id: user.id })
        .eq("id", assignment.booking_id);

      const { data: booking } = await supabaseAdmin
        .from("bookings")
        .select("customer_id, service")
        .eq("id", assignment.booking_id)
        .maybeSingle();
      if (booking) {
        await supabaseAdmin.from("notifications").insert({
          user_id: booking.customer_id,
          type: "booking",
          title: "Provider accepted your booking",
          body: `A verified professional has accepted your ${booking.service} booking.`,
        });
      }
      return { ok: true as const, result: "accepted" as const };
    }

    // Declined — immediately try the next-best provider for the same booking.
    const next = await findAndOfferProvider(supabaseAdmin, assignment.booking_id);
    return { ok: true as const, result: "declined" as const, next };
  });

/** Admin-only manual/testing trigger for the expiry sweep. In production
 * this runs on a schedule via netlify/functions/expire-assignments.ts
 * (a trusted server-side cron job, not reachable via this public RPC). */
export const expireStaleAssignments = createServerFn({ method: "POST" }).handler(async () => {
  const { supabaseAdmin } = await import("@/integrations/supabase/client.server");
  const auth = await requireAdmin(supabaseAdmin);
  if (!auth.ok) return { ok: false as const, error: auth.error };
  return expireStaleAssignmentsCore(supabaseAdmin);
});
