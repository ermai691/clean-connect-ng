export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "14.5"
  }
  public: {
    Tables: {
      addresses: {
        Row: {
          city: string | null
          created_at: string
          id: string
          is_default: boolean
          label: string
          state: string | null
          street: string
          updated_at: string
          user_id: string
        }
        Insert: {
          city?: string | null
          created_at?: string
          id?: string
          is_default?: boolean
          label?: string
          state?: string | null
          street: string
          updated_at?: string
          user_id: string
        }
        Update: {
          city?: string | null
          created_at?: string
          id?: string
          is_default?: boolean
          label?: string
          state?: string | null
          street?: string
          updated_at?: string
          user_id?: string
        }
        Relationships: []
      }
      bookings: {
        Row: {
          address: string | null
          amount: number
          category: string
          completed_at: string | null
          confirm_deadline: string | null
          created_at: string
          customer_id: string
          id: string
          job_details: Json
          notes: string | null
          package: string | null
          payment_reference: string | null
          provider_id: string | null
          reference: string
          scheduled_for: string
          service: string
          service_city: string | null
          service_state: string | null
          status: string
          updated_at: string
        }
        Insert: {
          address?: string | null
          amount?: number
          category?: string
          completed_at?: string | null
          confirm_deadline?: string | null
          created_at?: string
          customer_id: string
          id?: string
          job_details?: Json
          notes?: string | null
          package?: string | null
          payment_reference?: string | null
          provider_id?: string | null
          reference?: string
          scheduled_for: string
          service: string
          service_city?: string | null
          service_state?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          address?: string | null
          amount?: number
          category?: string
          completed_at?: string | null
          confirm_deadline?: string | null
          created_at?: string
          customer_id?: string
          id?: string
          job_details?: Json
          notes?: string | null
          package?: string | null
          payment_reference?: string | null
          provider_id?: string | null
          reference?: string
          scheduled_for?: string
          service?: string
          service_city?: string | null
          service_state?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      messages: {
        Row: {
          body: string
          booking_id: string | null
          created_at: string
          id: string
          read: boolean
          recipient_id: string
          sender_id: string
        }
        Insert: {
          body: string
          booking_id?: string | null
          created_at?: string
          id?: string
          read?: boolean
          recipient_id: string
          sender_id: string
        }
        Update: {
          body?: string
          booking_id?: string | null
          created_at?: string
          id?: string
          read?: boolean
          recipient_id?: string
          sender_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "messages_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
        ]
      }
      notifications: {
        Row: {
          body: string | null
          created_at: string
          id: string
          read: boolean
          title: string
          type: string
          user_id: string
        }
        Insert: {
          body?: string | null
          created_at?: string
          id?: string
          read?: boolean
          title: string
          type?: string
          user_id: string
        }
        Update: {
          body?: string | null
          created_at?: string
          id?: string
          read?: boolean
          title?: string
          type?: string
          user_id?: string
        }
        Relationships: []
      }
      payments: {
        Row: {
          amount: number
          booking_id: string | null
          created_at: string
          customer_id: string
          id: string
          method: string
          status: string
          updated_at: string
        }
        Insert: {
          amount?: number
          booking_id?: string | null
          created_at?: string
          customer_id: string
          id?: string
          method?: string
          status?: string
          updated_at?: string
        }
        Update: {
          amount?: number
          booking_id?: string | null
          created_at?: string
          customer_id?: string
          id?: string
          method?: string
          status?: string
          updated_at?: string
        }
        Relationships: [
          {
            foreignKeyName: "payments_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: false
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
        ]
      }
      profiles: {
        Row: {
          address: string | null
          avatar_url: string | null
          city: string | null
          created_at: string
          date_of_birth: string | null
          email: string
          full_name: string
          gender: string | null
          id: string
          language: string
          loyalty_points: number
          notify_bookings: boolean
          notify_email: boolean
          notify_promotions: boolean
          notify_sms: boolean
          phone: string | null
          referral_code: string | null
          referral_count: number
          referral_rewards: number
          state: string | null
          updated_at: string
          wallet_balance: number
        }
        Insert: {
          address?: string | null
          avatar_url?: string | null
          city?: string | null
          created_at?: string
          date_of_birth?: string | null
          email?: string
          full_name?: string
          gender?: string | null
          id: string
          language?: string
          loyalty_points?: number
          notify_bookings?: boolean
          notify_email?: boolean
          notify_promotions?: boolean
          notify_sms?: boolean
          phone?: string | null
          referral_code?: string | null
          referral_count?: number
          referral_rewards?: number
          state?: string | null
          updated_at?: string
          wallet_balance?: number
        }
        Update: {
          address?: string | null
          avatar_url?: string | null
          city?: string | null
          created_at?: string
          date_of_birth?: string | null
          email?: string
          full_name?: string
          gender?: string | null
          id?: string
          language?: string
          loyalty_points?: number
          notify_bookings?: boolean
          notify_email?: boolean
          notify_promotions?: boolean
          notify_sms?: boolean
          phone?: string | null
          referral_code?: string | null
          referral_count?: number
          referral_rewards?: number
          state?: string | null
          updated_at?: string
          wallet_balance?: number
        }
        Relationships: []
      }
      providers: {
        Row: {
          approval_status: string
          assignments_accepted: number
          assignments_declined: number
          assignments_expired: number
          business_name: string
          cancelled_jobs: number
          city: string | null
          completed_jobs: number
          contact_email: string | null
          contact_phone: string | null
          coverage_area: string | null
          created_at: string
          description: string | null
          id: string
          is_online: boolean
          no_show_count: number
          rating: number
          review_count: number
          services: string[]
          state: string | null
          updated_at: string
          verification_documents: Json
          verification_status: string
        }
        Insert: {
          approval_status?: string
          assignments_accepted?: number
          assignments_declined?: number
          assignments_expired?: number
          business_name?: string
          cancelled_jobs?: number
          city?: string | null
          completed_jobs?: number
          contact_email?: string | null
          contact_phone?: string | null
          coverage_area?: string | null
          created_at?: string
          description?: string | null
          id: string
          is_online?: boolean
          no_show_count?: number
          rating?: number
          review_count?: number
          services?: string[]
          state?: string | null
          updated_at?: string
          verification_documents?: Json
          verification_status?: string
        }
        Update: {
          approval_status?: string
          assignments_accepted?: number
          assignments_declined?: number
          assignments_expired?: number
          business_name?: string
          cancelled_jobs?: number
          city?: string | null
          completed_jobs?: number
          contact_email?: string | null
          contact_phone?: string | null
          coverage_area?: string | null
          created_at?: string
          description?: string | null
          id?: string
          is_online?: boolean
          no_show_count?: number
          rating?: number
          review_count?: number
          services?: string[]
          state?: string | null
          updated_at?: string
          verification_documents?: Json
          verification_status?: string
        }
        Relationships: []
      }
      reviews: {
        Row: {
          booking_id: string
          comment: string | null
          created_at: string
          customer_id: string
          id: string
          provider_id: string | null
          rating: number
          service: string
        }
        Insert: {
          booking_id: string
          comment?: string | null
          created_at?: string
          customer_id: string
          id?: string
          provider_id?: string | null
          rating: number
          service?: string
        }
        Update: {
          booking_id?: string
          comment?: string | null
          created_at?: string
          customer_id?: string
          id?: string
          provider_id?: string | null
          rating?: number
          service?: string
        }
        Relationships: [
          {
            foreignKeyName: "reviews_booking_id_fkey"
            columns: ["booking_id"]
            isOneToOne: true
            referencedRelation: "bookings"
            referencedColumns: ["id"]
          },
        ]
      }
      user_roles: {
        Row: {
          created_at: string
          id: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Insert: {
          created_at?: string
          id?: string
          role: Database["public"]["Enums"]["app_role"]
          user_id: string
        }
        Update: {
          created_at?: string
          id?: string
          role?: Database["public"]["Enums"]["app_role"]
          user_id?: string
        }
        Relationships: []
      }
      wallet_transactions: {
        Row: {
          amount: number
          created_at: string
          description: string
          id: string
          status: string
          user_id: string
        }
        Insert: {
          amount: number
          created_at?: string
          description: string
          id?: string
          status?: string
          user_id: string
        }
        Update: {
          amount?: number
          created_at?: string
          description?: string
          id?: string
          status?: string
          user_id?: string
        }
        Relationships: []
      }
      booking_assignments: {
        Row: {
          booking_id: string
          created_at: string
          id: string
          match_score: number | null
          offered_at: string
          provider_id: string
          responded_at: string | null
          responds_by: string
          status: string
        }
        Insert: {
          booking_id: string
          created_at?: string
          id?: string
          match_score?: number | null
          offered_at?: string
          provider_id: string
          responded_at?: string | null
          responds_by: string
          status?: string
        }
        Update: {
          booking_id?: string
          created_at?: string
          id?: string
          match_score?: number | null
          offered_at?: string
          provider_id?: string
          responded_at?: string | null
          responds_by?: string
          status?: string
        }
        Relationships: []
      }
      payouts: {
        Row: {
          booking_id: string
          commission_amount: number
          created_at: string
          gross_amount: number
          held_reason: string | null
          id: string
          payout_amount: number
          provider_id: string | null
          released_at: string | null
          status: string
          updated_at: string
        }
        Insert: {
          booking_id: string
          commission_amount: number
          created_at?: string
          gross_amount: number
          held_reason?: string | null
          id?: string
          payout_amount: number
          provider_id?: string | null
          released_at?: string | null
          status?: string
          updated_at?: string
        }
        Update: {
          booking_id?: string
          commission_amount?: number
          created_at?: string
          gross_amount?: number
          held_reason?: string | null
          id?: string
          payout_amount?: number
          provider_id?: string | null
          released_at?: string | null
          status?: string
          updated_at?: string
        }
        Relationships: []
      }
      disputes: {
        Row: {
          booking_id: string
          created_at: string
          customer_id: string
          description: string | null
          id: string
          reason: string
          resolution: string | null
          resolved_at: string | null
          resolved_by: string | null
          status: string
        }
        Insert: {
          booking_id: string
          created_at?: string
          customer_id: string
          description?: string | null
          id?: string
          reason: string
          resolution?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
        }
        Update: {
          booking_id?: string
          created_at?: string
          customer_id?: string
          description?: string | null
          id?: string
          reason?: string
          resolution?: string | null
          resolved_at?: string | null
          resolved_by?: string | null
          status?: string
        }
        Relationships: []
      }
      platform_settings: {
        Row: {
          description: string | null
          key: string
          updated_at: string
          value: Json
        }
        Insert: {
          description?: string | null
          key: string
          updated_at?: string
          value: Json
        }
        Update: {
          description?: string | null
          key?: string
          updated_at?: string
          value?: Json
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      has_role: {
        Args: {
          _role: Database["public"]["Enums"]["app_role"]
          _user_id: string
        }
        Returns: boolean
      }
    }
    Enums: {
      app_role: "customer" | "provider" | "admin"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends (DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never) = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends (DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never) = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends (PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never) = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      app_role: ["customer", "provider", "admin"],
    },
  },
} as const
