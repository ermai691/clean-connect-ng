import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { SERVICE_CATALOG, SEVERITY_LEVELS, type JobDetails } from "@/lib/service-catalog";
import { createQuotationRequest } from "@/lib/quotation.functions";
import { supabase } from "@/integrations/supabase/client";
import { currentCustomer } from "@/lib/customer-auth";

export const Route = createFileRoute("/customer/request-quote")({
  component: RequestQuotePage,
});

const QUOTE_SERVICES = SERVICE_CATALOG.filter((s) => s.bookingMode === "quote");

const MAX_FILES = 6;
const MAX_BYTES = 10 * 1024 * 1024;
const ALLOWED = new Set([
  "image/jpeg",
  "image/png",
  "image/webp",
  "video/mp4",
  "video/quicktime",
]);

function RequestQuotePage() {
  const navigate = useNavigate();
  const [serviceId, setServiceId] = useState(QUOTE_SERVICES[0]?.id ?? "");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [bedrooms, setBedrooms] = useState(2);
  const [bathrooms, setBathrooms] = useState(1);
  const [areaSqm, setAreaSqm] = useState(50);
  const [severity, setSeverity] = useState(SEVERITY_LEVELS[0]!.id);
  const [guests, setGuests] = useState(50);
  const [files, setFiles] = useState<File[]>([]);
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);
  const [done, setDone] = useState<{ reference: string; id: string } | null>(null);

  const service = useMemo(
    () => QUOTE_SERVICES.find((s) => s.id === serviceId) ?? QUOTE_SERVICES[0],
    [serviceId],
  );

  const jobDetails: JobDetails = useMemo(() => {
    if (!service) return {};
    switch (service.sizeUnit) {
      case "rooms":
        return { bedrooms, bathrooms };
      case "area":
        return { areaSqm, severity };
      case "guests":
        return { guests };
      default:
        return {};
    }
  }, [service, bedrooms, bathrooms, areaSqm, severity, guests]);

  function onFiles(list: FileList | null) {
    if (!list) return;
    const next = [...files];
    for (const f of Array.from(list)) {
      if (next.length >= MAX_FILES) break;
      if (!ALLOWED.has(f.type)) {
        setErr(`Unsupported file type: ${f.name}`);
        continue;
      }
      if (f.size > MAX_BYTES) {
        setErr(`${f.name} exceeds 10 MB.`);
        continue;
      }
      next.push(f);
    }
    setFiles(next);
  }

  async function onSubmit(e: React.FormEvent) {
    e.preventDefault();
    setErr(null);
    if (!service || service.bookingMode !== "quote") {
      setErr("Please select a quotation-only service.");
      return;
    }
    if (!address.trim()) {
      setErr("Please enter the service address.");
      return;
    }

    setSaving(true);
    try {
      const customer = await currentCustomer();
      if (!customer) {
        setErr("Please sign in as a customer.");
        setSaving(false);
        return;
      }

      // Create row first (empty attachments) so we have quotation id for storage paths.
      const created = await createQuotationRequest({
        data: {
          serviceId: service.id,
          jobDetails,
          address: address.trim(),
          notes: notes.trim() || undefined,
          attachmentPaths: [],
        },
      });
      if (!created.ok) {
        setErr(created.error);
        setSaving(false);
        return;
      }

      const qid = created.quotation.id;
      const paths: string[] = [];
      for (const file of files) {
        const safe = file.name.replace(/[^a-zA-Z0-9._-]/g, "_").slice(0, 80);
        const path = `${customer.id}/${qid}/${Date.now()}-${safe}`;
        const { error: upErr } = await supabase.storage
          .from("quotation-attachments")
          .upload(path, file, { contentType: file.type, upsert: false });
        if (upErr) {
          setErr(`Upload failed for ${file.name}: ${upErr.message}`);
          // Quotation already exists; still show success with partial files.
          break;
        }
        paths.push(path);
      }

      if (paths.length > 0) {
        await (supabase as any)
          .from("quotations")
          .update({ attachment_paths: paths })
          .eq("id", qid)
          .eq("customer_id", customer.id)
          .eq("status", "submitted");
      }

      setDone({ reference: created.quotation.reference, id: qid });
    } catch (ex) {
      setErr(ex instanceof Error ? ex.message : "Could not submit request.");
    } finally {
      setSaving(false);
    }
  }

  if (done) {
    return (
      <div className="cd-page">
        <div className="pd-panel" style={{ maxWidth: 520, margin: "2rem auto", textAlign: "center" }}>
          <i className="fas fa-circle-check" style={{ fontSize: 40, color: "var(--primary)" }} />
          <h1 style={{ marginTop: 12 }}>Request submitted</h1>
          <p>
            Your quotation reference is <strong>{done.reference}</strong>. CleanConnect will review the
            job and send a quotation to your dashboard.
          </p>
          <div style={{ display: "flex", gap: 12, justifyContent: "center", marginTop: 20 }}>
            <Link to="/customer/quotations" className="pd-btn pd-btn-primary">
              View my quotations
            </Link>
            <button type="button" className="pd-btn" onClick={() => navigate({ to: "/customer" })}>
              Dashboard
            </button>
          </div>
        </div>
      </div>
    );
  }

  if (QUOTE_SERVICES.length === 0) {
    return (
      <div className="cd-page">
        <p>No quotation services are configured.</p>
      </div>
    );
  }

  return (
    <div className="cd-page">
      <div className="pd-page-head">
        <div>
          <h1>Request a Quote</h1>
          <p>
            For specialist and large-scale jobs assessed by CleanConnect&apos;s team — not marketplace
            providers. You will receive a custom quotation before any payment.
          </p>
        </div>
      </div>

      <form className="pd-panel cd-form" onSubmit={onSubmit}>
        <label className="cd-field">
          <span>Service</span>
          <select value={serviceId} onChange={(e) => setServiceId(e.target.value)} required>
            {QUOTE_SERVICES.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name}
              </option>
            ))}
          </select>
        </label>

        {service?.sizeUnit === "rooms" && (
          <div className="cd-form-row">
            <label className="cd-field">
              <span>Bedrooms</span>
              <input
                type="number"
                min={1}
                max={50}
                value={bedrooms}
                onChange={(e) => setBedrooms(Math.max(1, Number(e.target.value) || 1))}
              />
            </label>
            <label className="cd-field">
              <span>Bathrooms</span>
              <input
                type="number"
                min={0}
                max={50}
                value={bathrooms}
                onChange={(e) => setBathrooms(Math.max(0, Number(e.target.value) || 0))}
              />
            </label>
          </div>
        )}

        {service?.sizeUnit === "area" && (
          <div className="cd-form-row">
            <label className="cd-field">
              <span>Approximate size (sqm)</span>
              <input
                type="number"
                min={1}
                max={50000}
                value={areaSqm}
                onChange={(e) => setAreaSqm(Math.max(1, Number(e.target.value) || 1))}
              />
            </label>
            {(service.id === "postcon" || service.id === "postreno") && (
              <label className="cd-field">
                <span>Site condition</span>
                <select value={severity} onChange={(e) => setSeverity(e.target.value)}>
                  {SEVERITY_LEVELS.map((l) => (
                    <option key={l.id} value={l.id}>
                      {l.name}
                    </option>
                  ))}
                </select>
              </label>
            )}
          </div>
        )}

        {service?.sizeUnit === "guests" && (
          <label className="cd-field">
            <span>Expected guests</span>
            <input
              type="number"
              min={1}
              max={10000}
              value={guests}
              onChange={(e) => setGuests(Math.max(1, Number(e.target.value) || 1))}
            />
          </label>
        )}

        <label className="cd-field">
          <span>Service address</span>
          <input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Street, area, city"
            required
          />
        </label>

        <label className="cd-field">
          <span>Job description / notes (optional)</span>
          <textarea
            value={notes}
            onChange={(e) => setNotes(e.target.value)}
            rows={4}
            placeholder="Describe the site, access, timing constraints, or special requirements…"
          />
        </label>

        <label className="cd-field">
          <span>Photos or videos (optional, max {MAX_FILES}, 10 MB each)</span>
          <input
            type="file"
            accept="image/jpeg,image/png,image/webp,video/mp4,video/quicktime"
            multiple
            onChange={(e) => onFiles(e.target.files)}
          />
          {files.length > 0 && (
            <ul style={{ marginTop: 8, fontSize: 14 }}>
              {files.map((f) => (
                <li key={f.name + f.size}>
                  {f.name} ({Math.round(f.size / 1024)} KB)
                </li>
              ))}
            </ul>
          )}
        </label>

        {err && (
          <p className="pd-error" role="alert">
            {err}
          </p>
        )}

        <button type="submit" className="pd-btn pd-btn-primary" disabled={saving}>
          {saving ? "Submitting…" : "Submit quotation request"}
        </button>
      </form>
    </div>
  );
}
