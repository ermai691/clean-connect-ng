import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { dashboardPathFor, getUser } from "@/lib/auth";
import { currentCustomer } from "@/lib/customer-auth";
import { currentProvider } from "@/lib/provider-auth";
import { currentAdmin } from "@/lib/admin-auth";

export const Route = createFileRoute("/dashboard")({
  ssr: false,
  component: DashboardRedirect,
});

function DashboardRedirect() {
  const navigate = useNavigate();

  useEffect(() => {
    let active = true;
    const goToLogin = () => active && navigate({ to: "/auth/$role", params: { role: "customer" }, replace: true });

    (async () => {
      try {
        // Real backend sessions take priority over the legacy local mirror,
        // since customer/provider/admin logins no longer write to it.
        const [customer, provider, admin] = await Promise.all([
          currentCustomer().catch(() => null),
          currentProvider().catch(() => null),
          currentAdmin().catch(() => null),
        ]);
        if (!active) return;
        if (customer) return navigate({ to: "/customer", replace: true });
        if (provider) return navigate({ to: "/provider", replace: true });
        if (admin) return navigate({ to: "/admin", replace: true });

        const user = getUser();
        if (!user) return goToLogin();
        navigate({ to: dashboardPathFor(user.role), replace: true });
      } catch {
        goToLogin();
      }
    })();

    return () => {
      active = false;
    };
  }, [navigate]);

  return (
    <div className="auth-shell">
      <div className="auth-card" style={{ textAlign: "center" }}>
        <p className="sub"><i className="fas fa-spinner fa-spin" /> Taking you to your dashboard…</p>
      </div>
    </div>
  );
}
