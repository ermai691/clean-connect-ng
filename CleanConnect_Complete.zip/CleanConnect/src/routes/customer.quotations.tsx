import { createFileRoute, Link } from "@tanstack/react-router";
import { useState } from "react";
import {
  useCustomerQuotations,
  getQuotationAttachmentUrl,
  STATUS_LABELS,
  type Quotation,
} from "@/lib/quotation-data";
import { cancelQuotationRequest, acceptQuotationWithFeeChoice, declineQuotation, initializeQuotationPayment } from "@/lib/quotation.functions";
import { ngn } from "@/lib/service-catalog";
import { EmptyState, Skeletons, ErrorState } from "@/components/CustomerShell";

export const Route = createFileRoute("/customer/quotations")({
  component: CustomerQuotationsPage,
});

function CustomerQuotationsPage() {
  const { quotations, loading, error, reload } = useCustomerQuotations();
  const [selected, setSelected] = useState<Quotation | null>(null);
  const [busy, setBusy] = useState(false);
  const [actionErr, setActionErr] = useState<string | null>(null);

  async function cancel(q: Quotation) {
    setBusy(true);
    setActionErr(null);
    const res = await cancelQuotationRequest({ data: { quotationId: q.id } });
    setBusy(false);
    if (!res.ok) {
      setActionErr(res.error);
      return;
    }
    setSelected(null);
    await reload();
  }

  const [approveFee, setApproveFee] = useState(false);

  async function accept(q: Quotation) {
    setBusy(true);
    setActionErr(null);
    const res = await acceptQuotationWithFeeChoice({
      data: { quotationId: q.id, approveInspectionFee: approveFee },
    });
    setBusy(false);
    if (!res.ok) {
      setActionErr(res.error);
      return;
    }
    await reload();
    setSelected((prev) => (prev ? { ...prev, status: "accepted" } : null));
  }

  async function pay(q: Quotation) {
    setBusy(true);
    setActionErr(null);
    const res = await initializeQuotationPayment({
      data: {
        quotationId: q.id,
        callbackUrl: `${window.location.origin}/customer/quotations`,
      },
    });
    setBusy(false);
    if (!res.ok) {
      setActionErr(res.error);
      return;
    }
    window.location.href = res.authorizationUrl;
  }

  async function decline(q: Quotation) {
    setBusy(true);
    setActionErr(null);
    const res = await declineQuotation({ data: { quotationId: q.id } });
    setBusy(false);
    if (!res.ok) {
      setActionErr(res.error);
      return;
    }
    await reload();
    setSelected((prev) => (prev ? { ...prev, status: "declined" } : null));
  }

  if (loading) return <Skeletons rows={5} />;
  if (error) return <ErrorState message={error} onRetry={() => void reload()} />;

  return (
    <div className="cd-page">
      <div className="pd-page-head">
        <div>
          <h1>My Quotations</h1>
          <p>Track Request a Quote submissions and respond when CleanConnect sends a price.</p>
        </div>
        <Link to="/customer/request-quote" className="pd-btn pd-btn-primary">
          Request a Quote
        </Link>
      </div>

      {quotations.length === 0 ? (
        <EmptyState
          icon="fa-file-invoice"
          title="No quotation requests yet"
          body="Specialist and large-scale jobs start with a custom quote from CleanConnect."
          action={{ label: "Request a Quote", to: "/customer/request-quote" }}
        />
      ) : (
        <div className="pd-panel">
          <table className="pd-table">
            <thead>
              <tr>
                <th>Reference</th>
                <th>Service</th>
                <th>Status</th>
                <th>Submitted</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {quotations.map((q) => (
                <tr key={q.id}>
                  <td>{q.reference}</td>
                  <td>{q.service_name}</td>
                  <td>
                    <span className={`pd-badge status-${q.status}`}>{STATUS_LABELS[q.status]}</span>
                  </td>
                  <td>{new Date(q.created_at).toLocaleDateString("en-NG")}</td>
                  <td>
                    <button type="button" className="pd-btn pd-btn-sm" onClick={() => setSelected(q)}>
                      View
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {selected && (
        <QuotationDetail
          q={selected}
          busy={busy}
          error={actionErr}
          approveFee={approveFee}
          onApproveFeeChange={setApproveFee}
          onClose={() => {
            setSelected(null);
            setActionErr(null);
          }}
          onCancel={() => void cancel(selected)}
          onAccept={() => void accept(selected)}
          onDecline={() => void decline(selected)}
          onPay={() => void pay(selected)}
        />
      )}
    </div>
  );
}

function QuotationDetail({
  q,
  busy,
  error,
  approveFee,
  onApproveFeeChange,
  onClose,
  onCancel,
  onAccept,
  onDecline,
  onPay,
}: {
  q: Quotation;
  busy: boolean;
  error: string | null;
  approveFee: boolean;
  onApproveFeeChange: (v: boolean) => void;
  onClose: () => void;
  onCancel: () => void;
  onAccept: () => void;
  onDecline: () => void;
  onPay: () => void;
}) {
  const [urls, setUrls] = useState<Record<string, string>>({});

  async function loadAttachment(path: string) {
    if (urls[path]) return;
    const url = await getQuotationAttachmentUrl(path);
    if (url) setUrls((u) => ({ ...u, [path]: url }));
  }

  const expired = q.valid_until ? new Date(q.valid_until).getTime() < Date.now() : false;
  const canDecide = q.status === "quoted" && !expired;

  return (
    <div className="pd-modal-backdrop" role="dialog" aria-modal="true">
      <div className="pd-modal" style={{ maxWidth: 560 }}>
        <header className="pd-card-head">
          <h2>
            {q.reference} · {STATUS_LABELS[q.status]}
          </h2>
          <button type="button" className="pd-btn pd-btn-sm" onClick={onClose}>
            Close
          </button>
        </header>
        <div className="pd-modal-body">
          <p>
            <strong>Service:</strong> {q.service_name}
          </p>
          <p>
            <strong>Address:</strong> {q.address}
          </p>
          {q.notes && (
            <p>
              <strong>Notes:</strong> {q.notes}
            </p>
          )}
          <p>
            <strong>Job details:</strong>{" "}
            <code style={{ fontSize: 13 }}>{JSON.stringify(q.job_details)}</code>
          </p>

          {q.status === "quoted" || q.status === "accepted" ? (
            <div className="pd-panel" style={{ marginTop: 12 }}>
              <p>
                <strong>Quoted amount:</strong> {q.quoted_amount != null ? ngn(q.quoted_amount) : "—"}
              </p>
              {q.inspection_fee != null && q.inspection_fee > 0 && (
                <p>
                  <strong>Inspection fee (disclosed):</strong> {ngn(q.inspection_fee)}
                  <br />
                  <small>Only charged if you approve before payment.</small>
                </p>
              )}
              {q.valid_until && (
                <p>
                  <strong>Valid until:</strong> {new Date(q.valid_until).toLocaleString("en-NG")}
                  {expired && " (expired)"}
                </p>
              )}
            </div>
          ) : null}

          {q.attachment_paths?.length > 0 && (
            <div style={{ marginTop: 12 }}>
              <strong>Attachments</strong>
              <ul>
                {q.attachment_paths.map((p) => (
                  <li key={p}>
                    <button type="button" className="pd-btn pd-btn-sm" onClick={() => void loadAttachment(p)}>
                      {urls[p] ? "Refresh link" : "View file"}
                    </button>
                    {urls[p] && (
                      <a href={urls[p]} target="_blank" rel="noreferrer" style={{ marginLeft: 8 }}>
                        Open
                      </a>
                    )}
                  </li>
                ))}
              </ul>
            </div>
          )}

          {error && (
            <p className="pd-error" role="alert">
              {error}
            </p>
          )}

          <div style={{ display: "flex", gap: 8, marginTop: 16, flexWrap: "wrap", flexDirection: "column" }}>
            {q.status === "submitted" && (
              <button type="button" className="pd-btn" disabled={busy} onClick={onCancel}>
                Cancel request
              </button>
            )}
            {canDecide && (
              <>
                {q.inspection_fee != null && q.inspection_fee > 0 && (
                  <label style={{ display: "flex", gap: 8, alignItems: "center" }}>
                    <input
                      type="checkbox"
                      checked={approveFee}
                      onChange={(e) => onApproveFeeChange(e.target.checked)}
                    />
                    <span>
                      I approve the disclosed inspection fee of {ngn(q.inspection_fee)} (added only if checked)
                    </span>
                  </label>
                )}
                <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
                  <button type="button" className="pd-btn pd-btn-primary" disabled={busy} onClick={onAccept}>
                    Accept quotation
                  </button>
                  <button type="button" className="pd-btn" disabled={busy} onClick={onDecline}>
                    Decline
                  </button>
                </div>
              </>
            )}
            {q.status === "accepted" && (
              <button type="button" className="pd-btn pd-btn-primary" disabled={busy} onClick={onPay}>
                Pay with Paystack
              </button>
            )}
            {(q.status === "paid" || q.status === "assigned") && (
              <p className="pd-muted">
                Payment verified. CleanConnect will assign an internal team — this is not a marketplace provider job.
              </p>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
