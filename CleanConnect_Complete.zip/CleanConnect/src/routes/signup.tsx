import { createFileRoute, Navigate } from "@tanstack/react-router";

export const Route = createFileRoute("/signup")({
  component: () => <Navigate to="/auth/$role" params={{ role: "customer" }} replace />,
});
