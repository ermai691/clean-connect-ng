import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import {
  PACKAGES,
  SERVICE_CATALOG,
  SEVERITY_LEVELS,
  estimateBreakdown,
  ngn,
  type JobDetails,
} from "@/lib/service-catalog";
import { useCustomerData } from "@/lib/customer-data";
import { createBookingServerSide } from "@/lib/booking.functions";
import { initializePaystackPayment } from "@/lib/payment.functions";

export const Route = createFileRoute("/customer/book")({
  component: BookService,
});

/** Services eligible for the online booking form.
 * Only services explicitly classified as "direct" are shown.
 * All others must use Request a Quote. Frontend filter is convenience only;
 * the server enforces the same rule. */
const BOOKABLE_SERVICES = SERVICE_CATALOG.filter((s) => s.bookingMode === "direct");

function todayISO() {
  const d = new Date();
  return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, "0")}-${String(d.getDate()).padStart(2, "0")}`;
}

function BookService() {
  const navigate = useNavigate();
  const { data } = useCustomerData();
  const [step, setStep] = useState<"form" | "review">("form");
  const [serviceId, setServiceId] = useState(BOOKABLE_SERVICES[0]!.id);
  const [pkg, setPkg] = useState(PACKAGES[0]!.id);
  const [date, setDate] = useState("");
  const [time, setTime] = useState("");
  const [address, setAddress] = useState("");
  const [notes, setNotes] = useState("");
  const [method, setMethod] = useState("Card");
  const [saving, setSaving] = useState(false);
  const [err, setErr] = useState<string | null>(null);

  // Job size/scope — which fields matter depends on the service's sizeUnit.
  const [bedrooms, setBedrooms] = useState(2);
  const [bathrooms, setBathrooms] = useState(1);
  const [areaSqm, setAreaSqm] = useState(50);
  const [severity, setSeverity] = useState(SEVERITY_LEVELS[0]!.id);
  const [guests, setGuests] = useState(50);
  const [loads, setLoads] = useState(1);

  const service = SERVICE_CATALOG.find((s) => s.id === serviceId) ?? BOOKABLE_SERVICES[0]!;
  const selectedPkg = PACKAGES.find((p) => p.id === pkg)!;
  const minDate = useMemo(() => todayISO(), []);

  const jobDetails: JobDetails = useMemo(() => {
    switch (service.sizeUnit) {
      case "rooms":
        return { bedrooms, bathrooms };
      case "area":
        return { areaSqm, severity };
      case "guests":
        return { guests };
      case "loads":
        return { loads };
      default:
        return {};
    }
  }, [service.sizeUnit, bedrooms, bathrooms, areaSqm, severity, guests, loads]);

  const breakdown = useMemo(() => estimateBreakdown(service, jobDetails), [service, jobDetails]);
  const packageFee = Math.round(breakdown.subtotal * (selectedPkg.multiplier - 1));
  const total = breakdown.subtotal + packageFee;

  const isPastDate = date && date < minDate;
  const isToday = date === minDate;
  const now = new Date();
  const nowHM = `${String(now.getHours()).padStart(2, "0")}:${String(now.getMinutes()).padStart(2, "0")}`;
  const isPastTimeToday = isToday && time && time < nowHM;

  const validationError = (): string | null => {
    if (!date || !time || !address.trim()) return "Please choose a date, time and service address.";
    if (isPastDate) return "Please choose a date that hasn't passed yet.";
    if (isPastTimeToday) return "That time today has already passed — pick a later time or a different date.";
    return null;
  };

  const goToReview = (e: React.FormEvent) => {
    e.preventDefault();
    const v = validationError();
    if (v) return setErr(v);
    setErr(null);
    setStep("review");
  };

  const confirm = async () => {
    setErr(null);
    setSaving(true);
    const res = await createBookingServerSide({
      data: {
        serviceId: service.id,
        packageId: selectedPkg.id,
        jobDetails,
        scheduledFor: new Date(`${date}T${time}`).toISOString(),
        address: address.trim(),
        notes: notes.trim(),
        method,
      },
    });
    if (!res.ok) {
      setSaving(false);
      return setErr(res.error);
    }

    // Booking is created (status: payment_pending) but nothing is confirmed
    // yet — hand off to Paystack. The booking only becomes "paid" once our
    // webhook verifies the transaction server-side, never from this redirect.
    const payRes = await initializePaystackPayment({
      data: {
        bookingId: res.booking.id,
        callbackUrl: `${window.location.origin}/customer/payment-callback?booking=${res.booking.id}`,
      },
    });
    setSaving(false);
    if (!payRes.ok) {
      setErr(payRes.error);
      return;
    }
    window.location.href = payRes.authorizationUrl;
  };

  if (step === "review") {
    return (
      <div className="cd-page">
        <div className="pd-page-head">
          <div>
            <h1>Review your booking</h1>
            <p>Check everything below is right before you confirm — a provider will be matched once you do.</p>
          </div>
        </div>

        <div className="pd-panel cd-form">
          <div className="cd-field">
            <span>Service</span>
            <strong>{service.name} ({selectedPkg.name})</strong>
          </div>
          <div className="cd-form-row">
            <div className="cd-field">
              <span>Date & time</span>
              <strong>{date} at {time}</strong>
            </div>
            <div className="cd-field">
              <span>Payment method</span>
              <strong>{method}</strong>
            </div>
          </div>
          <div className="cd-field">
            <span>Service address</span>
            <strong>{address}</strong>
          </div>
          {notes.trim() && (
            <div className="cd-field">
              <span>Notes for the professional</span>
              <strong>{notes}</strong>
            </div>
          )}

          <div className="cd-field">
            <span>Price breakdown</span>
            <div style={{ display: "grid", gap: 6, fontSize: ".88rem" }}>
              {breakdown.lines.map((line, i) => (
                <div key={i} style={{ display: "flex", justifyContent: "space-between", color: "var(--muted-foreground)" }}>
                  <span>{line.label}</span>
                  <span>{ngn(line.amount)}</span>
                </div>
              ))}
              {packageFee > 0 && (
                <div style={{ display: "flex", justifyContent: "space-between", color: "var(--muted-foreground)" }}>
                  <span>{selectedPkg.name} package</span>
                  <span>{ngn(packageFee)}</span>
                </div>
              )}
            </div>
          </div>

          <div className="cd-total">
            <span>Estimated total</span>
            <strong>{ngn(total)}</strong>
          </div>
          <p style={{ fontSize: ".78rem", color: "var(--muted-foreground)", margin: 0 }}>
            This is an estimate based on what you've told us. Your provider may confirm a small adjustment once they see the job in person.
          </p>

          {err && <p className="cd-error">{err}</p>}

          <div style={{ display: "flex", gap: 12 }}>
            <button type="button" className="pd-btn pd-btn-light" onClick={() => setStep("form")} disabled={saving}>
              Back and edit
            </button>
            <button type="button" className="pd-btn pd-btn-primary" onClick={confirm} disabled={saving} style={{ flex: 1 }}>
              {saving ? "Confirming…" : "Confirm booking"}
            </button>
          </div>
        </div>
      </div>
    );
  }

  return (
    <div className="cd-page">
      <div className="pd-page-head">
        <div>
          <h1>Book a Service</h1>
          <p>Choose a service, tell us the size of the job, pick a time — we'll match you with a verified professional.</p>
        </div>
      </div>

      <form className="pd-panel cd-form" onSubmit={goToReview}>
        <label className="cd-field">
          <span>Service</span>
          <select value={serviceId} onChange={(e) => setServiceId(e.target.value)}>
            {BOOKABLE_SERVICES.map((s) => (
              <option key={s.id} value={s.id}>
                {s.name} — from {ngn(s.price)}
              </option>
            ))}
          </select>
        </label>

        {service.sizeUnit === "rooms" && (
          <div className="cd-form-row">
            <label className="cd-field">
              <span>Bedrooms</span>
              <input
                type="number"
                min={1}
                max={20}
                value={bedrooms}
                onChange={(e) => setBedrooms(Math.max(1, Number(e.target.value) || 1))}
              />
            </label>
            <label className="cd-field">
              <span>Bathrooms</span>
              <input
                type="number"
                min={0}
                max={20}
                value={bathrooms}
                onChange={(e) => setBathrooms(Math.max(0, Number(e.target.value) || 0))}
              />
            </label>
          </div>
        )}

        {service.sizeUnit === "area" && (
          <div className="cd-form-row">
            <label className="cd-field">
              <span>Approximate size (sqm)</span>
              <input
                type="number"
                min={1}
                max={5000}
                value={areaSqm}
                onChange={(e) => setAreaSqm(Math.max(1, Number(e.target.value) || 1))}
              />
            </label>
            {(service.id === "postcon" || service.id === "postreno") && (
              <label className="cd-field">
                <span>How messy is the site?</span>
                <select value={severity} onChange={(e) => setSeverity(e.target.value)}>
                  {SEVERITY_LEVELS.map((lvl) => (
                    <option key={lvl.id} value={lvl.id}>
                      {lvl.name}
                    </option>
                  ))}
                </select>
              </label>
            )}
          </div>
        )}

        {service.sizeUnit === "guests" && (
          <label className="cd-field">
            <span>Expected number of guests</span>
            <input
              type="number"
              min={1}
              max={5000}
              value={guests}
              onChange={(e) => setGuests(Math.max(1, Number(e.target.value) || 1))}
            />
          </label>
        )}

        {service.sizeUnit === "loads" && (
          <label className="cd-field">
            <span>Number of loads / bags</span>
            <input
              type="number"
              min={1}
              max={50}
              value={loads}
              onChange={(e) => setLoads(Math.max(1, Number(e.target.value) || 1))}
            />
          </label>
        )}

        <label className="cd-field">
          <span>Package</span>
          <select value={pkg} onChange={(e) => setPkg(e.target.value)}>
            {PACKAGES.map((p) => (
              <option key={p.id} value={p.id}>
                {p.name}
              </option>
            ))}
          </select>
        </label>

        <div className="cd-form-row">
          <label className="cd-field">
            <span>Date</span>
            <input type="date" min={minDate} value={date} onChange={(e) => setDate(e.target.value)} required />
          </label>
          <label className="cd-field">
            <span>Time</span>
            <input type="time" min="07:00" max="20:00" value={time} onChange={(e) => setTime(e.target.value)} required />
          </label>
        </div>
        <p style={{ fontSize: ".78rem", color: "var(--muted-foreground)", margin: "-8px 0 0" }}>
          We currently take bookings between 7:00 AM and 8:00 PM.
        </p>

        <label className="cd-field">
          <span>Service address</span>
          {data.addresses.length > 0 && (
            <select
              value=""
              onChange={(e) => {
                const a = data.addresses.find((x) => x.id === e.target.value);
                if (a) setAddress([a.street, a.city, a.state].filter(Boolean).join(", "));
              }}
            >
              <option value="">Use a saved address…</option>
              {data.addresses.map((a) => (
                <option key={a.id} value={a.id}>
                  {a.label} — {a.street}
                </option>
              ))}
            </select>
          )}
          <input
            value={address}
            onChange={(e) => setAddress(e.target.value)}
            placeholder="Street, city, state"
            required
          />
        </label>

        <label className="cd-field">
          <span>Notes for the professional (optional)</span>
          <textarea rows={3} value={notes} onChange={(e) => setNotes(e.target.value)} />
        </label>

        <label className="cd-field">
          <span>Payment method</span>
          <select value={method} onChange={(e) => setMethod(e.target.value)}>
            <option>Card</option>
            <option>Bank Transfer</option>
            <option>Wallet</option>
            <option>Cash on Delivery</option>
          </select>
        </label>

        <div className="cd-field">
          <span>Price breakdown</span>
          <div style={{ display: "grid", gap: 6, fontSize: ".88rem" }}>
            {breakdown.lines.map((line, i) => (
              <div key={i} style={{ display: "flex", justifyContent: "space-between", color: "var(--muted-foreground)" }}>
                <span>{line.label}</span>
                <span>{ngn(line.amount)}</span>
              </div>
            ))}
            {packageFee > 0 && (
              <div style={{ display: "flex", justifyContent: "space-between", color: "var(--muted-foreground)" }}>
                <span>{selectedPkg.name} package</span>
                <span>{ngn(packageFee)}</span>
              </div>
            )}
          </div>
        </div>

        <div className="cd-total">
          <span>Estimated total</span>
          <strong>{ngn(total)}</strong>
        </div>

        {err && <p className="cd-error">{err}</p>}

        <button type="submit" className="pd-btn pd-btn-primary">
          Review booking
        </button>
      </form>
    </div>
  );
}
