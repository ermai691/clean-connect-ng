import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useEffect } from "react";
import { z } from "zod";

// This route used to be a standalone booking wizard backed by
// lib/platform-data.ts (localStorage, amount hardcoded to 0 — it never
// actually charged or persisted a real booking). The real, working booking
// flow lives at /customer/book and is backed by Supabase. Rather than
// maintaining two divergent booking UIs, this route now forwards there,
// preserving the ?service= deep link.
const searchSchema = z.object({ service: z.string().optional() });

export const Route = createFileRoute("/booking")({
  validateSearch: searchSchema,
  component: BookingRedirect,
});

function BookingRedirect() {
  const navigate = useNavigate();

  useEffect(() => {
    // Note: /customer/book doesn't currently read a ?service= deep link —
    // that's a small follow-up, not part of this redirect fix.
    navigate({ to: "/customer/book", replace: true });
  }, [navigate]);

  return null;
}
