import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useRef, useState } from "react";
import { RoleGuard } from "@/components/RoleGuard";
import { getUser, logout } from "@/lib/auth";
import { signOutAdmin } from "@/lib/admin-auth";
import logoMark from "@/assets/cleanconnect-mark.png.asset.json";
import {
  MONTH_LABELS,
  formatNaira,
  selectAdminStats,
  selectCategoryBreakdown,
  selectMonthlyBookings,
  selectMonthlyRevenue,
  setProviderStatus,
  getProviderDocumentLinks,
  useAdminData,
  usePlatformSettings,
  updatePlatformSetting,
  type Booking,
  type AdminProvider,
  type AdminPayment,
} from "@/lib/admin-data";
import { SERVICE_CATALOG, ngn } from "@/lib/service-catalog";
import { supabase } from "@/integrations/supabase/client";
import { adminConfirmCompletionByPhone, adminResolveDispute } from "@/lib/completion.functions";
import {
  adminUpdateQuotationReview,
  adminSendQuotation,
  adminAssignQuotationJob,
  adminListQuotations,
} from "@/lib/quotation.functions";

export const Route = createFileRoute("/admin")({
  validateSearch: (search: Record<string, unknown>): { section?: string } => ({
    section: typeof search.section === "string" ? search.section : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Admin Dashboard — CleanConnect" },
      {
        name: "description",
        content:
          "Central control room for CleanConnect: manage customers, providers, bookings, payments and reviews across Abuja.",
      },
      { property: "og:title", content: "Admin Dashboard — CleanConnect" },
      {
        property: "og:description",
        content: "Manage customers, providers, bookings, payments and reviews on CleanConnect.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  ssr: false,
  component: () => (
    <RoleGuard role="admin">
      <AdminDashboard />
    </RoleGuard>
  ),
});

const NAV = [
  { icon: "fa-calendar-check", label: "Bookings" },
  { icon: "fa-hourglass-half", label: "Pending Confirmation" },
  { icon: "fa-scale-balanced", label: "Disputes" },
  { icon: "fa-file-invoice", label: "Quotations" },
  { icon: "fa-users", label: "Customers" },
  { icon: "fa-user-tie", label: "Providers" },
  { icon: "fa-broom", label: "Services" },
  { icon: "fa-credit-card", label: "Payments" },
  { icon: "fa-star", label: "Reviews" },
  { icon: "fa-chart-line", label: "Analytics" },
  { icon: "fa-comment-dots", label: "Messages", counter: "messages" as const },
  { icon: "fa-bell", label: "Notifications", counter: "notifications" as const },
  { icon: "fa-gear", label: "Settings" },
  { icon: "fa-circle-question", label: "Help & Support" },
];

const STATUS_TONE: Record<Booking["status"], string> = {
  payment_pending: "warn",
  paid: "info",
  finding_provider: "info",
  no_provider_available: "bad",
  assignment_pending: "info",
  provider_accepted: "info",
  on_the_way: "info",
  in_progress: "info",
  completed: "ok",
  awaiting_confirmation: "warn",
  confirmed_complete: "ok",
  disputed: "bad",
  payout_released: "ok",
  cancelled: "bad",
  rejected: "bad",
};

/* ---------------- charts (render real data, zero-safe) ---------------- */

function BarChart({ values, labels, money }: { values: number[]; labels: string[]; money?: boolean }) {
  const max = Math.max(...values, 0);
  const empty = max === 0;
  return (
    <div
      className="pd-bars"
      role="img"
      aria-label={empty ? "Chart with no data yet" : "Chart of monthly totals"}
    >
      {labels.map((l, i) => (
        <div className="pd-bar-col" key={l}>
          <div className="pd-bar-track">
            <div
              className="pd-bar-fill"
              style={{ height: empty ? "2px" : `${Math.max(4, ((values[i] ?? 0) / max) * 100)}%` }}
              title={money ? formatNaira(values[i] ?? 0) : String(values[i] ?? 0)}
            />
          </div>
          <span>{l}</span>
        </div>
      ))}
      {empty && <span className="pd-chart-empty">No data yet</span>}
    </div>
  );
}

function CategoryChart({ data }: { data: { category: string; pct: number }[] }) {
  if (!data.length) {
    return <EmptyState icon="fa-chart-pie" title="No service bookings yet." body="Category insights appear after the first booking." />;
  }
  return (
    <ul className="ad-legend">
      {data.map((d) => (
        <li key={d.category}>
          <span className="ad-legend-top">
            <strong>{d.category}</strong>
            <em>{d.pct.toFixed(0)}%</em>
          </span>
          <span className="pd-progress sm">
            <span style={{ width: `${d.pct}%` }} />
          </span>
        </li>
      ))}
    </ul>
  );
}

function EmptyState({ icon, title, body, cta }: { icon: string; title: string; body?: string; cta?: React.ReactNode }) {
  return (
    <div className="pd-empty">
      <span className="pd-empty-art" aria-hidden="true">
        <i className={`fas ${icon}`} />
      </span>
      <strong>{title}</strong>
      {body && <p>{body}</p>}
      {cta}
    </div>
  );
}

/* ---------------- page ---------------- */

/* ---------------- sidebar section panels (real data, honest gaps) ---------------- */

function BookingDetailModal({ booking, onClose }: { booking: Booking; onClose: () => void }) {
  return (
    <div className="cd-modal" role="dialog" aria-modal="true" aria-label={`Booking ${booking.reference}`}>
      <div className="cd-modal-card">
        <h2>Booking {booking.reference}</h2>
        <div style={{ display: "grid", gap: 10, margin: "12px 0", fontSize: ".92rem" }}>
          <div><strong>Customer:</strong> {booking.customerName}</div>
          <div><strong>Provider:</strong> {booking.providerName ?? "Unassigned"}</div>
          <div><strong>Service:</strong> {booking.service} ({booking.category})</div>
          <div><strong>Amount:</strong> {formatNaira(booking.amount)}</div>
          <div><strong>Scheduled for:</strong> {new Date(booking.scheduledFor).toLocaleString("en-NG")}</div>
          <div><strong>Status:</strong> <span className={`ad-badge ${STATUS_TONE[booking.status]}`}>{booking.status}</span></div>
          <div><strong>Created:</strong> {new Date(booking.createdAt).toLocaleString("en-NG")}</div>
        </div>
        <div className="cd-modal-actions">
          <button type="button" className="pd-btn pd-btn-ghost" onClick={onClose}>Close</button>
        </div>
      </div>
    </div>
  );
}

function BookingsSection({ bookings, onView }: { bookings: Booking[]; onView: (b: Booking) => void }) {
  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head">
        <h2><i className="fas fa-calendar-check" /> All Bookings</h2>
      </header>
      {bookings.length === 0 ? (
        <EmptyState icon="fa-calendar-xmark" title="No bookings yet." body="Bookings will appear here when customers request a service." />
      ) : (
        <div className="ad-table-wrap">
          <table className="ad-table">
            <caption className="sr-only">All bookings</caption>
            <thead>
              <tr>
                <th scope="col">Customer</th><th scope="col">Service</th><th scope="col">Provider</th>
                <th scope="col">Date</th><th scope="col">Amount</th><th scope="col">Status</th><th scope="col">Action</th>
              </tr>
            </thead>
            <tbody>
              {bookings.map((b) => (
                <tr key={b.id}>
                  <td data-label="Customer">{b.customerName}</td>
                  <td data-label="Service">{b.service}</td>
                  <td data-label="Provider">{b.providerName ?? "Unassigned"}</td>
                  <td data-label="Date">{new Date(b.scheduledFor || b.createdAt).toLocaleDateString("en-NG")}</td>
                  <td data-label="Amount">{formatNaira(b.amount)}</td>
                  <td data-label="Status"><span className={`ad-badge ${STATUS_TONE[b.status]}`}>{b.status}</span></td>
                  <td data-label="Action"><button type="button" className="pd-link" onClick={() => onView(b)}>View</button></td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </article>
  );
}

/** Generic read-only list panel, used for Customers and Reviews (real data,
 * no mutating actions currently supported for either). */
function SimpleDirectorySection({
  icon, title, emptyIcon, emptyTitle, emptyBody, rows,
}: {
  icon: string; title: string; emptyIcon: string; emptyTitle: string; emptyBody: string;
  rows: { id: string; title: string; subtitle: string; tag: string; tone: "ok" | "warn" | "bad" | "info" }[];
}) {
  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className={`fas ${icon}`} /> {title}</h2></header>
      {rows.length === 0 ? (
        <EmptyState icon={emptyIcon} title={emptyTitle} body={emptyBody} />
      ) : (
        <ul className="ad-requests">
          {rows.map((r) => (
            <li key={r.id}>
              <div><strong>{r.title}</strong><em>{r.subtitle}</em></div>
              <span className={`ad-badge ${r.tone}`}>{r.tag}</span>
            </li>
          ))}
        </ul>
      )}
    </article>
  );
}

function ProvidersSection({
  providers, openDocsFor, docLinks, docsLoading, onToggleDocs, onApprove, onReject,
}: {
  providers: AdminProvider[];
  openDocsFor: string | null;
  docLinks: { name: string; url: string }[];
  docsLoading: boolean;
  onToggleDocs: (id: string) => void;
  onApprove: (id: string) => void;
  onReject: (id: string) => void;
}) {
  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className="fas fa-user-tie" /> All Providers</h2></header>
      {providers.length === 0 ? (
        <EmptyState icon="fa-user-tie" title="No providers yet." body="Applications will appear here when professionals register." />
      ) : (
        <ul className="ad-requests">
          {providers.map((p) => (
            <li key={p.id} style={{ flexWrap: "wrap" }}>
              <span className="pd-avatar" aria-hidden="true"><i className="fas fa-user-tie" /></span>
              <div>
                <strong>{p.name}</strong>
                <em>{p.services.length ? p.services.join(", ") : "Cleaning services"}{p.location ? ` · ${p.location}` : ""}</em>
                <em>{p.rating ? `${p.rating.toFixed(1)}★` : "No rating yet"} · {p.verified ? "Verified" : "Awaiting verification"}</em>
              </div>
              <span className={`ad-badge ${p.status === "approved" ? "ok" : p.status === "rejected" ? "bad" : "warn"}`}>{p.status}</span>
              <div className="ad-req-actions">
                <button type="button" className="ad-btn" onClick={() => onToggleDocs(p.id)}>
                  {openDocsFor === p.id ? "Hide documents" : "View documents"}
                </button>
                {p.status === "pending" && (
                  <>
                    <button type="button" className="ad-btn ok" onClick={() => onApprove(p.id)}>Approve</button>
                    <button type="button" className="ad-btn bad" onClick={() => onReject(p.id)}>Reject</button>
                  </>
                )}
              </div>
              {openDocsFor === p.id && (
                <div style={{ width: "100%", padding: "10px 0 4px", display: "flex", gap: 12, flexWrap: "wrap" }}>
                  {docsLoading ? <em>Loading documents…</em> : docLinks.length === 0 ? <em>No documents on file.</em> : (
                    docLinks.map((d) => (
                      <a key={d.name} href={d.url} target="_blank" rel="noreferrer" className="ad-btn">
                        <i className="fas fa-file-image" /> {d.name.replace(/\.[a-z]+$/i, "")}
                      </a>
                    ))
                  )}
                </div>
              )}
            </li>
          ))}
        </ul>
      )}
    </article>
  );
}

function PaymentsSection({ payments }: { payments: AdminPayment[] }) {
  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className="fas fa-credit-card" /> Payments</h2></header>
      {payments.length === 0 ? (
        <EmptyState icon="fa-receipt" title="No payments yet." body="Payment records will appear here once customers start paying for bookings." />
      ) : (
        <div className="ad-table-wrap">
          <table className="ad-table">
            <caption className="sr-only">Payments</caption>
            <thead>
              <tr><th scope="col">Booking</th><th scope="col">Customer</th><th scope="col">Amount</th><th scope="col">Method</th><th scope="col">Status</th><th scope="col">Date</th></tr>
            </thead>
            <tbody>
              {payments.map((p) => (
                <tr key={p.id}>
                  <td data-label="Booking">{p.bookingReference}</td>
                  <td data-label="Customer">{p.customerName}</td>
                  <td data-label="Amount">{formatNaira(p.amount)}</td>
                  <td data-label="Method">{p.method}</td>
                  <td data-label="Status">
                    <span className={`ad-badge ${p.status === "successful" ? "ok" : p.status === "failed" || p.status === "refunded" ? "bad" : "warn"}`}>{p.status}</span>
                  </td>
                  <td data-label="Date">{new Date(p.createdAt).toLocaleDateString("en-NG")}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <p style={{ fontSize: ".78rem", color: "var(--muted-foreground)", marginTop: 12 }}>
        Refund and payout actions aren't built yet — this view is read-only.
      </p>
    </article>
  );
}

function ServicesSection() {
  const services = SERVICE_CATALOG;
  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className="fas fa-broom" /> Services</h2></header>
      <div className="ad-table-wrap">
        <table className="ad-table">
          <caption className="sr-only">Services</caption>
          <thead><tr><th scope="col">Service</th><th scope="col">Category</th><th scope="col">Starting price</th><th scope="col">Pricing basis</th></tr></thead>
          <tbody>
            {services.map((s) => (
              <tr key={s.id}>
                <td data-label="Service">{s.name}</td>
                <td data-label="Category">{s.category}</td>
                <td data-label="Starting price">{ngn(s.price)}</td>
                <td data-label="Pricing basis">{s.sizeUnit}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      <p style={{ fontSize: ".78rem", color: "var(--muted-foreground)", marginTop: 12 }}>
        This list comes from the app's service catalogue in code. There's no database-backed editor yet — changing prices or adding services still requires a code change.
      </p>
    </article>
  );
}

function AnalyticsSection({
  monthlyBookings, monthlyRevenue, categories, stats,
}: {
  monthlyBookings: number[]; monthlyRevenue: number[]; categories: { category: string; pct: number }[];
  stats: ReturnType<typeof selectAdminStats>;
}) {
  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className="fas fa-chart-line" /> Analytics</h2></header>
      <div style={{ display: "grid", gap: 10, marginBottom: 16, fontSize: ".92rem" }}>
        <div><strong>Total booking value (gross):</strong> {formatNaira(stats.totalRevenue)}</div>
        <div><strong>Total bookings:</strong> {stats.totalBookings} ({stats.completedBookings} completed)</div>
        <div style={{ color: "var(--muted-foreground)", fontSize: ".82rem" }}>
          Note: this is gross booking value, not CleanConnect's commission revenue — per-booking commission tracking (₦5,500 flat) isn't broken out here yet.
        </div>
      </div>
      <BarChart values={monthlyBookings} labels={MONTH_LABELS} />
      <div style={{ height: 20 }} />
      <BarChart values={monthlyRevenue} labels={MONTH_LABELS} money />
      <div style={{ height: 20 }} />
      <CategoryChart data={categories} />
    </article>
  );
}




function DisputesSection() {
  const [rows, setRows] = useState<any[]>([]);
  const [selected, setSelected] = useState<any | null>(null);
  const [resolution, setResolution] = useState("");
  const [msg, setMsg] = useState<string | null>(null);

  const load = async () => {
    const { data: bookings } = await supabase
      .from("bookings")
      .select("id, reference, service, status, completed_at, customer_id, provider_id, amount")
      .eq("status", "disputed")
      .order("updated_at", { ascending: false })
      .limit(50);
    setRows(bookings ?? []);
  };
  useEffect(() => {
    void load();
  }, []);

  const open = async (b: any) => {
    const { data: dispute } = await supabase
      .from("disputes")
      .select("id, reason, description, status, resolution, created_at, resolved_at")
      .eq("booking_id", b.id)
      .maybeSingle();
    setSelected({ ...b, dispute });
    setResolution("");
    setMsg(null);
  };

  const resolve = async (decision: "provider_entitled" | "provider_not_entitled") => {
    if (!selected) return;
    if (resolution.trim().length < 3) {
      setMsg("Enter a resolution reason.");
      return;
    }
    const res = await adminResolveDispute({
      data: { bookingId: selected.id, decision, resolution: resolution.trim() },
    });
    setMsg(res.ok ? `Resolved: ${decision}` : res.error);
    await load();
    setSelected(null);
  };

  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className="fas fa-scale-balanced" /> Disputes</h2></header>
      <p className="pd-muted">Disputed jobs hold provider earnings until you resolve them. No automatic refunds.</p>
      {msg && <p>{msg}</p>}
      <div className="pd-grid pd-grid-2">
        <ul className="ad-requests">
          {rows.map((b) => (
            <li key={b.id}>
              <div>
                <strong>{b.reference}</strong> · {b.service}
                <em>₦{Number(b.amount).toLocaleString("en-NG")}</em>
              </div>
              <button type="button" className="ad-btn" onClick={() => void open(b)}>Review</button>
            </li>
          ))}
        </ul>
        {rows.length === 0 && <p className="pd-muted">No open disputed bookings.</p>}
        {selected && (
          <div>
            <h3>{selected.reference}</h3>
            <p>Completed at: {selected.completed_at ? new Date(selected.completed_at).toLocaleString("en-NG") : "—"}</p>
            <p>Customer: {selected.customer_id}</p>
            <p>Provider: {selected.provider_id}</p>
            <p><strong>Dispute reason:</strong> {selected.dispute?.reason || "—"}</p>
            <p>{selected.dispute?.description}</p>
            <label className="cd-field">Resolution notes
              <textarea value={resolution} onChange={(e) => setResolution(e.target.value)} rows={4} />
            </label>
            <div style={{ display: "flex", gap: 8, flexWrap: "wrap" }}>
              <button type="button" className="ad-btn ok" onClick={() => void resolve("provider_entitled")}>
                Provider entitled (release earnings once)
              </button>
              <button type="button" className="ad-btn bad" onClick={() => void resolve("provider_not_entitled")}>
                Uphold customer (no payout)
              </button>
            </div>
          </div>
        )}
      </div>
    </article>
  );
}

function PendingCompletionSection() {
  const [rows, setRows] = useState<any[]>([]);
  const [note, setNote] = useState("");
  const [msg, setMsg] = useState<string | null>(null);
  const load = async () => {
    const { data } = await supabase
      .from("bookings")
      .select("id, reference, service, status, completed_at, confirm_deadline, customer_id, provider_id, address, amount")
      .eq("status", "awaiting_confirmation")
      .order("completed_at", { ascending: true });
    setRows(data ?? []);
  };
  useEffect(() => {
    void load();
  }, []);
  const confirm = async (id: string) => {
    if (!window.confirm("Confirm you verified completion with the customer by phone?")) return;
    const res = await adminConfirmCompletionByPhone({ data: { bookingId: id, note: note || undefined } });
    setMsg(res.ok ? "Admin confirmation recorded. Earnings released to wallet ledger if eligible." : res.error);
    await load();
  };
  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className="fas fa-hourglass-half" /> Pending Completion Confirmation</h2></header>
      <p className="pd-muted">
        Five-minute window is an <strong>admin escalation reminder</strong> only — it does not auto-pay providers.
        Use phone verification, then Admin Confirmed Completion.
      </p>
      {msg && <p>{msg}</p>}
      <label className="cd-field">Optional verification note (saved on confirm)
        <input value={note} onChange={(e) => setNote(e.target.value)} />
      </label>
      <ul className="ad-requests">
        {rows.map((b) => {
          const elapsed = b.completed_at
            ? Math.round((Date.now() - new Date(b.completed_at).getTime()) / 60000)
            : null;
          const overdue = b.confirm_deadline && new Date(b.confirm_deadline).getTime() < Date.now();
          return (
            <li key={b.id} style={{ flexWrap: "wrap" }}>
              <div>
                <strong>{b.reference}</strong> · {b.service}
                <em>
                  Completed {b.completed_at ? new Date(b.completed_at).toLocaleString("en-NG") : "—"}
                  {elapsed != null ? ` · ${elapsed} min ago` : ""}
                  {overdue ? " · ESCALATION DUE" : ""}
                </em>
                <em>Customer id: {b.customer_id} · Provider id: {b.provider_id}</em>
              </div>
              <button type="button" className="ad-btn ok" onClick={() => void confirm(b.id)}>
                Admin Confirmed Completion
              </button>
            </li>
          );
        })}
      </ul>
      {rows.length === 0 && <p className="pd-muted">No bookings awaiting confirmation.</p>}
    </article>
  );
}

function AdminProviderSupportSection() {
  const [tickets, setTickets] = useState<any[]>([]);
  const [selected, setSelected] = useState<any | null>(null);
  const [reply, setReply] = useState("");
  const [internal, setInternal] = useState("");
  const [status, setStatus] = useState("in_progress");
  const [msg, setMsg] = useState<string | null>(null);
  const [messages, setMessages] = useState<any[]>([]);

  const load = async () => {
    const { data, error } = await (supabase as any)
      .from("provider_support_tickets")
      .select("id, provider_id, category, subject, body, status, created_at")
      .order("created_at", { ascending: false })
      .limit(100);
    if (error) {
      setMsg(error.message.includes("does not exist")
        ? "Provider support tables are not applied yet. Run the provider portal migrations on staging."
        : error.message);
      setTickets([]);
      return;
    }
    setTickets(data ?? []);
    setMsg(null);
  };

  useEffect(() => {
    void load();
  }, []);

  const openTicket = async (t: any) => {
    setSelected(t);
    setStatus(t.status);
    const { data } = await (supabase as any)
      .from("provider_support_messages")
      .select("id, body, is_internal_note, sender_id, created_at")
      .eq("ticket_id", t.id)
      .order("created_at", { ascending: true });
    setMessages(data ?? []);
  };

  const saveStatus = async () => {
    if (!selected) return;
    const { error } = await (supabase as any)
      .from("provider_support_tickets")
      .update({ status, updated_at: new Date().toISOString() })
      .eq("id", selected.id);
    setMsg(error ? error.message : "Status updated.");
    await load();
  };

  const sendReply = async (asInternal: boolean) => {
    if (!selected) return;
    const text = asInternal ? internal : reply;
    if (!text.trim()) return;
    const { data: auth } = await supabase.auth.getUser();
    const uid = auth.user?.id;
    if (!uid) return;
    const { error } = await (supabase as any).from("provider_support_messages").insert({
      ticket_id: selected.id,
      sender_id: uid,
      body: text.trim(),
      is_internal_note: asInternal,
    });
    if (error) {
      setMsg(error.message);
      return;
    }
    if (!asInternal) {
      await supabase.from("notifications").insert({
        user_id: selected.provider_id,
        type: "support",
        title: "Support reply",
        body: `Update on ticket: ${selected.subject}`,
      });
      setReply("");
    } else {
      setInternal("");
    }
    await openTicket(selected);
    setMsg(asInternal ? "Internal note saved." : "Reply sent to provider.");
  };

  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className="fas fa-circle-question" /> Provider Support Tickets</h2></header>
      {msg && <p>{msg}</p>}
      <div className="pd-grid pd-grid-2">
        <div>
          <ul className="ad-requests">
            {tickets.map((t) => (
              <li key={t.id}>
                <div>
                  <strong>{t.subject}</strong>
                  <em>{t.category} · {t.status}</em>
                </div>
                <button type="button" className="ad-btn" onClick={() => void openTicket(t)}>Open</button>
              </li>
            ))}
          </ul>
          {tickets.length === 0 && <p className="pd-muted">No provider tickets yet.</p>}
        </div>
        {selected && (
          <div>
            <h3>{selected.subject}</h3>
            <p>{selected.body}</p>
            <label className="cd-field">Status
              <select value={status} onChange={(e) => setStatus(e.target.value)}>
                {["open", "in_progress", "waiting_for_provider", "resolved", "closed"].map((s) => (
                  <option key={s} value={s}>{s}</option>
                ))}
              </select>
            </label>
            <button type="button" className="pd-btn" onClick={() => void saveStatus()}>Update status</button>
            <h4 style={{ marginTop: 12 }}>Thread</h4>
            <ul className="pd-verify-list">
              {messages.map((m) => (
                <li key={m.id}>
                  {m.is_internal_note ? <em>[Internal] </em> : null}
                  {m.body}
                </li>
              ))}
            </ul>
            <label className="cd-field">Reply to provider
              <textarea value={reply} onChange={(e) => setReply(e.target.value)} rows={3} />
            </label>
            <button type="button" className="pd-btn pd-btn-primary" onClick={() => void sendReply(false)}>Send reply</button>
            <label className="cd-field" style={{ marginTop: 8 }}>Internal note (provider cannot see)
              <textarea value={internal} onChange={(e) => setInternal(e.target.value)} rows={2} />
            </label>
            <button type="button" className="pd-btn" onClick={() => void sendReply(true)}>Save internal note</button>
          </div>
        )}
      </div>
    </article>
  );
}

function NotBuiltSection({ icon, title, reason }: { icon: string; title: string; reason: string }) {
  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className={`fas ${icon}`} /> {title}</h2></header>
      <EmptyState icon="fa-hammer" title="Not built yet" body={reason} />
    </article>
  );
}

function NotificationsSection() {
  const [items, setItems] = useState<{ id: string; title: string; body: string | null; read: boolean; created_at: string }[] | null>(null);

  useEffect(() => {
    void supabase.auth.getUser().then(({ data }) => {
      const uid = data.user?.id;
      if (!uid) return setItems([]);
      void supabase
        .from("notifications")
        .select("id, title, body, read, created_at")
        .eq("user_id", uid)
        .order("created_at", { ascending: false })
        .then(({ data: rows }) => setItems(rows ?? []));
    });
  }, []);

  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className="fas fa-bell" /> Notifications</h2></header>
      {items === null ? (
        <p className="cd-sub">Loading…</p>
      ) : items.length === 0 ? (
        <EmptyState
          icon="fa-bell-slash"
          title="No notifications."
          body="Nothing currently generates admin-targeted alerts (e.g. 'no provider available') — this panel is real and will populate once that's built."
        />
      ) : (
        <ul className="ad-requests">
          {items.map((n) => (
            <li key={n.id}>
              <div><strong>{n.title}</strong><em>{n.body}</em></div>
              <span className={`ad-badge ${n.read ? "ok" : "warn"}`}>{n.read ? "read" : "unread"}</span>
            </li>
          ))}
        </ul>
      )}
    </article>
  );
}

type AdminQuotationRow = {
  id: string;
  reference: string;
  customer_id: string;
  service_name: string;
  service_id: string;
  address: string;
  notes: string | null;
  job_details: Record<string, unknown>;
  attachment_paths: string[];
  status: string;
  quoted_amount: number | null;
  inspection_fee: number | null;
  valid_until: string | null;
  staff_notes: string | null;
  created_at: string;
  assigned_team_label: string | null;
  assigned_at: string | null;
};

function QuotationsSection() {
  const [rows, setRows] = useState<AdminQuotationRow[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selected, setSelected] = useState<AdminQuotationRow | null>(null);
  const [staffNotes, setStaffNotes] = useState("");
  const [quotedAmount, setQuotedAmount] = useState("");
  const [inspectionFee, setInspectionFee] = useState("0");
  const [teamLabel, setTeamLabel] = useState("");
  const [assignNotes, setAssignNotes] = useState("");
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  const reload = async () => {
    setLoading(true);
    setError(null);
    // Staff fields only available via admin server function (service role).
    const res = await adminListQuotations();
    setLoading(false);
    if (!res.ok) {
      setError(res.error);
      setRows([]);
      return;
    }
    setRows((res.quotations ?? []) as AdminQuotationRow[]);
  };

  useEffect(() => {
    void reload();
  }, []);

  const open = (r: AdminQuotationRow) => {
    setSelected(r);
    setStaffNotes(r.staff_notes ?? "");
    setQuotedAmount(r.quoted_amount != null ? String(r.quoted_amount) : "");
    setInspectionFee(r.inspection_fee != null ? String(r.inspection_fee) : "0");
    setTeamLabel(r.assigned_team_label ?? "");
    setAssignNotes("");
    setMsg(null);
  };

  const saveReview = async (status?: "under_review" | "declined" | "cancelled") => {
    if (!selected) return;
    setBusy(true);
    setMsg(null);
    const res = await adminUpdateQuotationReview({
      data: {
        quotationId: selected.id,
        status,
        staffNotes,
      },
    });
    setBusy(false);
    if (!res.ok) {
      setMsg(res.error);
      return;
    }
    setMsg("Review saved.");
    await reload();
  };

  const sendQuote = async () => {
    if (!selected) return;
    const amount = Number(quotedAmount);
    const fee = Number(inspectionFee || 0);
    if (!Number.isFinite(amount) || amount <= 0) {
      setMsg("Enter a valid quoted amount greater than zero.");
      return;
    }
    setBusy(true);
    setMsg(null);
    const res = await adminSendQuotation({
      data: {
        quotationId: selected.id,
        quotedAmount: amount,
        inspectionFee: fee,
        staffNotes,
      },
    });
    setBusy(false);
    if (!res.ok) {
      setMsg(res.error);
      return;
    }
    setMsg(`Quotation sent. Valid until ${new Date(res.quotation.validUntil).toLocaleDateString("en-NG")}.`);
    await reload();
  };

  const assignTeam = async () => {
    if (!selected) return;
    if (!teamLabel.trim()) {
      setMsg("Enter an internal team or staff label.");
      return;
    }
    setBusy(true);
    setMsg(null);
    const res = await adminAssignQuotationJob({
      data: {
        quotationId: selected.id,
        teamLabel: teamLabel.trim(),
        assignmentNotes: assignNotes.trim() || undefined,
      },
    });
    setBusy(false);
    if (!res.ok) {
      setMsg(res.error);
      return;
    }
    setMsg(`Assigned to internal team: ${teamLabel.trim()}. Marketplace providers were not notified.`);
    await reload();
  };

  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head">
        <h2>
          <i className="fas fa-file-invoice" /> Quotations
        </h2>
        <button type="button" className="pd-btn pd-btn-sm" onClick={() => void reload()}>
          Refresh
        </button>
      </header>
      {loading ? (
        <p className="cd-sub">Loading…</p>
      ) : error ? (
        <p className="pd-error">{error}</p>
      ) : rows.length === 0 ? (
        <EmptyState icon="fa-file-invoice" title="No quotation requests yet." body="Customer Request a Quote submissions will appear here." />
      ) : (
        <div className="pd-table-wrap">
          <table className="pd-table">
            <thead>
              <tr>
                <th>Reference</th>
                <th>Service</th>
                <th>Status</th>
                <th>Submitted</th>
                <th />
              </tr>
            </thead>
            <tbody>
              {rows.map((r) => (
                <tr key={r.id}>
                  <td>{r.reference}</td>
                  <td>{r.service_name}</td>
                  <td>{r.status}</td>
                  <td>{new Date(r.created_at).toLocaleString("en-NG")}</td>
                  <td>
                    <button type="button" className="pd-btn pd-btn-sm" onClick={() => open(r)}>
                      Review
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}

      {selected && (
        <div className="pd-panel" style={{ marginTop: 16 }}>
          <h3>
            {selected.reference} · {selected.status}
          </h3>
          <p>
            <strong>Customer:</strong> {selected.customer_id}
          </p>
          <p>
            <strong>Service:</strong> {selected.service_name} ({selected.service_id})
          </p>
          <p>
            <strong>Address:</strong> {selected.address}
          </p>
          {selected.notes && (
            <p>
              <strong>Notes:</strong> {selected.notes}
            </p>
          )}
          <p>
            <strong>Job details:</strong> <code>{JSON.stringify(selected.job_details)}</code>
          </p>
          <p>
            <strong>Attachments:</strong>{" "}
            {selected.attachment_paths?.length
              ? selected.attachment_paths.join(", ")
              : "None"}
          </p>

          <label className="cd-field" style={{ display: "block", marginTop: 12 }}>
            <span>Staff notes (internal only — not shown to customers)</span>
            <textarea value={staffNotes} onChange={(e) => setStaffNotes(e.target.value)} rows={3} />
          </label>

          <div className="cd-form-row" style={{ marginTop: 12 }}>
            <label className="cd-field">
              <span>Quoted amount (NGN)</span>
              <input value={quotedAmount} onChange={(e) => setQuotedAmount(e.target.value)} inputMode="decimal" />
            </label>
            <label className="cd-field">
              <span>Inspection fee (NGN, disclosed)</span>
              <input value={inspectionFee} onChange={(e) => setInspectionFee(e.target.value)} inputMode="decimal" />
            </label>
          </div>

          {msg && <p style={{ marginTop: 8 }}>{msg}</p>}

          {(selected.status === "paid" || selected.status === "assigned") && (
            <div className="pd-panel" style={{ marginTop: 12 }}>
              <p>
                <strong>Paid job — manual internal assignment only.</strong> Do not use marketplace matching.
              </p>
              {selected.assigned_team_label && (
                <p>
                  Currently assigned: {selected.assigned_team_label}
                  {selected.assigned_at ? ` (${new Date(selected.assigned_at).toLocaleString("en-NG")})` : ""}
                </p>
              )}
              <label className="cd-field" style={{ display: "block" }}>
                <span>Internal team / staff label</span>
                <input value={teamLabel} onChange={(e) => setTeamLabel(e.target.value)} placeholder="e.g. Team A — Abuja Central" />
              </label>
              <label className="cd-field" style={{ display: "block", marginTop: 8 }}>
                <span>Assignment notes (internal)</span>
                <textarea value={assignNotes} onChange={(e) => setAssignNotes(e.target.value)} rows={2} />
              </label>
              <button type="button" className="pd-btn pd-btn-primary" style={{ marginTop: 8 }} disabled={busy} onClick={() => void assignTeam()}>
                Assign to CleanConnect team
              </button>
            </div>
          )}

          <div style={{ display: "flex", gap: 8, flexWrap: "wrap", marginTop: 12 }}>
            <button type="button" className="pd-btn" disabled={busy} onClick={() => void saveReview("under_review")}>
              Mark under review
            </button>
            <button type="button" className="pd-btn pd-btn-primary" disabled={busy} onClick={() => void sendQuote()}>
              Send quotation to customer
            </button>
            <button type="button" className="pd-btn" disabled={busy} onClick={() => void saveReview("declined")}>
              Decline request
            </button>
            <button type="button" className="pd-btn" onClick={() => setSelected(null)}>
              Close
            </button>
          </div>
        </div>
      )}
    </article>
  );
}

function SettingsSection() {
  const { settings, loading, reload } = usePlatformSettings();
  const [editing, setEditing] = useState<Record<string, string>>({});
  const [saving, setSaving] = useState<string | null>(null);

  const save = async (key: string) => {
    const raw = editing[key];
    if (raw === undefined) return;
    let parsed: unknown;
    try {
      parsed = JSON.parse(raw);
    } catch {
      parsed = raw;
    }
    setSaving(key);
    await updatePlatformSetting(key, parsed);
    setSaving(null);
    setEditing((e) => { const next = { ...e }; delete next[key]; return next; });
    await reload();
  };

  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className="fas fa-sliders" /> Platform Settings</h2></header>
      {loading ? (
        <p className="cd-sub">Loading…</p>
      ) : settings.length === 0 ? (
        <EmptyState icon="fa-sliders" title="No settings found." />
      ) : (
        <div style={{ display: "grid", gap: 14 }}>
          {settings.map((s) => (
            <div key={s.key} style={{ display: "grid", gap: 4 }}>
              <label style={{ fontSize: ".85rem", fontWeight: 600 }}>{s.key}</label>
              {s.description && <span style={{ fontSize: ".78rem", color: "var(--muted-foreground)" }}>{s.description}</span>}
              <div style={{ display: "flex", gap: 8 }}>
                <input
                  value={editing[s.key] ?? JSON.stringify(s.value)}
                  onChange={(e) => setEditing((prev) => ({ ...prev, [s.key]: e.target.value }))}
                  style={{ flex: 1 }}
                />
                <button type="button" className="pd-btn pd-btn-primary" disabled={saving === s.key} onClick={() => save(s.key)}>
                  {saving === s.key ? "Saving…" : "Save"}
                </button>
              </div>
            </div>
          ))}
        </div>
      )}
      <p style={{ fontSize: ".78rem", color: "var(--muted-foreground)", marginTop: 14 }}>
        Values are stored as JSON (e.g. a number like 5500, or an object like {"{"}"reliability":0.35{"}"}).
      </p>
    </article>
  );
}

function AdminDashboard() {
  const navigate = useNavigate();
  const { data, loading, reload } = useAdminData();
  const stats = useMemo(() => selectAdminStats(data), [data]);
  const monthlyBookings = useMemo(() => selectMonthlyBookings(data), [data]);
  const monthlyRevenue = useMemo(() => selectMonthlyRevenue(data), [data]);
  const categories = useMemo(() => selectCategoryBreakdown(data), [data]);

  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [dashOpen, setDashOpen] = useState(true);
  const [query, setQuery] = useState("");
  const { section } = Route.useSearch();
  const active = section ?? "Dashboard";
  const setActive = (label: string) => {
    void navigate({ to: "/admin", search: { section: label } });
  };
  const [openDocsFor, setOpenDocsFor] = useState<string | null>(null);
  const [docLinks, setDocLinks] = useState<{ name: string; url: string }[]>([]);
  const [docsLoading, setDocsLoading] = useState(false);
  const [viewBooking, setViewBooking] = useState<Booking | null>(null);
  const menuRef = useRef<HTMLDivElement>(null);

  const toggleDocs = async (providerId: string) => {
    if (openDocsFor === providerId) {
      setOpenDocsFor(null);
      return;
    }
    setOpenDocsFor(providerId);
    setDocsLoading(true);
    setDocLinks(await getProviderDocumentLinks(providerId));
    setDocsLoading(false);
  };

  const adminName = getUser()?.name?.split(" ")[0] ?? "Admin";

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMenuOpen(false);
        setMobileOpen(false);
      }
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, []);

  const signOut = async () => {
    await signOutAdmin();
    logout();
    navigate({ to: "/auth/$role", params: { role: "admin" }, replace: true });
  };

  const pendingProviders = data.providers.filter((p) => p.status === "pending");
  const q = query.trim().toLowerCase();
  const bookings = q
    ? data.bookings.filter((b) =>
        [b.customerName, b.service, b.providerName ?? "", b.reference].join(" ").toLowerCase().includes(q),
      )
    : data.bookings;

  const STAT_CARDS = [
    { icon: "fa-users", label: "Total Customers", value: stats.totalCustomers, tone: "blue" },
    { icon: "fa-user-tie", label: "Active Providers", value: stats.activeProviders, tone: "green" },
    { icon: "fa-calendar-day", label: "Today's Bookings", value: stats.todaysBookings, tone: "amber" },
    { icon: "fa-naira-sign", label: "Total Revenue", value: stats.totalRevenue, money: true, tone: "violet" },
    { icon: "fa-calendar-check", label: "Total Bookings", value: stats.totalBookings, tone: "blue" },
    { icon: "fa-circle-check", label: "Completed Bookings", value: stats.completedBookings, tone: "green" },
    { icon: "fa-hourglass-half", label: "Pending Bookings", value: stats.pendingBookings, tone: "amber" },
    { icon: "fa-circle-xmark", label: "Cancelled Bookings", value: stats.cancelledBookings, tone: "violet" },
    { icon: "fa-user-clock", label: "Pending Applications", value: stats.pendingProviders, tone: "amber" },
    { icon: "fa-star", label: "Total Reviews", value: stats.totalReviews, tone: "green" },
  ];

  const QUICK_ACTIONS: { icon: string; label: string; tone: string; to?: string }[] = [
    { icon: "fa-plus", label: "Add Service", tone: "blue", to: "/" },
    { icon: "fa-user-plus", label: "Add Provider", tone: "green", to: "/become-provider" },
    { icon: "fa-chart-simple", label: "View Reports", tone: "violet" },
    { icon: "fa-users-gear", label: "Manage Users", tone: "amber" },
    { icon: "fa-calendar-days", label: "Manage Bookings", tone: "blue", to: "/booking" },
    { icon: "fa-money-bill-transfer", label: "Manage Payments", tone: "green" },
  ];

  return (
    <div className={`pd-shell${collapsed ? " is-collapsed" : ""}${mobileOpen ? " is-mobile-open" : ""}`}>
      {/* Sidebar */}
      <aside className="pd-sidebar" aria-label="Admin navigation">
        <div className="pd-brand">
          <Link to="/" className="pd-brand-link" aria-label="CleanConnect home">
            <span className="pd-logo" aria-hidden="true">
              <img src={logoMark.url} alt="" />
            </span>
            <span className="pd-brand-text">
              <strong>
                Clean<span>Connect</span>
              </strong>
              <em>Admin Control Center</em>
            </span>
          </Link>
        </div>

        <nav className="pd-nav">
          <button
            type="button"
            className={`pd-nav-item${active === "Dashboard" ? " active" : ""}`}
            aria-expanded={dashOpen}
            onClick={() => {
              setActive("Dashboard");
              setDashOpen((o) => !o);
            }}
          >
            <i className="fas fa-gauge-high" aria-hidden="true" />
            <span>Dashboard</span>
            <i className={`fas fa-chevron-down cc-caret${dashOpen ? " open" : ""}`} aria-hidden="true" />
          </button>
          <div className={`cc-submenu${dashOpen ? " open" : ""}`}>
            <Link to="/admin" className="pd-nav-item pd-nav-sub">
              <i className="fas fa-shield-halved" aria-hidden="true" />
              <span>Admin Dashboard</span>
            </Link>
            <Link to="/customer" className="pd-nav-item pd-nav-sub">
              <i className="fas fa-user" aria-hidden="true" />
              <span>Customer Dashboard</span>
            </Link>
            <Link to="/provider" className="pd-nav-item pd-nav-sub">
              <i className="fas fa-user-tie" aria-hidden="true" />
              <span>Provider Dashboard</span>
            </Link>
          </div>

          {NAV.map((item) => (
            <button
              key={item.label}
              type="button"
              className={`pd-nav-item${active === item.label ? " active" : ""}`}
              title={item.label}
              aria-current={active === item.label ? "page" : undefined}
              onClick={() => {
                setActive(item.label);
                setMobileOpen(false);
              }}
            >
              <i className={`fas ${item.icon}`} aria-hidden="true" />
              <span>{item.label}</span>
              {item.counter && (
                <span className="pd-nav-badge">
                  {item.counter === "messages" ? stats.unreadMessages : stats.unreadNotifications}
                </span>
              )}
            </button>
          ))}

          <button type="button" className="pd-nav-item pd-logout" onClick={signOut}>
            <i className="fas fa-arrow-right-from-bracket" aria-hidden="true" />
            <span>Logout</span>
          </button>
        </nav>

        <div className="pd-side-card">
          <strong>Platform is live</strong>
          <p>Activity will appear here as customers and providers join CleanConnect.</p>
        </div>
      </aside>

      {mobileOpen && (
        <button type="button" className="pd-overlay" aria-label="Close navigation" onClick={() => setMobileOpen(false)} />
      )}

      {/* Main */}
      <div className="pd-main">
        <header className="pd-topbar">
          <button
            type="button"
            className="pd-icon-btn pd-burger"
            aria-label="Toggle navigation"
            onClick={() => {
              if (window.innerWidth <= 1024) setMobileOpen((v) => !v);
              else setCollapsed((v) => !v);
            }}
          >
            <i className="fas fa-bars" />
          </button>

          <div className="pd-search">
            <i className="fas fa-magnifying-glass" aria-hidden="true" />
            <input
              type="search"
              value={query}
              onChange={(e) => setQuery(e.target.value)}
              placeholder="Search for bookings, customers, providers..."
              aria-label="Search bookings, customers and providers"
            />
          </div>

          <div className="pd-top-right">
            <button
              type="button"
              className="pd-icon-btn"
              aria-label={`Notifications, ${stats.unreadNotifications} unread`}
              onClick={() => setActive("Notifications")}
            >
              <i className="fas fa-bell" />
              <span className="pd-count">{stats.unreadNotifications}</span>
            </button>
            <button
              type="button"
              className="pd-icon-btn"
              aria-label={`Messages, ${stats.unreadMessages} unread`}
              onClick={() => setActive("Messages")}
            >
              <i className="fas fa-comment-dots" />
              <span className="pd-count">{stats.unreadMessages}</span>
            </button>

            <div className="pd-profile" ref={menuRef}>
              <button
                type="button"
                className="pd-profile-btn"
                onClick={() => setMenuOpen((v) => !v)}
                aria-expanded={menuOpen}
                aria-haspopup="menu"
              >
                <span className="pd-avatar" aria-hidden="true">
                  <i className="fas fa-user-shield" />
                </span>
                <span className="pd-profile-text">
                  <strong>Hello, {adminName}</strong>
                  <em>Administrator</em>
                </span>
                <i className="fas fa-chevron-down" aria-hidden="true" />
              </button>
              {menuOpen && (
                <div className="pd-menu" role="menu">
                  <button
                    type="button"
                    role="menuitem"
                    className="pd-menu-item"
                    onClick={() => {
                      setActive("My Profile");
                      setMenuOpen(false);
                    }}
                  >
                    <i className="fas fa-id-card" /> My Profile
                  </button>
                  <button type="button" role="menuitem" className="pd-menu-item" onClick={() => setActive("Settings")}>
                    <i className="fas fa-gear" /> Settings
                  </button>
                  <button type="button" role="menuitem" className="pd-menu-item" onClick={signOut}>
                    <i className="fas fa-arrow-right-from-bracket" /> Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        <main className="pd-content">
          {active === "Dashboard" && (
          <>
          <section className="pd-welcome pd-animate">
            <div>
              <h1>Welcome Back, {adminName} 👋</h1>
              <p>Here's what's happening with your business today.</p>
            </div>
            <span className="pd-tag">
              <i className="fas fa-calendar" />{" "}
              {new Date().toLocaleDateString("en-NG", { month: "long", day: "numeric", year: "numeric" })}
            </span>
          </section>

          {/* Stats */}
          <section className="pd-stats" aria-label="Platform overview">
            {STAT_CARDS.map((s, i) =>
              loading ? (
                <div className="pd-card pd-skel-card" key={s.label}>
                  <div className="pd-skel pd-skel-icon" />
                  <div className="pd-skel pd-skel-line" />
                  <div className="pd-skel pd-skel-line short" />
                </div>
              ) : (
                <article className="pd-card pd-stat pd-animate" key={s.label} style={{ animationDelay: `${i * 40}ms` }}>
                  <span className={`pd-stat-icon tone-${s.tone}`} aria-hidden="true">
                    <i className={`fas ${s.icon}`} />
                  </span>
                  <div className="pd-stat-body">
                    <span className="pd-stat-label">{s.label}</span>
                    <span className="pd-stat-value">
                      {s.money ? formatNaira(s.value) : s.value.toLocaleString()}
                    </span>
                    <span className="pd-stat-foot">{s.value === 0 ? "No data yet" : "Updated live"}</span>
                  </div>
                </article>
              ),
            )}
          </section>

          {/* Analytics */}
          <section className="pd-grid pd-grid-3">
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-chart-column" /> Monthly Bookings
                </h2>
                <span className="pd-tag">This Year</span>
              </header>
              <BarChart values={monthlyBookings} labels={MONTH_LABELS} />
              {stats.totalBookings === 0 && <p className="ad-note">No booking data available yet.</p>}
            </article>

            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-naira-sign" /> Revenue Overview
                </h2>
                <span className="pd-tag">{formatNaira(stats.totalRevenue)}</span>
              </header>
              <BarChart values={monthlyRevenue} labels={MONTH_LABELS} money />
              {stats.totalRevenue === 0 && <p className="ad-note">Revenue will appear after successful customer payments.</p>}
            </article>

            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-chart-pie" /> Service Categories
                </h2>
              </header>
              <CategoryChart data={categories} />
            </article>
          </section>

          {/* Recent bookings + provider requests */}
          <section className="pd-grid pd-grid-2-1">
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-calendar-check" /> Recent Bookings
                </h2>
                <button type="button" className="pd-link" onClick={() => setActive("Bookings")}>
                  View all bookings
                </button>
              </header>
              {bookings.length === 0 ? (
                <EmptyState
                  icon="fa-calendar-xmark"
                  title={q ? "No matching bookings." : "No bookings yet."}
                  body={q ? "Try a different search term." : "Bookings will appear here when customers request a service."}
                />
              ) : (
                <div className="ad-table-wrap">
                  <table className="ad-table">
                    <caption className="sr-only">Recent bookings</caption>
                    <thead>
                      <tr>
                        <th scope="col">Customer</th>
                        <th scope="col">Service</th>
                        <th scope="col">Provider</th>
                        <th scope="col">Date</th>
                        <th scope="col">Amount</th>
                        <th scope="col">Status</th>
                        <th scope="col">Action</th>
                      </tr>
                    </thead>
                    <tbody>
                      {bookings.slice(0, 8).map((b) => (
                        <tr key={b.id}>
                          <td data-label="Customer">{b.customerName}</td>
                          <td data-label="Service">{b.service}</td>
                          <td data-label="Provider">{b.providerName ?? "Unassigned"}</td>
                          <td data-label="Date">{new Date(b.scheduledFor || b.createdAt).toLocaleDateString("en-NG")}</td>
                          <td data-label="Amount">{formatNaira(b.amount)}</td>
                          <td data-label="Status">
                            <span className={`ad-badge ${STATUS_TONE[b.status]}`}>{b.status}</span>
                          </td>
                          <td data-label="Action">
                            <button type="button" className="pd-link" onClick={() => setViewBooking(b)}>
                              View
                            </button>
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              )}
            </article>

            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-user-clock" /> Provider Requests
                </h2>
                <span className="pd-tag">{pendingProviders.length}</span>
              </header>
              {pendingProviders.length === 0 ? (
                <EmptyState
                  icon="fa-user-tie"
                  title="No pending provider applications."
                  body="Applications will appear here when professionals register."
                />
              ) : (
                <ul className="ad-requests">
                  {pendingProviders.map((p) => (
                    <li key={p.id}>
                      <span className="pd-avatar" aria-hidden="true">
                        <i className="fas fa-user-tie" />
                      </span>
                      <div>
                        <strong>{p.name}</strong>
                        <em>
                          {p.services.length ? p.services.join(", ") : "Cleaning services"}
                          {p.location ? ` · ${p.location}` : ""}
                        </em>
                        <em>
                          {p.rating ? `${p.rating.toFixed(1)}★` : "No rating yet"} ·{" "}
                          {p.verified ? "Verified" : "Awaiting verification"}
                        </em>
                      </div>
                      <div className="ad-req-actions">
                        <button
                          type="button"
                          className="ad-btn"
                          onClick={() => toggleDocs(p.id)}
                          aria-label={`View documents for ${p.name}`}
                        >
                          {openDocsFor === p.id ? "Hide documents" : "View documents"}
                        </button>
                        <button
                          type="button"
                          className="ad-btn ok"
                          onClick={() => setProviderStatus(p.id, "approved").then(() => reload())}
                          aria-label={`Approve ${p.name}`}
                        >
                          Approve
                        </button>
                        <button
                          type="button"
                          className="ad-btn bad"
                          onClick={() => setProviderStatus(p.id, "rejected").then(() => reload())}
                          aria-label={`Reject ${p.name}`}
                        >
                          Reject
                        </button>
                      </div>
                      {openDocsFor === p.id && (
                        <div style={{ gridColumn: "1 / -1", padding: "10px 0 4px", display: "flex", gap: 12, flexWrap: "wrap" }}>
                          {docsLoading ? (
                            <em>Loading documents…</em>
                          ) : docLinks.length === 0 ? (
                            <em>No documents on file for this applicant.</em>
                          ) : (
                            docLinks.map((d) => (
                              <a key={d.name} href={d.url} target="_blank" rel="noreferrer" className="ad-btn">
                                <i className="fas fa-file-image" /> {d.name.replace(/\.[a-z]+$/i, "")}
                              </a>
                            ))
                          )}
                        </div>
                      )}
                    </li>
                  ))}
                </ul>
              )}
            </article>
          </section>

          {/* Reviews + activity */}
          <section className="pd-grid pd-grid-2">
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-star" /> Latest Reviews
                </h2>
              </header>
              {data.reviews.length === 0 ? (
                <EmptyState
                  icon="fa-star-half-stroke"
                  title="No reviews yet."
                  body="Customer reviews will appear after completed services."
                />
              ) : (
                <ul className="ad-reviews">
                  {data.reviews.slice(0, 5).map((r) => (
                    <li key={r.id}>
                      <div>
                        <strong>{r.customerName}</strong>
                        <em>
                          {r.service} · {r.providerName}
                        </em>
                      </div>
                      <span className="ad-stars" aria-label={`${r.rating} out of 5`}>
                        {"★".repeat(Math.round(r.rating))}
                      </span>
                      <p>{r.comment}</p>
                    </li>
                  ))}
                </ul>
              )}
            </article>

            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-clock-rotate-left" /> Recent Activity
                </h2>
              </header>
              {data.activity.length === 0 ? (
                <EmptyState icon="fa-wave-square" title="No recent activity." body="Platform events will be logged here." />
              ) : (
                <ul className="ad-activity">
                  {data.activity.slice(0, 8).map((a) => (
                    <li key={a.id}>
                      <span className="pd-stat-icon tone-blue" aria-hidden="true">
                        <i className="fas fa-bolt" />
                      </span>
                      <div>
                        <strong>{a.title}</strong>
                        {a.detail && <em>{a.detail}</em>}
                      </div>
                      <time dateTime={a.createdAt}>{new Date(a.createdAt).toLocaleString("en-NG")}</time>
                    </li>
                  ))}
                </ul>
              )}
            </article>
          </section>

          {/* Customers + providers directories */}
          <section className="pd-grid pd-grid-2">
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-users" /> Customers
                </h2>
                <span className="pd-tag">{stats.totalCustomers}</span>
              </header>
              {data.customers.length === 0 ? (
                <EmptyState icon="fa-user-plus" title="No customers yet." body="Customers will appear here when they create an account." />
              ) : (
                <ul className="ad-simple-list">
                  {data.customers.slice(0, 6).map((c) => (
                    <li key={c.id}>
                      <div>
                        <strong>{c.name}</strong>
                        <em>{c.email}</em>
                      </div>
                      <span className={`ad-badge ${c.status === "active" ? "ok" : "warn"}`}>{c.status}</span>
                    </li>
                  ))}
                </ul>
              )}
            </article>

            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-user-tie" /> Providers
                </h2>
                <span className="pd-tag">{stats.totalProviders}</span>
              </header>
              {data.providers.length === 0 ? (
                <EmptyState
                  icon="fa-user-tie"
                  title="No providers yet."
                  body="Provider applications will appear here when professionals register."
                  cta={
                    <Link to="/become-provider" className="pd-btn pd-btn-primary pd-ripple">
                      Invite a provider
                    </Link>
                  }
                />
              ) : (
                <ul className="ad-simple-list">
                  {data.providers.slice(0, 6).map((p) => (
                    <li key={p.id}>
                      <div>
                        <strong>{p.name}</strong>
                        <em>{p.email}</em>
                      </div>
                      <span className={`ad-badge ${p.status === "approved" ? "ok" : p.status === "pending" ? "warn" : "bad"}`}>
                        {p.status}
                      </span>
                    </li>
                  ))}
                </ul>
              )}
            </article>
          </section>

          {/* Quick actions */}
          <section className="pd-animate">
            <h2 className="pd-section-title">
              <i className="fas fa-bolt" /> Quick Actions
            </h2>
            <div className="pd-actions">
              {QUICK_ACTIONS.map((a) =>
                a.to ? (
                  <Link key={a.label} to={a.to} className="pd-action pd-ripple">
                    <span className={`pd-stat-icon tone-${a.tone}`} aria-hidden="true">
                      <i className={`fas ${a.icon}`} />
                    </span>
                    <strong>{a.label}</strong>
                    <i className="fas fa-arrow-right" aria-hidden="true" />
                  </Link>
                ) : (
                  <button
                    key={a.label}
                    type="button"
                    className="pd-action pd-ripple"
                    onClick={() =>
                      setActive(
                        a.label === "View Reports"
                          ? "Analytics"
                          : a.label === "Manage Users"
                            ? "Customers"
                            : "Payments",
                      )
                    }
                  >
                    <span className={`pd-stat-icon tone-${a.tone}`} aria-hidden="true">
                      <i className={`fas ${a.icon}`} />
                    </span>
                    <strong>{a.label}</strong>
                    <i className="fas fa-arrow-right" aria-hidden="true" />
                  </button>
                ),
              )}
            </div>
          </section>
          </>
          )}

          {active === "Pending Confirmation" && <PendingCompletionSection />}
          {active === "Disputes" && <DisputesSection />}
          {active === "Bookings" && (
            <BookingsSection bookings={bookings} onView={setViewBooking} />
          )}

          {active === "Customers" && (
            <SimpleDirectorySection
              icon="fa-users"
              title="All Customers"
              emptyIcon="fa-user-plus"
              emptyTitle="No customers yet."
              emptyBody="Customers will appear here when they create an account."
              rows={data.customers.map((c) => ({ id: c.id, title: c.name, subtitle: c.email, tone: "ok" as const, tag: c.status }))}
            />
          )}

          {active === "Providers" && (
            <ProvidersSection
              providers={data.providers}
              openDocsFor={openDocsFor}
              docLinks={docLinks}
              docsLoading={docsLoading}
              onToggleDocs={toggleDocs}
              onApprove={(id) => setProviderStatus(id, "approved").then(() => reload())}
              onReject={(id) => setProviderStatus(id, "rejected").then(() => reload())}
            />
          )}

          {active === "Services" && <ServicesSection />}

          {active === "Payments" && <PaymentsSection payments={data.payments} />}

          {active === "Reviews" && (
            <SimpleDirectorySection
              icon="fa-star"
              title="All Reviews"
              emptyIcon="fa-star-half-stroke"
              emptyTitle="No reviews yet."
              emptyBody="Customer reviews will appear after completed services."
              rows={data.reviews.map((r) => ({
                id: r.id,
                title: `${r.customerName} → ${r.providerName}`,
                subtitle: `${r.service} — ${r.comment || "No comment left"}`,
                tag: `${"★".repeat(Math.round(r.rating))} (${r.rating}/5)`,
                tone: "ok" as const,
              }))}
            />
          )}

          {active === "Analytics" && (
            <AnalyticsSection
              monthlyBookings={monthlyBookings}
              monthlyRevenue={monthlyRevenue}
              categories={categories}
              stats={stats}
            />
          )}

          {active === "Quotations" && <QuotationsSection />}

          {active === "Messages" && <NotBuiltSection icon="fa-comment-dots" title="Admin message relay" reason="Admins can already read booking conversations in the database for dispute review, but there's no dashboard UI built yet to browse or relay them. This needs its own panel — flagging rather than faking it." />}

          {active === "Notifications" && <NotificationsSection />}

          {active === "Settings" && <SettingsSection />}

          {active === "Help & Support" && <AdminProviderSupportSection />}

          {active === "My Profile" && (
            <div className="pd-panel pd-animate" style={{ maxWidth: 420 }}>
              <h2><i className="fas fa-id-card" /> My Profile</h2>
              <p style={{ color: "var(--muted-foreground)", marginTop: 8 }}>
                <strong>Name:</strong> {getUser()?.name ?? "Admin"}<br />
                <strong>Email:</strong> {getUser()?.email ?? "—"}<br />
                <strong>Role:</strong> Administrator
              </p>
              <p style={{ fontSize: ".82rem", color: "var(--muted-foreground)", marginTop: 12 }}>
                Profile editing isn't built yet — this is a read-only view of your account.
              </p>
            </div>
          )}

          {viewBooking && <BookingDetailModal booking={viewBooking} onClose={() => setViewBooking(null)} />}
        </main>
      </div>
    </div>
  );
}
