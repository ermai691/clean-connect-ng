import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { RoleGuard } from "@/components/RoleGuard";
import { useEffect, useMemo, useRef, useState } from "react";
import {
  useProviderData,
  providerStats,
  profileCompletionPct,
  updateProviderProfile,
  setProviderOnline,
} from "@/lib/provider-data";
import { signOutProvider } from "@/lib/provider-auth";
import { usePendingOffers, respondToOffer } from "@/lib/provider-assignments";
import {
  providerStartJob,
  providerMarkInProgress,
  providerCompleteJob,
  requestProviderWithdrawal,
  listProviderWithdrawals,
  createProviderSupportTicket,
  listProviderSupportTickets,
  listProviderPolicies,
  acceptProviderPolicy,
  listProviderNotifications,
  markProviderNotificationRead,
  markAllProviderNotificationsRead,
  listProviderPolicies,
  acceptProviderPolicy,
  listMyPolicyAcceptances,
} from "@/lib/provider-portal";
import { ChatDialog } from "@/components/ChatDialog";
import { ngn } from "@/lib/customer-data";

export const Route = createFileRoute("/provider")({
  validateSearch: (search: Record<string, unknown>): { section?: string } => ({
    section: typeof search.section === "string" ? search.section : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Provider Dashboard — CleanConnect" },
      {
        name: "description",
        content:
          "Manage job requests, earnings, wallet, schedule and reviews as a CleanConnect cleaning provider in Abuja.",
      },
      { property: "og:title", content: "Provider Dashboard — CleanConnect" },
      {
        property: "og:description",
        content: "Track job requests, earnings and performance as a CleanConnect provider.",
      },
      { property: "og:type", content: "website" },
      { name: "twitter:card", content: "summary_large_image" },
    ],
  }),
  ssr: false,
  component: () => (
    <RoleGuard role="provider">
      <ProviderDashboard />
    </RoleGuard>
  ),
});

/* ---------------- Sidebar nav model ---------------- */
const NAV = [
  { icon: "fa-gauge-high", label: "Dashboard", active: true },
  { icon: "fa-inbox", label: "Job Requests", badge: 0 },
  { icon: "fa-briefcase", label: "My Jobs" },
  { icon: "fa-calendar-days", label: "Schedule" },
  { icon: "fa-sack-dollar", label: "Earnings" },
  { icon: "fa-wallet", label: "Wallet" },
  { icon: "fa-comment-dots", label: "Messages", badge: 0 },
  { icon: "fa-star", label: "Reviews" },
  { icon: "fa-bell", label: "Notifications" },
  { icon: "fa-chart-line", label: "Analytics" },
  { icon: "fa-id-card", label: "Profile" },
  { icon: "fa-gear", label: "Settings" },
  { icon: "fa-circle-question", label: "Help & Support" },
];

/* ---------------- Stat/checklist shapes (values are computed from Supabase data) ---------------- */
type StatCard = {
  icon: string; label: string; value: number; tone: string; foot: string;
  money?: boolean; rating?: boolean;
};

import type { ProviderData } from "@/lib/provider-data";

function buildStats(d: ProviderData): StatCard[] {
  const s = providerStats(d);
  return [
    { icon: "fa-inbox", label: "Available Job Requests", value: s.availableRequests, tone: "blue", foot: s.availableRequests ? "Awaiting your response" : "New requests appear here" },
    { icon: "fa-circle-check", label: "Jobs Completed", value: s.jobsCompleted, tone: "green", foot: "All time" },
    { icon: "fa-coins", label: "Today's Earnings", value: s.todayEarnings, money: true, tone: "amber", foot: "Today" },
    { icon: "fa-sack-dollar", label: "Monthly Earnings", value: s.monthlyEarnings, money: true, tone: "violet", foot: "This month" },
    { icon: "fa-wallet", label: "Wallet Balance", value: s.walletBalance, money: true, tone: "blue", foot: "Available to withdraw" },
    { icon: "fa-star", label: "Average Rating", value: s.averageRating, rating: true, tone: "amber", foot: s.reviewCount ? `${s.reviewCount} review${s.reviewCount === 1 ? "" : "s"}` : "No ratings yet" },
    { icon: "fa-comment-dots", label: "Reviews Received", value: s.reviewCount, tone: "green", foot: "Total" },
    { icon: "fa-users", label: "Total Customers", value: s.totalCustomers, tone: "violet", foot: "Repeat + new" },
  ];
}

function buildPerformance(d: ProviderData) {
  const s = providerStats(d);
  return [
    { label: "Jobs Accepted", value: `${s.acceptedRatePct}%`, pct: s.acceptedRatePct },
    { label: "Completion Rate", value: `${s.completionRatePct}%`, pct: s.completionRatePct },
    { label: "Customer Satisfaction", value: `${s.satisfactionPct}%`, pct: s.satisfactionPct },
    { label: "Average Response Time", value: "Not tracked yet", pct: 0 },
    { label: "Cancellation Rate", value: `${s.cancellationRatePct}%`, pct: s.cancellationRatePct },
  ];
}

function buildVerification(d: ProviderData) {
  const p = d.profile;
  return [
    { label: "Application Submitted", done: !!p },
    { label: "Documents Uploaded", done: (p?.verification_documents?.length ?? 0) > 0 },
    { label: "Verified by CleanConnect", done: p?.verification_status === "verified" },
    { label: "Approved to Receive Bookings", done: p?.approval_status === "approved" },
  ];
}

function buildChecklist(d: ProviderData) {
  const p = d.profile;
  return [
    { label: "Add Bio", done: !!p?.description && p.description.length >= 20 },
    { label: "Select Services", done: (p?.services.length ?? 0) > 0 },
    { label: "Add Coverage Area", done: !!p?.coverage_area },
    { label: "Verify Identity", done: p?.verification_status === "verified" },
    { label: "Get Approved", done: p?.approval_status === "approved" },
    // Not yet supported by the schema — always shown as outstanding.
    { label: "Upload Profile Picture", done: false },
    { label: "Set Availability", done: false },
    { label: "Add Bank Details", done: false },
  ];
}

const QUICK_ACTIONS = [
  { icon: "fa-magnifying-glass", label: "Browse Available Jobs", tone: "blue" },
  { icon: "fa-calendar-plus", label: "Update Availability", tone: "green" },
  { icon: "fa-user-pen", label: "Edit Profile", tone: "violet" },
  { icon: "fa-file-arrow-up", label: "Upload Certificates", tone: "amber" },
  { icon: "fa-chart-simple", label: "View Earnings", tone: "blue" },
  { icon: "fa-wallet", label: "Open Wallet", tone: "green" },
];

const ACTIVE_STATUS_SET = new Set(["assignment_pending", "provider_accepted", "on_the_way", "in_progress", "awaiting_confirmation"]);

const DAYS = ["Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sun"];
const SLOTS = ["Morning", "Afternoon", "Evening"];
const MONTHS = ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

const AI_TIPS = [
  "Complete your profile to appear higher in search.",
  "Upload work photos — providers with photos get 3x more requests.",
  "Accept your first booking to unlock reviews.",
  "Maintain a high response rate (under 5 mins).",
];

/* ---------------- Animated counter (starts at zero) ---------------- */
function useCountUp(target: number, duration = 900) {
  const [value, setValue] = useState(0);
  useEffect(() => {
    if (target === 0) return;
    let raf = 0;
    const start = performance.now();
    const tick = (now: number) => {
      const p = Math.min(1, (now - start) / duration);
      setValue(target * (1 - Math.pow(1 - p, 3)));
      if (p < 1) raf = requestAnimationFrame(tick);
    };
    raf = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(raf);
  }, [target, duration]);
  return value;
}

function StatValue({ stat }: { stat: StatCard }) {
  const v = useCountUp(stat.value);
  if (stat.rating) return <>{v.toFixed(1)} <i className="fas fa-star pd-star" /></>;
  if (stat.money) return <>₦{Math.round(v).toLocaleString()}</>;
  return <>{Math.round(v).toLocaleString()}</>;
}

/* ---------------- Zero-value charts ---------------- */
function ZeroBars({ labels }: { labels: string[] }) {
  return (
    <div className="pd-bars" role="img" aria-label="Chart with no data yet — all values are zero">
      {labels.map((l) => (
        <div className="pd-bar-col" key={l}>
          <div className="pd-bar-track">
            <div className="pd-bar-fill" style={{ height: "2px" }} />
          </div>
          <span>{l}</span>
        </div>
      ))}
      <span className="pd-chart-empty">No data yet</span>
    </div>
  );
}

function ZeroLine({ labels }: { labels: string[] }) {
  return (
    <div className="pd-line-wrap" role="img" aria-label="Growth chart with no data yet">
      <svg viewBox="0 0 300 90" preserveAspectRatio="none" className="pd-line">
        {[0, 1, 2, 3].map((i) => (
          <line key={i} x1="0" x2="300" y1={i * 28 + 2} y2={i * 28 + 2} className="pd-gridline" />
        ))}
        <polyline points="0,86 60,86 120,86 180,86 240,86 300,86" className="pd-line-path" />
      </svg>
      <div className="pd-line-labels">
        {labels.map((l) => (
          <span key={l}>{l}</span>
        ))}
      </div>
      <span className="pd-chart-empty">No data yet</span>
    </div>
  );
}

function EmptyState({
  icon,
  title,
  body,
  cta,
}: {
  icon: string;
  title: string;
  body?: string;
  cta?: string;
}) {
  return (
    <div className="pd-empty">
      <span className="pd-empty-art" aria-hidden="true">
        <i className={`fas ${icon}`} />
      </span>
      <strong>{title}</strong>
      {body && <p>{body}</p>}
      {cta && (
        <button type="button" className="pd-btn pd-btn-primary pd-ripple">
          {cta}
        </button>
      )}
    </div>
  );
}

/** Real-data booking list with lifecycle actions (start / in progress / complete). */
function SimpleBookingList({
  bookings,
  onMessage,
  onChanged,
  limit = 5,
  showActions = false,
}: {
  bookings: import("@/lib/customer-data").Booking[];
  onMessage?: (b: import("@/lib/customer-data").Booking) => void;
  onChanged?: () => void;
  limit?: number;
  showActions?: boolean;
}) {
  const [busy, setBusy] = useState<string | null>(null);
  const [err, setErr] = useState<string | null>(null);

  const act = async (id: string, kind: "start" | "progress" | "complete") => {
    setBusy(id);
    setErr(null);
    const res =
      kind === "start"
        ? await providerStartJob(id)
        : kind === "progress"
          ? await providerMarkInProgress(id)
          : await providerCompleteJob(id);
    setBusy(null);
    if (!res.ok) {
      setErr(res.error);
      return;
    }
    onChanged?.();
  };

  return (
    <div>
      {err && <p style={{ color: "crimson", marginBottom: 8 }}>{err}</p>}
      <ul className="pd-verify-list" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
        {bookings.slice(0, limit).map((b) => (
          <li key={b.id} style={{ display: "flex", justifyContent: "space-between", alignItems: "center", gap: 12, flexWrap: "wrap" }}>
            <span>
              <i className="fas fa-broom" aria-hidden="true" /> {b.service} · {b.reference}
              <span style={{ color: "var(--muted-foreground)", fontSize: ".85rem", marginLeft: 8 }}>
                {new Date(b.scheduled_for).toLocaleString("en-NG")} · {b.status}
              </span>
            </span>
            <span style={{ display: "flex", alignItems: "center", gap: 8, flexWrap: "wrap" }}>
              {onMessage && b.customer_id && (
                <button type="button" className="pd-btn pd-btn-ghost" style={{ padding: "4px 10px" }} onClick={() => onMessage(b)}>
                  <i className="fas fa-comment" /> Message
                </button>
              )}
              {showActions && b.status === "provider_accepted" && (
                <button type="button" className="pd-btn pd-btn-primary" style={{ padding: "4px 10px" }} disabled={busy === b.id} onClick={() => void act(b.id, "start")}>
                  Start Job
                </button>
              )}
              {showActions && b.status === "on_the_way" && (
                <button type="button" className="pd-btn pd-btn-primary" style={{ padding: "4px 10px" }} disabled={busy === b.id} onClick={() => void act(b.id, "progress")}>
                  Mark in progress
                </button>
              )}
              {showActions && b.status === "in_progress" && (
                <button type="button" className="pd-btn pd-btn-primary" style={{ padding: "4px 10px" }} disabled={busy === b.id} onClick={() => void act(b.id, "complete")}>
                  Job Completed
                </button>
              )}
            </span>
          </li>
        ))}
      </ul>
    </div>
  );
}

function timeLeftLabel(respondsBy: string): string {
  const ms = new Date(respondsBy).getTime() - Date.now();
  if (ms <= 0) return "Expiring…";
  const mins = Math.floor(ms / 60000);
  const secs = Math.floor((ms % 60000) / 1000);
  return `${mins}m ${secs}s left`;
}

function OfferBanner() {
  const { offers, reload } = usePendingOffers();
  const [, forceTick] = useState(0);
  const [busyId, setBusyId] = useState<string | null>(null);

  useEffect(() => {
    const t = setInterval(() => forceTick((n) => n + 1), 1000);
    return () => clearInterval(t);
  }, []);

  if (offers.length === 0) return null;

  const respond = async (id: string, decision: "accept" | "decline") => {
    setBusyId(id);
    const res = await respondToOffer(id, decision);
    setBusyId(null);
    if (!res.ok) window.alert(res.error);
    void reload();
  };

  return (
    <section className="pd-panel pd-animate" style={{ borderLeft: "4px solid var(--accent, #22c55e)", marginBottom: 20 }}>
      {offers.map((o) => (
        <div key={o.id} style={{ display: "flex", flexWrap: "wrap", alignItems: "center", gap: 16, padding: "12px 4px" }}>
          <div style={{ flex: 1, minWidth: 220 }}>
            <strong>New job offer: {o.service}</strong>
            <p style={{ margin: "4px 0 0", color: "var(--muted-foreground)", fontSize: ".88rem" }}>
              {new Date(o.scheduledFor).toLocaleString()} · {o.address} · {ngn(o.amount)}
            </p>
          </div>
          <span style={{ fontSize: ".82rem", fontWeight: 600, color: "#b45309" }}>{timeLeftLabel(o.respondsBy)}</span>
          <div style={{ display: "flex", gap: 8 }}>
            <button
              type="button"
              className="pd-btn pd-btn-primary"
              disabled={busyId === o.id}
              onClick={() => respond(o.id, "accept")}
            >
              Accept
            </button>
            <button
              type="button"
              className="pd-btn pd-btn-light"
              disabled={busyId === o.id}
              onClick={() => respond(o.id, "decline")}
            >
              Decline
            </button>
          </div>
        </div>
      ))}
    </section>
  );
}


function ProviderWalletSection({ stats }: { stats: ReturnType<typeof providerStats> }) {
  const [amount, setAmount] = useState("");
  const [rows, setRows] = useState<Awaited<ReturnType<typeof listProviderWithdrawals>>>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  const reload = async () => {
    setRows(await listProviderWithdrawals());
  };
  useEffect(() => {
    void reload();
  }, []);

  const submit = async () => {
    setBusy(true);
    setMsg(null);
    const res = await requestProviderWithdrawal(Number(amount));
    setBusy(false);
    if (!res.ok) {
      setMsg(res.error);
      return;
    }
    setMsg("Withdrawal requested. It stays in requested/processing until Paystack Transfer confirms (server config required).");
    setAmount("");
    await reload();
  };

  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className="fas fa-wallet" /> Wallet</h2></header>
      <p><strong>Available (wallet ledger):</strong> {ngn(stats.walletBalance)}</p>
      <p className="pd-muted">Pending earnings and automatic Paystack transfers require payout release rules + Transfer API configuration. Do not treat a request as paid until status is successful.</p>
      <div className="cd-form-row" style={{ marginTop: 12, display: "flex", gap: 8, flexWrap: "wrap" }}>
        <input value={amount} onChange={(e) => setAmount(e.target.value)} placeholder="Amount (NGN)" inputMode="decimal" />
        <button type="button" className="pd-btn pd-btn-primary" disabled={busy} onClick={() => void submit()}>
          Request withdrawal
        </button>
      </div>
      {msg && <p style={{ marginTop: 8 }}>{msg}</p>}
      <h3 style={{ marginTop: 16 }}>Withdrawal history</h3>
      {rows.length === 0 ? (
        <p className="pd-muted">No withdrawal requests yet.</p>
      ) : (
        <ul className="pd-verify-list">
          {rows.map((r) => (
            <li key={r.id}>{ngn(r.amount)} · {r.status} · {new Date(r.created_at).toLocaleString("en-NG")}</li>
          ))}
        </ul>
      )}
    </article>
  );
}

function ProviderNotificationsSection() {
  const [rows, setRows] = useState<any[]>([]);
  const load = async () => setRows(await listProviderNotifications());
  useEffect(() => {
    void load();
  }, []);
  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head">
        <h2><i className="fas fa-bell" /> Notifications</h2>
        <button type="button" className="pd-link" onClick={() => void markAllProviderNotificationsRead().then(load)}>Mark all read</button>
      </header>
      {rows.length === 0 ? (
        <EmptyState icon="fa-bell-slash" title="You're all caught up." body="No notifications." />
      ) : (
        <ul className="pd-verify-list">
          {rows.map((n) => (
            <li key={n.id} style={{ opacity: n.read ? 0.7 : 1 }}>
              <strong>{n.title}</strong> — {n.body}
              <button type="button" className="pd-btn pd-btn-ghost" style={{ marginLeft: 8 }} onClick={() => void markProviderNotificationRead(n.id).then(load)}>
                {n.read ? "Read" : "Mark read"}
              </button>
            </li>
          ))}
        </ul>
      )}
    </article>
  );
}

function ProviderSupportSection() {
  const [category, setCategory] = useState("Job assignment");
  const [subject, setSubject] = useState("");
  const [body, setBody] = useState("");
  const [tickets, setTickets] = useState<any[]>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const load = async () => setTickets(await listProviderSupportTickets());
  useEffect(() => {
    void load();
  }, []);
  const submit = async () => {
    const res = await createProviderSupportTicket({ category, subject, body });
    if (!res.ok) {
      setMsg(res.error);
      return;
    }
    setMsg("Ticket submitted.");
    setSubject("");
    setBody("");
    await load();
  };
  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className="fas fa-circle-question" /> Help & Support</h2></header>
      <label className="cd-field">Category
        <select value={category} onChange={(e) => setCategory(e.target.value)}>
          {["Job assignment","Customer complaint","Payment and earnings","Withdrawal problem","Verification","Account access","Safety incident","Technical problem","Other"].map((c) => (
            <option key={c}>{c}</option>
          ))}
        </select>
      </label>
      <label className="cd-field">Subject
        <input value={subject} onChange={(e) => setSubject(e.target.value)} />
      </label>
      <label className="cd-field">Details
        <textarea value={body} onChange={(e) => setBody(e.target.value)} rows={4} />
      </label>
      <button type="button" className="pd-btn pd-btn-primary" onClick={() => void submit()}>Submit ticket</button>
      {msg && <p>{msg}</p>}
      <h3 style={{ marginTop: 16 }}>Your tickets</h3>
      {tickets.length === 0 ? <p className="pd-muted">No tickets yet (requires portal migration).</p> : (
        <ul className="pd-verify-list">
          {tickets.map((t) => (
            <li key={t.id}><strong>{t.subject}</strong> · {t.status} · {t.category}</li>
          ))}
        </ul>
      )}
      <p className="pd-muted" style={{ marginTop: 12 }}>
        Policies: see the Provider Agreement seed in the portal migration (legal review required before launch).
      </p>
    </article>
  );
}


function ProviderProfileEditor({
  profile,
  onSaved,
}: {
  profile: import("@/lib/provider-data").ProviderProfile | null;
  onSaved: () => void;
}) {
  const [businessName, setBusinessName] = useState(profile?.business_name ?? "");
  const [phone, setPhone] = useState(profile?.contact_phone ?? "");
  const [description, setDescription] = useState(profile?.description ?? "");
  const [city, setCity] = useState(profile?.city ?? "");
  const [state, setState] = useState(profile?.state ?? "");
  const [coverage, setCoverage] = useState(profile?.coverage_area ?? "");
  const [msg, setMsg] = useState<string | null>(null);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    setBusinessName(profile?.business_name ?? "");
    setPhone(profile?.contact_phone ?? "");
    setDescription(profile?.description ?? "");
    setCity(profile?.city ?? "");
    setState(profile?.state ?? "");
    setCoverage(profile?.coverage_area ?? "");
  }, [profile]);

  const save = async () => {
    setBusy(true);
    setMsg(null);
    const res = await updateProviderProfile({
      business_name: businessName.trim(),
      contact_phone: phone.trim() || null,
      description: description.trim() || null,
      city: city.trim() || null,
      state: state.trim() || null,
      coverage_area: coverage.trim() || null,
    });
    setBusy(false);
    if (!res.ok) {
      setMsg(res.error);
      return;
    }
    setMsg("Profile saved.");
    onSaved();
  };

  if (!profile) return <EmptyState icon="fa-id-card" title="No provider profile loaded." />;

  return (
    <article className="pd-card pd-animate">
      <header className="pd-card-head"><h2><i className="fas fa-id-card" /> Profile</h2></header>
      <p className="pd-muted">Verification: <strong>{profile.verification_status}</strong> · Approval: <strong>{profile.approval_status}</strong> (admin-controlled)</p>
      <label className="cd-field">Business name<input value={businessName} onChange={(e) => setBusinessName(e.target.value)} /></label>
      <label className="cd-field">Phone<input value={phone} onChange={(e) => setPhone(e.target.value)} /></label>
      <label className="cd-field">City<input value={city} onChange={(e) => setCity(e.target.value)} /></label>
      <label className="cd-field">State<input value={state} onChange={(e) => setState(e.target.value)} /></label>
      <label className="cd-field">Coverage area<input value={coverage} onChange={(e) => setCoverage(e.target.value)} /></label>
      <label className="cd-field">Description<textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={4} /></label>
      <p>Profile completion: {profileCompletionPct(profile)}%</p>
      <button type="button" className="pd-btn pd-btn-primary" disabled={busy} onClick={() => void save()}>Save profile</button>
      {msg && <p>{msg}</p>}
    </article>
  );
}

function ProviderPoliciesPanel() {
  const [policies, setPolicies] = useState<any[]>([]);
  const [accepted, setAccepted] = useState<any[]>([]);
  const [msg, setMsg] = useState<string | null>(null);
  const load = async () => {
    setPolicies(await listProviderPolicies());
    setAccepted(await listMyPolicyAcceptances());
  };
  useEffect(() => {
    void load();
  }, []);
  const isAccepted = (id: string, version: string) =>
    accepted.some((a) => a.policy_id === id && a.policy_version === version);
  return (
    <div style={{ marginTop: 20 }}>
      <h3>Required policies (draft — legal review before launch)</h3>
      <p className="pd-muted">You must accept all required current versions before receiving job offers.</p>
      {policies.length === 0 ? (
        <p className="pd-muted">No policies loaded (apply provider portal migrations on Supabase).</p>
      ) : (
        <ul className="pd-verify-list">
          {policies.map((pol) => (
            <li key={pol.id} style={{ flexDirection: "column", alignItems: "flex-start" }}>
              <strong>{pol.title}</strong> <span className="pd-muted">v{pol.version}</span>
              <details style={{ marginTop: 6, maxWidth: "100%" }}>
                <summary>Read policy</summary>
                <pre style={{ whiteSpace: "pre-wrap", fontSize: "0.85rem" }}>{pol.body}</pre>
              </details>
              {isAccepted(pol.id, pol.version) ? (
                <span className="ad-badge ok">Accepted</span>
              ) : (
                <button
                  type="button"
                  className="pd-btn pd-btn-primary"
                  style={{ marginTop: 8 }}
                  onClick={() =>
                    void acceptProviderPolicy(pol.id, pol.version).then((r) => {
                      setMsg(r.ok ? "Acceptance recorded." : r.error);
                      void load();
                    })
                  }
                >
                  I have read and accept
                </button>
              )}
            </li>
          ))}
        </ul>
      )}
      {msg && <p>{msg}</p>}
    </div>
  );
}

function ProviderDashboard() {
  const [collapsed, setCollapsed] = useState(false);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [menuOpen, setMenuOpen] = useState(false);
  const [dashOpen, setDashOpen] = useState(true);
  const menuRef = useRef<HTMLDivElement>(null);

  const navigate = useNavigate();
  const { section } = Route.useSearch();
  const active = section ?? "Dashboard";
  const setActive = (label: string) => {
    void navigate({ to: "/provider", search: { section: label } });
    setMobileOpen(false);
  };

  const { data, loading, reload } = useProviderData();
  const [online, setOnlineLocal] = useState(false);
  const [chatFor, setChatFor] = useState<import("@/lib/customer-data").Booking | null>(null);

  const handleLogout = async () => {
    try {
      await signOutProvider();
    } catch (err) {
      console.error("Sign out error:", err);
    } finally {
      navigate({ to: "/" });
    }
  };
  useEffect(() => {
    if (data.profile) setOnlineLocal(data.profile.is_online);
  }, [data.profile]);

  const toggleOnline = async () => {
    const next = !online;
    setOnlineLocal(next); // optimistic
    const res = await setProviderOnline(next);
    if (!res.ok) setOnlineLocal(!next); // revert on failure
    else void reload();
  };

  const STATS = useMemo(() => buildStats(data), [data]);
  const PERFORMANCE = useMemo(() => buildPerformance(data), [data]);
  const VERIFICATION = useMemo(() => buildVerification(data), [data]);
  const CHECKLIST = useMemo(() => buildChecklist(data), [data]);
  const profilePct = useMemo(() => profileCompletionPct(data.profile), [data.profile]);
  const providerName = data.profile?.business_name || "Provider";

  useEffect(() => {
    const onDown = (e: MouseEvent) => {
      if (menuRef.current && !menuRef.current.contains(e.target as Node)) setMenuOpen(false);
    };
    const onKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") {
        setMenuOpen(false);
        setMobileOpen(false);
      }
    };
    document.addEventListener("mousedown", onDown);
    document.addEventListener("keydown", onKey);
    return () => {
      document.removeEventListener("mousedown", onDown);
      document.removeEventListener("keydown", onKey);
    };
  }, []);

  return (
    <div className={`pd-shell${collapsed ? " is-collapsed" : ""}${mobileOpen ? " is-mobile-open" : ""}`}>
      {/* ---------- Sidebar ---------- */}
      <aside className="pd-sidebar" aria-label="Provider navigation">
        <div className="pd-brand">
          <Link to="/" className="pd-brand-link" aria-label="CleanConnect home">
            <span className="pd-logo" aria-hidden="true">
              <i className="fas fa-broom" />
            </span>
            <span className="pd-brand-text">
              <strong>
                Clean<span>Connect</span>
              </strong>
              <em>Clean Homes, Happy Lives</em>
            </span>
          </Link>
        </div>

        <nav className="pd-nav">
          <button
            type="button"
            className="pd-nav-item active"
            aria-expanded={dashOpen}
            onClick={() => setDashOpen((o) => !o)}
            title="Dashboard"
          >
            <i className="fas fa-gauge-high" aria-hidden="true" />
            <span>Dashboard</span>
            <i className={`fas fa-chevron-down cc-caret${dashOpen ? " open" : ""}`} aria-hidden="true" />
          </button>
          <div className={`cc-submenu${dashOpen ? " open" : ""}`}>
            <Link to="/customer" className="pd-nav-item pd-nav-sub">
              <i className="fas fa-user" aria-hidden="true" />
              <span>Customer Dashboard</span>
            </Link>
            <Link to="/provider" className="pd-nav-item pd-nav-sub">
              <i className="fas fa-user-tie" aria-hidden="true" />
              <span>Provider Dashboard</span>
            </Link>
            <Link to="/admin" className="pd-nav-item pd-nav-sub">
              <i className="fas fa-shield-halved" aria-hidden="true" />
              <span>Admin Dashboard</span>
            </Link>
          </div>
          <button
            type="button"
            className={`pd-nav-item${active === "Dashboard" ? " active" : ""}`}
            title="Dashboard"
            onClick={() => setActive("Dashboard")}
          >
            <i className="fas fa-gauge-high" aria-hidden="true" />
            <span>Dashboard</span>
          </button>
          {NAV.filter((item) => item.label !== "Dashboard").map((item) => (
            <button
              key={item.label}
              type="button"
              className={`pd-nav-item${active === item.label ? " active" : ""}`}
              title={item.label}
              onClick={() => setActive(item.label)}
            >
              <i className={`fas ${item.icon}`} aria-hidden="true" />
              <span>{item.label}</span>
              {typeof item.badge === "number" && <span className="pd-nav-badge">{item.badge}</span>}
            </button>
          ))}
          <button type="button" className="pd-nav-item pd-logout" onClick={() => void handleLogout()}>
            <i className="fas fa-arrow-right-from-bracket" aria-hidden="true" />
            <span>Logout</span>
          </button>
        </nav>

        <div className="pd-side-card">
          <strong>Grow faster</strong>
          <p>Complete your profile to unlock more job requests.</p>
          <button type="button" className="pd-btn pd-btn-light pd-ripple">
            Complete Profile
          </button>
        </div>
      </aside>

      {mobileOpen && (
        <button
          type="button"
          className="pd-overlay"
          aria-label="Close navigation"
          onClick={() => setMobileOpen(false)}
        />
      )}

      {/* ---------- Main ---------- */}
      <div className="pd-main">
        <header className="pd-topbar">
          <button
            type="button"
            className="pd-icon-btn pd-burger"
            aria-label="Toggle navigation"
            onClick={() => {
              if (window.innerWidth <= 1024) setMobileOpen((v) => !v);
              else setCollapsed((v) => !v);
            }}
          >
            <i className="fas fa-bars" />
          </button>

          <div className="pd-search">
            <i className="fas fa-magnifying-glass" aria-hidden="true" />
            <input type="search" placeholder="Search for jobs, customers, payouts..." aria-label="Search dashboard" />
          </div>

          <div className="pd-top-right">
            <button
              type="button"
              className={`pd-toggle${online ? " on" : ""}`}
              onClick={() => void toggleOnline()}
              aria-pressed={online}
              aria-label={online ? "You are online. Go offline" : "You are offline. Go online"}
            >
              <span className="pd-toggle-dot" />
              {online ? "Online" : "Offline"}
            </button>

            <button type="button" className="pd-icon-btn" aria-label="Notifications, none new">
              <i className="fas fa-bell" />
              <span className="pd-count">0</span>
            </button>
            <button type="button" className="pd-icon-btn" aria-label="Messages, none new">
              <i className="fas fa-comment-dots" />
              <span className="pd-count">0</span>
            </button>

            <div className="pd-profile" ref={menuRef}>
              <button
                type="button"
                className="pd-profile-btn"
                onClick={() => setMenuOpen((v) => !v)}
                aria-expanded={menuOpen}
                aria-haspopup="menu"
              >
                <span className="pd-avatar" aria-hidden="true">
                  <i className="fas fa-user" />
                </span>
                <span className="pd-profile-text">
                  <strong>
                    Hello, Provider
                    <i className="fas fa-circle-check pd-verified" title="Verified provider" />
                  </strong>
                  <em>Cleaning Professional</em>
                </span>
                <i className="fas fa-chevron-down" aria-hidden="true" />
              </button>
              {menuOpen && (
                <div className="pd-menu" role="menu">
                  {[
                    { i: "fa-id-card", t: "My Profile" },
                    { i: "fa-calendar-days", t: "Availability" },
                    { i: "fa-wallet", t: "Wallet" },
                    { i: "fa-gear", t: "Settings" },
                  ].map((m) => (
                    <button key={m.t} type="button" role="menuitem" className="pd-menu-item">
                      <i className={`fas ${m.i}`} /> {m.t}
                    </button>
                  ))}
                  <button
                    type="button"
                    className="pd-menu-item"
                    role="menuitem"
                    onClick={() => void handleLogout()}
                  >
                    <i className="fas fa-arrow-right-from-bracket" /> Logout
                  </button>
                </div>
              )}
            </div>
          </div>
        </header>

        <main className="pd-content">
          {active === "Dashboard" && (
          <>
          <OfferBanner />

          {/* Welcome */}
          <section className="pd-welcome pd-animate">
            <div>
              <h1>Welcome back, {providerName} 👋</h1>
              <p>Start accepting jobs and grow your cleaning business with CleanConnect.</p>
            </div>
            <button type="button" className="pd-btn pd-btn-primary pd-ripple">
              <i className="fas fa-inbox" /> Browse Job Requests
            </button>
          </section>

          {/* Stats */}
          <section className="pd-stats" aria-label="Account overview">
            {STATS.map((s, i) =>
              loading ? (
                <div className="pd-card pd-skel-card" key={s.label}>
                  <div className="pd-skel pd-skel-icon" />
                  <div className="pd-skel pd-skel-line" />
                  <div className="pd-skel pd-skel-line short" />
                </div>
              ) : (
                <article className="pd-card pd-stat pd-animate" key={s.label} style={{ animationDelay: `${i * 45}ms` }}>
                  <span className={`pd-stat-icon tone-${s.tone}`} aria-hidden="true">
                    <i className={`fas ${s.icon}`} />
                  </span>
                  <div className="pd-stat-body">
                    <span className="pd-stat-label">{s.label}</span>
                    <span className="pd-stat-value">
                      <StatValue stat={s} />
                    </span>
                    <span className="pd-stat-foot">{s.foot}</span>
                  </div>
                </article>
              ),
            )}
          </section>

          {/* Row: jobs + wallet */}
          <section className="pd-grid pd-grid-2-1">
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-inbox" /> Accepted, Not Yet Started
                </h2>
                <button type="button" className="pd-link">
                  View all
                </button>
              </header>
              {data.bookings.filter((b) => b.status === "provider_accepted").length > 0 ? (
                <SimpleBookingList bookings={data.bookings.filter((b) => b.status === "provider_accepted")} onMessage={setChatFor} />
              ) : (
                <EmptyState
                  icon="fa-clipboard-list"
                  title="No jobs yet."
                  body="Accept your first booking to start earning."
                  cta="Browse Job Requests"
                />
              )}
            </article>

            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-wallet" /> Wallet
                </h2>
              </header>
              <div className="pd-wallet">
                <span className="pd-wallet-label">Wallet Balance</span>
                <strong className="pd-wallet-value">{ngn(providerStats(data).walletBalance)}</strong>
                <div className="pd-wallet-rows">
                  <span>
                    Pending Withdrawal <b>Not tracked yet</b>
                  </span>
                  <span>
                    Total Withdrawn <b>Not tracked yet</b>
                  </span>
                </div>
                <button type="button" className="pd-btn pd-btn-light" disabled>
                  <i className="fas fa-money-bill-transfer" /> Withdraw Earnings
                </button>
                <p className="pd-wallet-note">
                  {providerStats(data).walletBalance > 0
                    ? "Withdrawals aren't wired up yet — coming in a later phase."
                    : "You haven't earned any money yet."}
                </p>
              </div>
            </article>
          </section>

          {/* Row: recent jobs + schedule */}
          <section className="pd-grid pd-grid-2">
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-briefcase" /> Recent Jobs
                </h2>
              </header>
              {data.bookings.filter((b) => b.status === "completed").length > 0 ? (
                <SimpleBookingList bookings={data.bookings.filter((b) => b.status === "completed")} onMessage={setChatFor} />
              ) : (
                <EmptyState icon="fa-broom" title="No completed jobs yet." cta="Accept First Job" />
              )}
            </article>
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-calendar-day" /> Upcoming Schedule
                </h2>
              </header>
              {data.bookings.filter((b) => ACTIVE_STATUS_SET.has(b.status) && new Date(b.scheduled_for) >= new Date()).length > 0 ? (
                <SimpleBookingList bookings={data.bookings.filter((b) => ACTIVE_STATUS_SET.has(b.status) && new Date(b.scheduled_for) >= new Date())} onMessage={setChatFor} />
              ) : (
                <EmptyState icon="fa-calendar-xmark" title="No upcoming bookings." cta="View Job Requests" />
              )}
            </article>
          </section>

          {/* Earnings overview */}
          <section className="pd-grid pd-grid-2-1">
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-chart-column" /> Earnings Overview
                </h2>
                <span className="pd-tag">Weekly</span>
              </header>
              <div className="pd-earn-grid">
                {[
                  ["Today's Earnings", ngn(providerStats(data).todayEarnings)],
                  ["Weekly Earnings", ngn(providerStats(data).weeklyEarnings)],
                  ["Monthly Earnings", ngn(providerStats(data).monthlyEarnings)],
                  ["Yearly Earnings", ngn(providerStats(data).yearlyEarnings)],
                ].map(([l, v]) => (
                  <div className="pd-earn-cell" key={l}>
                    <span>{l}</span>
                    <strong>{v}</strong>
                  </div>
                ))}
              </div>
              <ZeroBars labels={DAYS} />
            </article>

            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-shield-halved" /> Verification Status
                </h2>
              </header>
              <div className="pd-verify-badge">
                <i className={`fas ${data.profile?.approval_status === "approved" ? "fa-circle-check" : "fa-clock"}`} />{" "}
                {data.profile?.approval_status === "approved"
                  ? "Application Approved"
                  : data.profile?.approval_status === "pending"
                    ? "Application Under Review"
                    : "Not Yet Approved"}
              </div>
              <ul className="pd-verify-list">
                {VERIFICATION.map((v) => (
                  <li key={v.label} className={v.done ? "" : "pd-verify-pending"}>
                    <i className={`fas ${v.done ? "fa-circle-check" : "fa-circle"}`} aria-hidden="true" /> {v.label}
                  </li>
                ))}
              </ul>
              <div className="pd-progress-head">
                <span>Profile Completion</span>
                <strong>{profilePct}%</strong>
              </div>
              <div
                className="pd-progress"
                role="progressbar"
                aria-valuenow={profilePct}
                aria-valuemin={0}
                aria-valuemax={100}
                aria-label="Profile completion"
              >
                <span style={{ width: `${profilePct}%` }} />
              </div>
            </article>
          </section>

          {/* Performance */}
          <section className="pd-card pd-animate">
            <header className="pd-card-head">
              <h2>
                <i className="fas fa-gauge-high" /> Performance Analytics
              </h2>
            </header>
            <div className="pd-perf">
              {PERFORMANCE.map((p) => (
                <div className="pd-perf-cell" key={p.label}>
                  <div className="pd-perf-top">
                    <span>{p.label}</span>
                    <strong>{p.value}</strong>
                  </div>
                  <div className="pd-progress sm">
                    <span style={{ width: `${p.pct}%` }} />
                  </div>
                </div>
              ))}
            </div>
          </section>

          {/* Charts */}
          <section className="pd-grid pd-grid-2">
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-chart-column" /> Monthly Earnings
                </h2>
              </header>
              <ZeroBars labels={MONTHS.slice(0, 8)} />
            </article>
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-chart-line" /> Customer Growth
                </h2>
              </header>
              <ZeroLine labels={MONTHS.slice(0, 6)} />
            </article>
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-chart-simple" /> Completed Jobs
                </h2>
              </header>
              <ZeroBars labels={DAYS} />
            </article>
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-list-check" /> Profile Completion Checklist
                </h2>
                <span className="pd-tag">
                  {CHECKLIST.filter((c) => c.done).length}/{CHECKLIST.length}
                </span>
              </header>
              <ul className="pd-check">
                {CHECKLIST.map((c) => (
                  <li key={c.label} className={c.done ? "done" : ""}>
                    <i className={`fas ${c.done ? "fa-circle-check" : "fa-circle"}`} aria-hidden="true" />
                    {c.label}
                  </li>
                ))}
              </ul>
            </article>
          </section>

          {/* Calendar */}
          <section className="pd-card pd-animate">
            <header className="pd-card-head">
              <h2>
                <i className="fas fa-calendar-days" /> Weekly Availability
              </h2>
              <button type="button" className="pd-link">
                Edit availability
              </button>
            </header>
            <div className="pd-cal" role="table" aria-label="Weekly availability calendar, currently empty">
              <div className="pd-cal-row head" role="row">
                <span role="columnheader" />
                {DAYS.map((d) => (
                  <span key={d} role="columnheader">
                    {d}
                  </span>
                ))}
              </div>
              {SLOTS.map((s) => (
                <div className="pd-cal-row" role="row" key={s}>
                  <span className="pd-cal-slot" role="rowheader">
                    {s}
                  </span>
                  {DAYS.map((d) => (
                    <span className="pd-cal-cell" role="cell" key={d + s} aria-label={`${d} ${s}: not set`} />
                  ))}
                </div>
              ))}
            </div>
          </section>

          {/* Quick actions */}
          <section className="pd-animate">
            <h2 className="pd-section-title">
              <i className="fas fa-bolt" /> Quick Actions
            </h2>
            <div className="pd-actions">
              {QUICK_ACTIONS.map((a) => (
                <button type="button" className="pd-action pd-ripple" key={a.label}>
                  <span className={`pd-stat-icon tone-${a.tone}`} aria-hidden="true">
                    <i className={`fas ${a.icon}`} />
                  </span>
                  <strong>{a.label}</strong>
                  <i className="fas fa-arrow-right" aria-hidden="true" />
                </button>
              ))}
            </div>
          </section>

          {/* Reviews / Messages / Notifications */}
          <section className="pd-grid pd-grid-3">
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-star" /> Reviews
                </h2>
              </header>
              {data.reviews.length > 0 ? (
                <ul className="pd-verify-list" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
                  {data.reviews.slice(0, 4).map((r) => (
                    <li key={r.id}>
                      <i className="fas fa-star" style={{ color: "#f59e0b" }} aria-hidden="true" /> {r.rating}/5 — {r.comment || "No comment"}
                    </li>
                  ))}
                </ul>
              ) : (
                <EmptyState
                  icon="fa-star-half-stroke"
                  title="No reviews yet."
                  body="Complete your first job to receive customer ratings."
                />
              )}
            </article>
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-comment-dots" /> Messages
                </h2>
              </header>
              <EmptyState
                icon="fa-comments"
                title="No messages yet."
                body="Customer conversations will appear here after accepting a booking."
              />
            </article>
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-bell" /> Notifications
                </h2>
              </header>
              <EmptyState icon="fa-bell-slash" title="You're all caught up." body="No new notifications." />
            </article>
          </section>

          {/* Timeline + AI */}
          <section className="pd-grid pd-grid-2-1">
            <article className="pd-card pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-clock-rotate-left" /> Activity Timeline
                </h2>
              </header>
              <EmptyState
                icon="fa-timeline"
                title="No recent activity."
                body="Once you start working, your activities will appear here."
              />
            </article>

            <article className="pd-card pd-ai pd-animate">
              <header className="pd-card-head">
                <h2>
                  <i className="fas fa-wand-magic-sparkles" /> CleanConnect AI
                </h2>
              </header>
              <p className="pd-ai-msg">Hello! I'm here to help you grow your cleaning business.</p>
              <ul className="pd-ai-tips">
                {AI_TIPS.map((t) => (
                  <li key={t}>
                    <i className="fas fa-lightbulb" aria-hidden="true" /> {t}
                  </li>
                ))}
              </ul>
              <button type="button" className="pd-btn pd-btn-light pd-ripple">
                <i className="fas fa-comment" /> Ask the assistant
              </button>
            </article>
          </section>


          </>
          )}

          {active === "Job Requests" && (
            <article className="pd-card pd-animate">
              <header className="pd-card-head"><h2><i className="fas fa-inbox" /> Job Requests</h2></header>
              <p className="pd-muted">Only offers matched to you by CleanConnect. Quote-only jobs never appear here.</p>
              <OfferBanner />
            </article>
          )}

          {active === "My Jobs" && (
            <article className="pd-card pd-animate">
              <header className="pd-card-head"><h2><i className="fas fa-briefcase" /> My Jobs</h2></header>
              {loading ? <p>Loading…</p> : data.bookings.length === 0 ? (
                <EmptyState icon="fa-briefcase" title="No jobs yet." body="Accepted offers will show here with start and complete actions." />
              ) : (
                <SimpleBookingList bookings={data.bookings} onMessage={setChatFor} onChanged={() => void reload()} limit={50} showActions />
              )}
            </article>
          )}

          {active === "Schedule" && (
            <article className="pd-card pd-animate">
              <header className="pd-card-head"><h2><i className="fas fa-calendar-days" /> Schedule</h2></header>
              <SimpleBookingList
                bookings={data.bookings.filter((b) => ACTIVE_STATUS_SET.has(b.status))}
                onMessage={setChatFor}
                onChanged={() => void reload()}
                limit={50}
                showActions
              />
              {!loading && data.bookings.filter((b) => ACTIVE_STATUS_SET.has(b.status)).length === 0 && (
                <EmptyState icon="fa-calendar-xmark" title="No upcoming scheduled jobs." />
              )}
            </article>
          )}

          {active === "Earnings" && (
            <article className="pd-card pd-animate">
              <header className="pd-card-head"><h2><i className="fas fa-sack-dollar" /> Earnings</h2></header>
              <div className="pd-earn-grid">
                {[
                  ["Today", ngn(providerStats(data).todayEarnings)],
                  ["This week", ngn(providerStats(data).weeklyEarnings)],
                  ["This month", ngn(providerStats(data).monthlyEarnings)],
                  ["This year", ngn(providerStats(data).yearlyEarnings)],
                ].map(([l, v]) => (
                  <div className="pd-earn-cell" key={l as string}><span>{l}</span><strong>{v}</strong></div>
                ))}
              </div>
              <p className="pd-muted" style={{ marginTop: 12 }}>
                Figures come from successful payment records linked to your account. Platform commission (default ₦5,500) is applied when payouts are released — not invented on this screen.
              </p>
            </article>
          )}

          {active === "Wallet" && <ProviderWalletSection stats={providerStats(data)} />}

          {active === "Messages" && (
            <article className="pd-card pd-animate">
              <header className="pd-card-head"><h2><i className="fas fa-comment-dots" /> Messages</h2></header>
              <p className="pd-muted">Open a job under My Jobs and use Message to chat with that customer only after assignment.</p>
              <SimpleBookingList
                bookings={data.bookings.filter((b) => !!b.customer_id && b.status !== "cancelled")}
                onMessage={setChatFor}
                limit={30}
              />
            </article>
          )}

          {active === "Reviews" && (
            <article className="pd-card pd-animate">
              <header className="pd-card-head"><h2><i className="fas fa-star" /> Reviews</h2></header>
              {data.reviews.length === 0 ? (
                <EmptyState icon="fa-star" title="No reviews yet." body="Reviews from completed jobs will appear here." />
              ) : (
                <ul className="pd-verify-list">
                  {data.reviews.map((r) => (
                    <li key={r.id}>
                      <strong>{r.rating}★</strong> — {r.comment || "No comment"}{" "}
                      <span className="pd-muted">{new Date(r.created_at).toLocaleDateString("en-NG")}</span>
                    </li>
                  ))}
                </ul>
              )}
            </article>
          )}

          {active === "Notifications" && <ProviderNotificationsSection />}

          {active === "Analytics" && (
            <article className="pd-card pd-animate">
              <header className="pd-card-head"><h2><i className="fas fa-chart-line" /> Analytics</h2></header>
              <ul className="pd-verify-list">
                {buildPerformance(data).map((row) => (
                  <li key={row.label}>{row.label}: <strong>{row.value}</strong></li>
                ))}
              </ul>
              {data.bookings.length < 3 && (
                <p className="pd-muted">Complete more jobs for richer analytics.</p>
              )}
            </article>
          )}

          {active === "Profile" && <ProviderProfileEditor profile={data.profile} onSaved={() => void reload()} />}

          {active === "Settings" && (
            <article className="pd-card pd-animate">
              <header className="pd-card-head"><h2><i className="fas fa-gear" /> Settings</h2></header>
              <p><strong>Availability:</strong> use the Online toggle in the header (saved to your provider record). Offline providers do not receive new offers.</p>
              <p className="pd-muted">Password and email security: use Supabase Auth recovery from the login page (forgot password). Admin-controlled fields (approval, verification) cannot be changed here.</p>
              <ProviderPoliciesPanel />
              <button type="button" className="pd-btn pd-btn-primary" style={{ marginTop: 16 }} onClick={() => void handleLogout()}>Log out</button>
            </article>
          )}

          {active === "Help & Support" && <ProviderSupportSection />}

          {active !== "Dashboard" && active !== "Job Requests" && active !== "My Jobs" && active !== "Schedule" && active !== "Earnings" && active !== "Wallet" && active !== "Messages" && active !== "Reviews" && active !== "Notifications" && active !== "Analytics" && active !== "Profile" && active !== "Settings" && active !== "Help & Support" && (
            <article className="pd-card"><p>Unknown section.</p></article>
          )}

          <footer className="pd-footer">
            <span>© 2026 CleanConnect. All Rights Reserved.</span>
            <div>
              <Link to="/">Home</Link>
              <Link to="/become-provider">Earn with CleanConnect</Link>
              <Link to="/customer">Customer view</Link>
            </div>
          </footer>
        </main>
      </div>

      {chatFor && chatFor.customer_id && (
        <ChatDialog
          bookingId={chatFor.id}
          recipientId={chatFor.customer_id}
          title={`${chatFor.service} · ${chatFor.reference}`}
          onClose={() => setChatFor(null)}
        />
      )}
    </div>
  );
}
